self.__BUILD_MANIFEST = function(s, a, e) {
    return {
        __rewrites: {
            beforeFiles: [],
            afterFiles: [],
            fallback: []
        },
        "/": [s, "static/chunks/8b2edbe5-88fda7e551a465fa.js", "static/chunks/7624509f-d4788bde68ffcf77.js", "static/chunks/65dc0f57-f8e9bc6d54b63406.js", "static/chunks/2a84ada5-934f76c5f35a4a8a.js", "static/chunks/6c95e57a-25c10cd1860477c4.js", a, "static/chunks/711-c5511b85f0901a77.js", e, "static/chunks/pages/index-36ca7562ffcfb7e5.js"],
        "/_error": ["static/chunks/pages/_error-524ff14eb4bc5674.js"],
        "/about": [s, a, e, "static/chunks/pages/about-32d8dfe8d54b0cd6.js"],
        sortedPages: ["/", "/_app", "/_error", "/about"]
    }
}("static/chunks/41bfca99-129021bfdd5544b5.js", "static/chunks/992-ced7547cd7d8a1ec.js", "static/chunks/119-e9f71542918687bd.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();
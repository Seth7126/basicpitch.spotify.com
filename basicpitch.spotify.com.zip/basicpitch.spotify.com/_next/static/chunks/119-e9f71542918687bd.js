"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [119], {
        14801: function(n, t, e) {
            e.d(t, {
                T: function() {
                    return G
                }
            });
            var r = e(33647),
                i = e(96111),
                o = e(63208),
                a = e.n(o),
                u = (e(88356), e(23169)),
                c = e(6509),
                s = e(86273),
                d = e(20465);

            function l() {
                var n = (0, r.Z)(["\n  max-height: 146px;\n  max-width: ", "px;\n\n  > .baseColors {\n    /* Switches base color based on the current colorset to match the default text */\n    fill: ", ";\n  }\n"]);
                return l = function() {
                    return n
                }, n
            }
            var f = u.ZP.svg(l(), (function(n) {
                    return n.width
                }), (0, i.NE)("textBase")),
                h = function(n) {
                    var t = n.width,
                        e = void 0 === t ? 231 : t,
                        r = n.className,
                        i = n.style;
                    return (0, d.jsxs)(f, {
                        viewBox: "0 0 231 146",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        preserveAspectRatio: "xMinYMin",
                        width: e,
                        className: r,
                        style: i,
                        children: [(0, d.jsxs)("g", {
                            clipPath: "url(#clip0_101_1011)",
                            className: "baseColors",
                            children: [(0, d.jsx)("path", {
                                d: "M0.224121 65.8056V0.886841H22.8437C27.349 0.886841 31.0639 1.66124 33.9949 3.2163C36.9195 4.77135 39.1037 6.851 40.5349 9.46148C41.9662 12.072 42.6818 14.9635 42.6818 18.1298C42.6818 20.9214 42.1902 23.2259 41.2132 25.0432C40.2362 26.8606 38.9481 28.297 37.3613 29.3524C35.7683 30.4078 34.0509 31.1885 32.1965 31.7006V32.3376C34.1753 32.4625 36.1666 33.162 38.1641 34.4297C40.1616 35.6975 41.8355 37.5149 43.1858 39.8818C44.5299 42.2487 45.2082 45.1465 45.2082 48.5689C45.2082 51.9912 44.4739 54.7516 42.9991 57.3496C41.5243 59.9476 39.1971 62.0085 36.0172 63.5323C32.8374 65.0562 28.6993 65.8118 23.6029 65.8118H0.224121V65.8056ZM8.05853 29.4149H22.5886C24.947 29.4149 27.0814 28.9527 28.9856 28.0222C30.8897 27.0917 32.4081 25.7802 33.5344 24.094C34.6607 22.4015 35.227 20.4155 35.227 18.1361C35.227 15.282 34.2375 12.8589 32.2587 10.8604C30.2799 8.86195 27.1436 7.86272 22.8437 7.86272H8.05853V29.4149ZM8.05853 58.8297H23.5967C28.7118 58.8297 32.3521 57.8305 34.5113 55.832C36.6706 53.8335 37.7472 51.4104 37.7472 48.5564C37.7472 46.3581 37.1871 44.3221 36.0732 42.4548C34.9594 40.5875 33.3664 39.0824 31.3066 37.952C29.2407 36.8217 26.8014 36.2533 23.9763 36.2533H8.05853V58.8235V58.8297Z"
                            }), (0, d.jsx)("path", {
                                d: "M58.9602 65.8056H50.7524L74.5046 0.886841H82.5879L106.34 65.8056H98.126L78.7983 11.1602H78.2942L58.9602 65.8056Z"
                            }), (0, d.jsx)("path", {
                                d: "M151.822 17.1181C151.442 13.9081 149.905 11.41 147.211 9.63634C144.516 7.86271 141.212 6.97589 137.292 6.97589C134.429 6.97589 131.928 7.44428 129.793 8.36857C127.659 9.2991 125.991 10.5794 124.803 12.2031C123.614 13.8331 123.017 15.6817 123.017 17.7488C123.017 19.4788 123.434 20.9651 124.268 22.2017C125.102 23.4382 126.166 24.4624 127.472 25.2743C128.779 26.0862 130.148 26.7544 131.579 27.2728C133.011 27.7911 134.33 28.2095 135.525 28.5218L142.096 30.2954C143.782 30.7388 145.661 31.3509 147.734 32.1315C149.806 32.9122 151.797 33.9738 153.701 35.3166C155.605 36.6593 157.18 38.3767 158.424 40.4688C159.669 42.561 160.285 45.1277 160.285 48.1692C160.285 51.6789 159.376 54.8453 157.553 57.6806C155.73 60.5096 153.079 62.7642 149.594 64.4316C146.109 66.0991 141.884 66.9359 136.912 66.9359C132.283 66.9359 128.275 66.1865 124.896 64.6877C121.517 63.1888 118.866 61.0967 116.937 58.4113C115.008 55.7258 113.919 52.6095 113.67 49.0622H121.754C121.965 51.5166 122.793 53.54 124.23 55.1325C125.674 56.7313 127.504 57.9116 129.725 58.6798C131.947 59.4542 134.342 59.8352 136.912 59.8352C139.899 59.8352 142.587 59.3418 144.964 58.3613C147.342 57.3808 149.227 56.0069 150.621 54.2395C152.009 52.4783 152.706 50.4112 152.706 48.0443C152.706 45.8897 152.108 44.1348 150.907 42.7796C149.706 41.4244 148.126 40.3252 146.172 39.4821C144.212 38.639 142.096 37.8958 139.825 37.2651L131.866 34.9856C126.813 33.5304 122.812 31.4445 119.862 28.7404C116.912 26.0362 115.438 22.4952 115.438 18.1236C115.438 14.4889 116.421 11.3163 118.393 8.59964C120.36 5.88299 123.017 3.77211 126.352 2.26078C129.688 0.749442 133.421 -0.00622559 137.547 -0.00622559C141.673 -0.00622559 145.425 0.736952 148.667 2.22955C151.909 3.72215 154.485 5.75184 156.389 8.3311C158.294 10.9104 159.302 13.8331 159.407 17.1118H151.828L151.822 17.1181Z"
                            }), (0, d.jsx)("path", {
                                d: "M179.998 17.1367V65.8679H172.674V17.1367H179.998Z"
                            }), (0, d.jsx)("path", {
                                d: "M231 32.987H223.601C223.315 31.4008 222.786 30.0018 222.014 28.7965C221.243 27.5912 220.291 26.567 219.17 25.7239C218.05 24.8808 216.793 24.25 215.412 23.8191C214.031 23.3882 212.562 23.1758 211.013 23.1758C208.212 23.1758 205.711 23.8815 203.508 25.293C201.305 26.7044 199.563 28.7778 198.293 31.5007C197.018 34.2298 196.383 37.5585 196.383 41.493C196.383 45.4274 197.018 48.8061 198.293 51.5352C199.563 54.2644 201.305 56.3253 203.52 57.7242C205.736 59.1231 208.225 59.8164 210.988 59.8164C212.518 59.8164 213.981 59.604 215.362 59.1856C216.744 58.7672 218.001 58.1426 219.121 57.3183C220.241 56.4939 221.193 55.4822 221.977 54.2831C222.761 53.084 223.302 51.7101 223.601 50.1551L231 50.18C230.602 52.5782 229.842 54.7765 228.71 56.7812C227.577 58.7859 226.134 60.5158 224.373 61.971C222.612 63.4198 220.602 64.544 218.337 65.3371C216.078 66.1302 213.607 66.5299 210.938 66.5299C206.731 66.5299 202.985 65.5245 199.7 63.5198C196.414 61.515 193.825 58.636 191.934 54.8952C190.042 51.148 189.102 46.6827 189.102 41.4992C189.102 36.3157 190.048 31.8254 191.946 28.0908C193.844 24.3562 196.433 21.4834 199.724 19.4787C203.01 17.474 206.75 16.4685 210.938 16.4685C213.514 16.4685 215.922 16.837 218.156 17.5739C220.39 18.3108 222.406 19.3913 224.192 20.8089C225.978 22.2266 227.453 23.9565 228.629 25.9987C229.799 28.0346 230.589 30.3641 231 32.9808V32.987Z"
                            }), (0, d.jsx)("path", {
                                d: "M61.7916 87.1641V80.1882H110.304V87.1641H89.9619V145.107H82.1275V87.1641H61.7854H61.7916Z"
                            }), (0, d.jsx)("path", {
                                d: "M166.228 100.479H158.393C157.933 98.2181 157.124 96.2321 155.979 94.521C154.834 92.8098 153.44 91.3671 151.81 90.193C150.179 89.0189 148.375 88.1384 146.396 87.5451C144.417 86.9518 142.351 86.6583 140.204 86.6583C136.29 86.6583 132.743 87.6512 129.576 89.6372C126.408 91.6232 123.888 94.5522 122.028 98.4179C120.167 102.284 119.234 107.03 119.234 112.651C119.234 118.271 120.167 123.018 122.028 126.884C123.888 130.749 126.408 133.678 129.576 135.664C132.743 137.65 136.29 138.643 140.204 138.643C142.351 138.643 144.417 138.35 146.396 137.756C148.375 137.163 150.179 136.283 151.81 135.108C153.44 133.934 154.834 132.485 155.979 130.768C157.124 129.044 157.933 127.065 158.393 124.823H166.228C165.637 128.139 164.566 131.112 163.004 133.728C161.449 136.351 159.507 138.574 157.192 140.398C154.877 142.228 152.283 143.614 149.408 144.564C146.533 145.513 143.465 145.988 140.198 145.988C134.679 145.988 129.775 144.632 125.481 141.928C121.188 139.224 117.809 135.377 115.344 130.387C112.88 125.397 111.648 119.483 111.648 112.638C111.648 105.794 112.88 99.8731 115.344 94.8894C117.809 89.8995 121.188 86.0587 125.481 83.3483C129.775 80.6442 134.685 79.2889 140.198 79.2889C143.459 79.2889 146.533 79.7636 149.408 80.7128C152.283 81.6621 154.877 83.0548 157.192 84.8784C159.507 86.7082 161.449 88.9253 163.004 91.5358C164.56 94.1462 165.637 97.1189 166.228 100.46V100.479Z"
                            }), (0, d.jsx)("path", {
                                d: "M186.694 145.113H178.86V80.1945H186.694V145.113ZM221.187 80.1945H229.021V145.113H221.187V80.1945Z"
                            }), (0, d.jsx)("path", {
                                d: "M26.7328 97.6997C24.25 96.3195 21.1199 95.6326 17.3428 95.6326H0.0373535V144.364H7.3615V127.233H17.3241C21.0888 127.233 24.2126 126.54 26.7017 125.154C29.1908 123.767 31.0576 121.881 32.296 119.489C33.5343 117.104 34.1566 114.406 34.1566 111.408C34.1566 108.41 33.5405 105.744 32.3084 103.352C31.0763 100.966 29.2157 99.0799 26.7391 97.6997H26.7328ZM25.7372 116.329C25.0403 117.772 23.9513 118.908 22.4641 119.745C20.9768 120.576 19.0416 120.994 16.6583 120.994H7.3615V101.934H16.5587C18.9918 101.934 20.9582 102.34 22.4516 103.146C23.9451 103.957 25.0403 105.075 25.7372 106.499C26.4342 107.929 26.7826 109.559 26.7826 111.402C26.7826 113.244 26.4342 114.886 25.7372 116.329Z"
                            }), (0, d.jsx)("path", {
                                d: "M50.037 95.6263H42.7129V144.358H50.037V95.6263Z"
                            })]
                        }), (0, d.jsxs)("g", {
                            children: [(0, d.jsx)("path", {
                                d: "M50.2796 80.1945H0V85.5403H50.2796V80.1945Z",
                                fill: "#FAE62D"
                            }), (0, d.jsx)("path", {
                                d: "M228.953 0.886841H172.625V6.23272H228.953V0.886841Z",
                                fill: "#FFCDD2"
                            }), (0, d.jsx)("path", {
                                d: "M215.039 109.847H192.83V115.192H215.039V109.847Z",
                                fill: "#F573A0"
                            }), (0, d.jsx)("path", {
                                d: "M85.2513 41.568H71.8662V46.9139H85.2513V41.568Z",
                                fill: "#FF4632"
                            })]
                        }), (0, d.jsx)("defs", {
                            children: (0, d.jsx)("clipPath", {
                                id: "clip0_101_1011",
                                children: (0, d.jsx)("rect", {
                                    width: "231",
                                    height: "146"
                                })
                            })
                        })]
                    })
                },
                g = e(99195);

            function p() {
                var n = (0, r.Z)(["\n  width: 100%;\n  padding-top: 68px;\n  padding-bottom: 36px;\n  flex-grow: 0;\n  flex-shrink: 0;\n"]);
                return p = function() {
                    return n
                }, n
            }

            function v() {
                var n = (0, r.Z)(["\n  display: flex;\n  flex-wrap: wrap;\n  justify-items: center;\n  margin-bottom: 28px;\n"]);
                return v = function() {
                    return n
                }, n
            }

            function x() {
                var n = (0, r.Z)(["\n  flex: 1;\n\n  @media (max-width: ", ") {\n    flex: 0 0 50%;\n  }\n  @media (max-width: ", ") {\n    ", "\n  }\n"]);
                return x = function() {
                    return n
                }, n
            }

            function C() {
                var n = (0, r.Z)(["\n  text-align: center;\n  a {\n    font-size: 16px;\n    color: unset;\n    text-decoration: none;\n    font-weight: bold;\n  }\n  div {\n    font-size: 12px;\n  }\n"]);
                return C = function() {
                    return n
                }, n
            }

            function m() {
                var n = (0, r.Z)(["\n  text-decoration: none !important;\n  margin-bottom: 20px;\n  display: block;\n"]);
                return m = function() {
                    return n
                }, n
            }
            var w = (0, u.ZP)(g.$)(p()),
                Z = u.ZP.div(v()),
                b = u.ZP.div(x(), c.SIq, c.gXv, (function(n) {
                    return n.hideOnMobile && "display: none;"
                })),
                H = u.ZP.div(C()),
                j = (0, u.ZP)(s.h)(m()),
                k = function(n) {
                    var t = n.dark;
                    return (0, d.jsxs)(w, {
                        dark: t,
                        light: !t,
                        children: [(0, d.jsxs)(Z, {
                            children: [(0, d.jsx)(b, {
                                hideOnMobile: !0,
                                children: (0, d.jsx)(h, {
                                    width: 151
                                })
                            }), (0, d.jsxs)(b, {
                                children: [(0, d.jsx)(j, {
                                    href: "https://github.com/spotify/basic-pitch",
                                    target: "_blank",
                                    children: "GitHub"
                                }), (0, d.jsx)(j, {
                                    href: "https://spotify.github.io/",
                                    target: "_blank",
                                    children: "Open Source @ Spotify"
                                }), (0, d.jsx)(j, {
                                    href: "https://www.soundtrap.com/",
                                    target: "_blank",
                                    children: "Soundtrap"
                                })]
                            }), (0, d.jsxs)(b, {
                                children: [(0, d.jsx)(j, {
                                    href: "https://twitter.com/spotifyeng",
                                    target: "_blank",
                                    children: "@SpotifyEng Twitter"
                                }), (0, d.jsx)(j, {
                                    href: "https://www.linkedin.com/showcase/spotify-r&d/",
                                    target: "_blank",
                                    children: "Spotify R&D LinkedIn"
                                }), (0, d.jsx)(j, {
                                    href: "https://open.spotify.com/show/5eXZwvvxt3K2dxha3BSaAe",
                                    target: "_blank",
                                    children: "NerdOut@Spotify Podcast"
                                })]
                            }), (0, d.jsxs)(b, {
                                children: [(0, d.jsx)(j, {
                                    href: "https://engineering.atspotify.com/",
                                    target: "_blank",
                                    children: "Spotify R&D Engineering"
                                }), (0, d.jsx)(j, {
                                    href: "https://research.atspotify.com/",
                                    target: "_blank",
                                    children: "Spotify R&D Research"
                                }), (0, d.jsx)(j, {
                                    href: "https://spotify.design/",
                                    target: "_blank",
                                    children: "Spotify R&D Design"
                                }), (0, d.jsx)(j, {
                                    href: "https://www.lifeatspotify.com/",
                                    target: "_blank",
                                    children: "Life at Spotify"
                                })]
                            })]
                        }), (0, d.jsxs)(H, {
                            children: [(0, d.jsx)("a", {
                                href: "https://spotify.github.io/",
                                target: "_blank",
                                children: "Made with \ud83d\udc9a at Spotify"
                            }), (0, d.jsx)("br", {}), (0, d.jsx)("div", {
                                children: "Copyright \xa9 2022 Spotify AB"
                            })]
                        })]
                    })
                },
                y = e(97171);

            function _() {
                var n = (0, r.Z)(["\n  display: flex;\n  flex-direction: row;\n  width: 390px;\n  height: 38px;\n  justify-content: space-between;\n  margin-left: 0;\n  margin-top: 0;\n  padding: 0;\n\n  @media (max-width: ", ") {\n    margin-left: ", ";\n  }\n\n  & > * + * {\n    margin-left: ", ";\n  }\n"]);
                return _ = function() {
                    return n
                }, n
            }

            function M() {
                var n = (0, r.Z)(["\n  ", "\n  list-style-type: none;\n"]);
                return M = function() {
                    return n
                }, n
            }

            function P() {
                var n = (0, r.Z)(["\n  font-weight: 700;\n  font-size: 24px;\n  line-height: 29px;\n  text-transform: uppercase;\n  color: #fae62d;\n  text-decoration: none;\n"]);
                return P = function() {
                    return n
                }, n
            }
            var E = u.ZP.ul(_(), c.gXv, c.g4V, c.dly),
                A = u.ZP.li(M(), (function(n) {
                    return n.href === n.path ? "border-bottom: 5px solid #f573a0;" : ""
                })),
                V = u.ZP.a(P()),
                S = function(n) {
                    var t = n.href,
                        e = n.target,
                        r = n.children,
                        i = (0, y.useRouter)();
                    return (0, d.jsx)(A, {
                        href: t,
                        path: i.asPath,
                        children: (0, d.jsx)(V, {
                            target: e,
                            href: t,
                            children: r
                        })
                    })
                },
                R = function() {
                    return (0, d.jsxs)(E, {
                        children: [(0, d.jsx)(S, {
                            href: "/",
                            children: "Demo"
                        }), (0, d.jsx)(S, {
                            href: "/about",
                            children: "About"
                        }), (0, d.jsx)(S, {
                            href: "https://github.com/spotify/basic-pitch",
                            target: "_new",
                            children: "Github"
                        })]
                    })
                };

            function N() {
                var n = (0, r.Z)(["\n  display: flex;\n  flex-direction: row;\n  marginbottom: '60px';\n  justify-content: space-between;\n"]);
                return N = function() {
                    return n
                }, n
            }
            var B = u.ZP.div(N()),
                D = function() {
                    return (0, d.jsx)(g.$, {
                        paddingY: 0,
                        children: (0, d.jsxs)(B, {
                            children: [(0, d.jsx)(h, {}), (0, d.jsx)(R, {})]
                        })
                    })
                };

            function F() {
                var n = (0, r.Z)(["\n  display: flex;\n  flex-direction: column;\n  align-items: stretch;\n  min-height: 100vh;\n"]);
                return F = function() {
                    return n
                }, n
            }

            function L() {
                var n = (0, r.Z)(["\n  background: ", ";\n  color: ", ";\n  flex-grow: 1;\n  flex-shrink: 0;\n"]);
                return L = function() {
                    return n
                }, n
            }
            var U = u.ZP.div(F()),
                K = u.ZP.div(L(), (0, i.NE)(i.iK.backgroundBase), (0, i.NE)(i.iK.textBase));

            function G(n) {
                var t = n.children,
                    e = n.darkFooter,
                    r = n.title,
                    i = "Basic Pitch: An open source MIDI converter from Spotify - ".concat(r);
                return (0, d.jsxs)(d.Fragment, {
                    children: [(0, d.jsxs)(a(), {
                        children: [(0, d.jsx)("title", {
                            children: i
                        }), (0, d.jsx)("meta", {
                            property: "og:title",
                            content: i
                        }, "title")]
                    }), (0, d.jsxs)(U, {
                        children: [(0, d.jsxs)(K, {
                            children: [(0, d.jsx)(D, {}), t]
                        }), (0, d.jsx)(k, {
                            dark: e
                        })]
                    })]
                })
            }
        },
        99195: function(n, t, e) {
            e.d(t, {
                $: function() {
                    return v
                }
            });
            var r = e(13005),
                i = e(5630),
                o = e(24105),
                a = e(33647),
                u = e(96111),
                c = e(6509),
                s = e(23169),
                d = e(20465);

            function l() {
                var n = (0, a.Z)(["\n      padding: ", "px 0;\n      background-color: ", ";\n      color: ", ";\n\n      @media (max-width: ", ") {\n        padding: ", "px 0;\n      }\n    "]);
                return l = function() {
                    return n
                }, n
            }

            function f() {
                var n = (0, a.Z)(["\n  ", "\n"]);
                return f = function() {
                    return n
                }, n
            }

            function h() {
                var n = (0, a.Z)(["\n  @media (min-width: ", ") and (max-width: ", ") {\n    padding-left: ", ";\n    padding-right: ", ";\n  }\n\n  @media (max-width: ", ") {\n    padding-left: ", ";\n    padding-right: ", ";\n  }\n\n  @media (min-width: ", ") {\n    max-width: 900px;\n    margin-left: auto;\n    margin-right: auto;\n  }\n"]);
                return h = function() {
                    return n
                }, n
            }
            var g = s.ZP.section(f(), (function(n) {
                    var t = n.backgroundColor,
                        e = n.condensed,
                        r = n.dark,
                        i = n.light,
                        o = n.paddingY,
                        a = n.tint,
                        d = t && (0, u.NE)(t) || (a ? (0, u.NE)(u.iK.backgroundTintedBase) : "") || (i || r ? (0, u.NE)(u.iK.backgroundBase) : ""),
                        f = null !== o && void 0 !== o ? o : e ? 50 : 90;
                    return (0, s.iv)(l(), f, d, i || r ? (0, u.NE)("textBase") : "", c.rmE, Math.round(f / 2))
                })),
                p = s.ZP.div(h(), c.gXv, c.rmE, c.mGT, c.mGT, c.gXv, c.nuo, c.nuo, c.vmZ),
                v = function(n) {
                    var t = n.children,
                        e = n.className,
                        a = (0, o.Z)(n, ["children", "className"]),
                        c = [e, a.dark && (0, u.Mg)("invertedDark"), a.light && (0, u.Mg)("invertedLight")].filter(Boolean);
                    return (0, d.jsx)(g, (0, i.Z)((0, r.Z)({
                        className: c.join(" ")
                    }, a), {
                        children: (0, d.jsx)(p, {
                            children: t
                        })
                    }))
                }
        },
        35164: function(n, t, e) {
            e.d(t, {
                A: function() {
                    return M
                },
                H1: function() {
                    return E
                },
                H2: function() {
                    return A
                },
                H3: function() {
                    return V
                },
                H4: function() {
                    return S
                },
                H5: function() {
                    return R
                },
                Ol: function() {
                    return N
                },
                P: function() {
                    return B
                },
                Ul: function() {
                    return L
                },
                x4: function() {
                    return D
                },
                zw: function() {
                    return F
                }
            });
            var r = e(33647),
                i = e(6755),
                o = e(96111),
                a = e(86273),
                u = e(6509),
                c = e(23169),
                s = e(67396);

            function d() {
                var n = (0, r.Z)(["\n      color: ", ";\n    "]);
                return d = function() {
                    return n
                }, n
            }

            function l() {
                var n = (0, r.Z)(["\n      color: ", ";\n    "]);
                return l = function() {
                    return n
                }, n
            }

            function f() {
                var n = (0, r.Z)(["\n  ", "\n  ", "\n"]);
                return f = function() {
                    return n
                }, n
            }

            function h() {
                var n = (0, r.Z)(["\n  /* Add a thick colorful underline */\n  &,\n  &[href],\n  &:hover:not([disabled]) {\n    text-decoration: underline;\n    text-decoration-color: ", ";\n    text-underline-offset: 0.1em;\n    text-decoration-thickness: 0.2em;\n  }\n  &:hover:not([disabled]) {\n    color: unset;\n    text-decoration-color: ", ";\n  }\n"]);
                return h = function() {
                    return n
                }, n
            }

            function g() {
                var n = (0, r.Z)(["\n  /* Make underline a little farther away from text */\n  a,\n  a[href],\n  a:hover:not([disabled]) {\n    text-underline-offset: 0.2em;\n  }\n"]);
                return g = function() {
                    return n
                }, n
            }

            function p() {
                var n = (0, r.Z)(["\n  ", "\n  ", "\n"]);
                return p = function() {
                    return n
                }, n
            }

            function v() {
                var n = (0, r.Z)(["\n  ", "\n  ", "\n"]);
                return v = function() {
                    return n
                }, n
            }

            function x() {
                var n = (0, r.Z)(["\n  ", "\n  ", "\n"]);
                return x = function() {
                    return n
                }, n
            }

            function C() {
                var n = (0, r.Z)(["\n  ", "\n  ", "\n"]);
                return C = function() {
                    return n
                }, n
            }

            function m() {
                var n = (0, r.Z)(["\n  ", "\n  ", "\n"]);
                return m = function() {
                    return n
                }, n
            }

            function w() {
                var n = (0, r.Z)(["\n  --margin-left: 72px;\n  ", "\n  counter-reset: item;\n  padding-left: 70px;\n  list-style: none;\n  width: 85%;\n  margin-left: var(--margin-left);\n\n  @media (max-width: ", ") {\n    padding-left: 20px;\n  }\n\n  > li {\n    counter-increment: item;\n    position: relative;\n    margin-bottom: 0.6em;\n\n    &:before {\n      /* Generated svg using Sketch.app, then encoded using https://yoksel.github.io/url-encoder/ */\n      --dash: url(\"data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='36px' height='7px' viewBox='0 0 38 7' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3ELine%3C/title%3E%3Cg id='Page-1' stroke='none' stroke-width='1' fill='none' fill-rule='evenodd'%3E%3Crect id='Rectangle' fill='%23F573A0' x='16' y='0' width='20' height='3'%3E%3C/rect%3E%3C/g%3E%3C/svg%3E\");\n      position: absolute;\n      content: counter(item) var(--dash);\n      left: calc(var(--margin-left) * -1);\n      color: var(--text-announcement);\n    }\n  }\n"]);
                return w = function() {
                    return n
                }, n
            }

            function Z() {
                var n = (0, r.Z)(["\n  ", "\n"]);
                return Z = function() {
                    return n
                }, n
            }

            function b() {
                var n = (0, r.Z)([""]);
                return b = function() {
                    return n
                }, n
            }

            function H() {
                var n = (0, r.Z)(["\n  text-align: center;\n"]);
                return H = function() {
                    return n
                }, n
            }

            function j() {
                var n = (0, r.Z)(["\n      font-family: unset;\n      font-size: unset;\n      font-weight: unset;\n    "]);
                return j = function() {
                    return n
                }, n
            }

            function k() {
                var n = (0, r.Z)(["\n  /* Unset the default variant so B doesn't change font styles by default */\n  ", "\n"]);
                return k = function() {
                    return n
                }, n
            }

            function y() {
                var n = (0, r.Z)(["\n  ", "\n  /* Generated svg using Sketch.app, then encoded using https://yoksel.github.io/url-encoder/ */\n  list-style-image: url(\"data:image/svg+xml,%3C%3Fxml version='1.0' encoding='UTF-8'%3F%3E%3Csvg width='38px' height='7px' viewBox='0 0 38 7' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E%3Ctitle%3ELine%3C/title%3E%3Cg id='Page-1' stroke='none' stroke-width='1' fill='none' fill-rule='evenodd'%3E%3Crect id='Rectangle' fill='%23F573A0' x='0' y='0' width='20' height='3'%3E%3C/rect%3E%3C/g%3E%3C/svg%3E\");\n  list-style-position: outside;\n  padding-left: 0;\n  margin-left: 46px;\n  li {\n    margin-bottom: 0.6em;\n  }\n"]);
                return y = function() {
                    return n
                }, n
            }
            var _ = (0, c.ZP)(i.Dy)(f(), (function(n) {
                    return n.$pink && (0, c.iv)(d(), (0, o.NE)(o.iK.textBrightAccent))
                }), (function(n) {
                    return n.$yellow && (0, c.iv)(l(), (0, o.NE)(o.iK.textAnnouncement))
                })),
                M = (0, c.ZP)(a.h)(h(), (0, o.NE)(o.iK.textBrightAccent), (0, o.NE)(o.iK.textBase));
            a.h.defaultProps = {
                target: "_blank"
            };
            var P = (0, c.iv)(g()),
                E = (0, c.ZP)(_).attrs({
                    forwardedAs: "h1",
                    variant: "altoBrio",
                    pink: !0
                })(p(), (0, s.Hu)(1), P),
                A = (0, c.ZP)(_).attrs({
                    forwardedAs: "h2",
                    variant: "alto"
                })(v(), (0, s.Hu)(.8), P),
                V = (0, c.ZP)(_).attrs({
                    forwardedAs: "h3",
                    variant: "cello"
                })(x(), (0, s.Hu)(.8), P),
                S = (0, c.ZP)(_).attrs({
                    forwardedAs: "h4",
                    variant: "ballad",
                    weight: "bold"
                })(C(), (0, s.Hu)(.5), P),
                R = (0, c.ZP)(_).attrs({
                    forwardedAs: "h5",
                    variant: "viola",
                    weight: "bold"
                })(m(), (0, s.Hu)(.7), P),
                N = (0, c.ZP)(_).attrs({
                    forwardedAs: "ul",
                    variant: "ballad"
                })(w(), (0, s.Hu)(1.4), u.rmE),
                B = (0, c.ZP)(_).attrs({
                    forwardedAs: "p"
                })(Z(), (0, s.Hu)(1.4));
            B.defaultProps = {
                variant: "ballad"
            };
            var D = (0, c.ZP)(_).attrs({
                    variant: "viola",
                    semanticColor: o.iK.textSubdued
                })(b()),
                F = (0, c.ZP)(B)(H()),
                L = ((0, c.ZP)(_).attrs({
                    forwardedAs: "span"
                })(k(), (function(n) {
                    return !n.variant && (0, c.iv)(j())
                })), (0, c.ZP)(_).attrs({
                    forwardedAs: "ul",
                    variant: "ballad"
                })(y(), (0, s.Hu)(1.4)))
        },
        67396: function(n, t, e) {
            e.d(t, {
                Hu: function() {
                    return u
                },
                MW: function() {
                    return c
                }
            });
            var r = e(33647),
                i = e(23169);

            function o() {
                var n = (0, r.Z)(["\n      padding-bottom: ", "rem;\n    "]);
                return o = function() {
                    return n
                }, n
            }

            function a() {
                var n = (0, r.Z)(["\n    margin-bottom: ", "rem;\n    margin-top: ", "rem;\n  "]);
                return a = function() {
                    return n
                }, n
            }
            var u = function(n) {
                    return function(t) {
                        return !t.condensed && (0, i.iv)(o(), n)
                    }
                },
                c = function(n) {
                    return function(t) {
                        return !t.condensed && (0, i.iv)(a(), n, n)
                    }
                }
        },
        44897: function(n, t, e) {
            e.d(t, {
                A: function() {
                    return V.A
                },
                DF: function() {
                    return f
                },
                PL: function() {
                    return p
                },
                zw: function() {
                    return V.zw
                },
                H1: function() {
                    return V.H1
                },
                H2: function() {
                    return V.H2
                },
                H3: function() {
                    return V.H3
                },
                H4: function() {
                    return V.H4
                },
                H5: function() {
                    return V.H5
                },
                Ol: function() {
                    return V.Ol
                },
                P: function() {
                    return V.P
                },
                BZ: function() {
                    return A
                },
                x4: function() {
                    return V.x4
                },
                Ul: function() {
                    return V.Ul
                }
            });
            var r = e(33647),
                i = e(5769),
                o = e(96111),
                a = e(23169),
                u = e(67396);

            function c() {
                var n = (0, r.Z)(["\n  font-size: 1.1rem;\n  font-weight: 700;\n  text-transform: uppercase;\n  box-sizing: border-box;\n  ", "\n"]);
                return c = function() {
                    return n
                }, n
            }
            var s = (0, a.iv)(c(), (0, u.MW)(1.4));

            function d() {
                var n = (0, r.Z)(["\n        --color: ", ";\n        --essential-bright-accent: var(--color) !important;\n        --background-base: var(--color) !important;\n        --background-highlight: var(--color) !important;\n        --background-press: var(--color) !important;\n      "]);
                return d = function() {
                    return n
                }, n
            }

            function l() {
                var n = (0, r.Z)(["\n  ", "\n  ", "\n"]);
                return l = function() {
                    return n
                }, n
            }
            var f = (0, a.ZP)(i.D)(l(), s, (function(n) {
                    var t = n.$yellow && o.iK.essentialAnnouncement || n.$red && o.iK.essentialNegative;
                    return !!t && (0, a.iv)(d(), (0, o.NE)(t))
                })),
                h = e(76623);

            function g() {
                var n = (0, r.Z)(["\n  ", "\n  --color: ", ";\n  --border: 3px solid var(--color);\n  border: var(--border);\n  color: var(--color);\n  &:hover {\n    border: var(--border);\n  }\n"]);
                return g = function() {
                    return n
                }, n
            }
            var p = (0, a.ZP)(h.P)(g(), s, (0, o.NE)("essentialAnnouncement")),
                v = e(70119),
                x = e(27606),
                C = e(2013),
                m = e(44e3),
                w = e(30673),
                Z = e(80285),
                b = e(96851),
                H = e(60335),
                j = e(22536),
                k = e(14942),
                y = e(88356),
                _ = e(20465);

            function M() {
                var n = (0, r.Z)(["\n      @keyframes pulse {\n        0%,\n        100% {\n          box-shadow: 0 0 0 10px rgba(0, 0, 0, 0);\n        }\n        50% {\n          box-shadow: 0 0 0 10px #ff463270;\n        }\n      }\n      animation: pulse 2s infinite;\n      box-shadow: 0 0 0 10px rgba(0, 0, 0, 0);\n    "]);
                return M = function() {
                    return n
                }, n
            }

            function P() {
                var n = (0, r.Z)(["\n  min-width: 162px; /* to ensure stays same width despite state */\n  box-shadow: 0 0 0 10px rgba(0, 0, 0, 0);\n  ", "\n"]);
                return P = function() {
                    return n
                }, n
            }
            var E = (0, a.ZP)(f)(P(), (function(n) {
                    return n.$red && (0, a.iv)(M())
                })),
                A = function(n) {
                    (0, Z.Z)(e, n);
                    var t = (0, b.Z)(e);

                    function e(n) {
                        var r;
                        return (0, C.Z)(this, e), r = t.call(this, n), (0, w.Z)((0, v.Z)(r), "_chunks", void 0), (0, w.Z)((0, v.Z)(r), "_mediaRecorder", void 0), r.state = {
                            isRecording: !1
                        }, r._toggleRecording = r._toggleRecording.bind((0, v.Z)(r)), r._onGetUserMediaSuccessful = r._onGetUserMediaSuccessful.bind((0, v.Z)(r)), r._onDataAvailable = r._onDataAvailable.bind((0, v.Z)(r)), r._onMediarecorderStop = r._onMediarecorderStop.bind((0, v.Z)(r)), r
                    }
                    return (0, m.Z)(e, [{
                        key: "_onMediarecorderStop",
                        value: function() {
                            var n = this;
                            return (0, x.Z)((function() {
                                var t, e, r;
                                return (0, H.__generator)(this, (function(i) {
                                    switch (i.label) {
                                        case 0:
                                            return t = new Blob(n._chunks, {
                                                type: "audio/wav; codecs=MS_PCM"
                                            }), n.setState({
                                                isRecording: !1
                                            }), r = (e = n.props).onFileAdded, [4, t.arrayBuffer()];
                                        case 1:
                                            return r.apply(e, [i.sent()]), [2]
                                    }
                                }))
                            }))()
                        }
                    }, {
                        key: "_onDataAvailable",
                        value: function(n) {
                            this._chunks.push(n.data)
                        }
                    }, {
                        key: "_onGetUserMediaSuccessful",
                        value: function(n) {
                            this._mediaRecorder = new MediaRecorder(n), this._mediaRecorder.onstop = this._onMediarecorderStop, this._mediaRecorder.ondataavailable = this._onDataAvailable, this._mediaRecorder.start(1e3), this.setState({
                                isRecording: !0
                            })
                        }
                    }, {
                        key: "_toggleRecording",
                        value: function() {
                            var n, t;
                            null === (t = (n = this.props).onClick) || void 0 === t || t.call(n), this.state.isRecording ? this._mediaRecorder.stop() : navigator.mediaDevices && navigator.mediaDevices.getUserMedia ? (this._chunks = [], navigator.mediaDevices.getUserMedia({
                                audio: !0
                            }).then(this._onGetUserMediaSuccessful).catch((function(n) {
                                console.log("The following getUserMedia error occurred: ".concat(n))
                            }))) : console.log("getUserMedia not supported on your browser!")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var n = this.state.isRecording ? "Stop" : "Record";
                            return (0, _.jsx)(E, {
                                disabled: this.props.disabled,
                                iconLeading: this.state.isRecording ? j.$ : k.l,
                                onClick: this._toggleRecording,
                                $red: this.state.isRecording,
                                children: n
                            })
                        }
                    }]), e
                }(y.Component),
                V = e(35164)
        }
    }
]);
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [293], {
        54819: function(t, e) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function() {
                function t() {
                    this.listeners = new Map
                }
                return t.prototype.addEventListener = function(t, e) {
                    if (!this.hasEventListener(t, e)) {
                        var r = this.listeners.get(t);
                        r || this.listeners.set(t, r = []), r.push(e)
                    }
                }, t.prototype.hasEventListener = function(t, e) {
                    var r = this.listeners.get(t);
                    return Array.isArray(r) && r.includes(e)
                }, t.prototype.removeEventListener = function(t, e) {
                    if (this.hasEventListener(t, e)) {
                        var r = this.listeners.get(t);
                        Array.isArray(r) && r.splice(r.findIndex((function(t) {
                            return t === e
                        })), 1)
                    }
                }, t.prototype.dispatchEvent = function(t) {
                    var e = this,
                        r = this.listeners.get(t.type);
                    r && r.forEach((function(r) {
                        return r.call(e, t)
                    }))
                }, t
            }();
            e.default = r
        },
        13449: function(t, e) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function() {
                function t(t) {
                    this.func = t, this.jobs = new Map;
                    var e = "\n      self.onmessage = function(message) {\n        function resolve(result) { postMessage({ id: message.data.id, result: result }); }\n        function reject(error) { postMessage({ id: message.data.id, error: error }); }\n        (" + t.toString() + ")(message.data.input, resolve, reject);\n      }\n    ";
                    this.blob = new Blob([e], {
                        type: "text/javascript"
                    }), this.url = URL.createObjectURL(this.blob), this.worker = new Worker(this.url), this.worker.addEventListener("message", this.onMessage.bind(this)), URL.revokeObjectURL(this.url)
                }
                return t.prototype.run = function(t, e) {
                    var r = this;
                    return new Promise((function(n, o) {
                        var i = r.generateJobId();
                        r.jobs.set(i, {
                            resolve: n,
                            reject: o
                        }), r.worker.postMessage({
                            id: i,
                            input: t
                        }, e)
                    }))
                }, t.prototype.generateJobId = function() {
                    var t = Math.floor(4294967295 * Math.random()),
                        e = Math.floor(4294967295 * Math.random()),
                        r = Math.floor(4294967295 * Math.random());
                    return Date.now() + "-" + t + "-" + e + "-" + r
                }, t.prototype.onMessage = function(t) {
                    var e = t.data,
                        r = e.id,
                        n = e.error,
                        o = e.result;
                    if (!this.jobs.has(r)) throw "No job found with id=" + r;
                    var i = this.jobs.get(r);
                    n ? i.reject(n) : i.resolve(o), this.jobs.delete(r)
                }, t
            }();
            e.default = r
        },
        51768: function(t, e, r) {
            "use strict";
            var n = this && this.__extends || function() {
                    var t = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
                    };
                    return function(e, r) {
                        function n() {
                            this.constructor = e
                        }
                        t(e, r), e.prototype = null === r ? Object.create(r) : (n.prototype = r.prototype, new n)
                    }
                }(),
                o = this && this.__decorate || function(t, e, r, n) {
                    var o, i = arguments.length,
                        a = i < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, r) : n;
                    if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) a = Reflect.decorate(t, e, r, n);
                    else
                        for (var s = t.length - 1; s >= 0; s--)(o = t[s]) && (a = (i < 3 ? o(a) : i > 3 ? o(e, r, a) : o(e, r)) || a);
                    return i > 3 && a && Object.defineProperty(e, r, a), a
                },
                i = this && this.__awaiter || function(t, e, r, n) {
                    return new(r || (r = Promise))((function(o, i) {
                        function a(t) {
                            try {
                                c(n.next(t))
                            } catch (e) {
                                i(e)
                            }
                        }

                        function s(t) {
                            try {
                                c(n.throw(t))
                            } catch (e) {
                                i(e)
                            }
                        }

                        function c(t) {
                            t.done ? o(t.value) : new r((function(e) {
                                e(t.value)
                            })).then(a, s)
                        }
                        c((n = n.apply(t, e || [])).next())
                    }))
                },
                a = this && this.__generator || function(t, e) {
                    var r, n, o, i, a = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return i = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" === typeof Symbol && (i[Symbol.iterator] = function() {
                        return this
                    }), i;

                    function s(i) {
                        return function(s) {
                            return function(i) {
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; a;) try {
                                    if (r = 1, n && (o = 2 & i[0] ? n.return : i[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, i[1])).done) return o;
                                    switch (n = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                        case 0:
                                        case 1:
                                            o = i;
                                            break;
                                        case 4:
                                            return a.label++, {
                                                value: i[1],
                                                done: !1
                                            };
                                        case 5:
                                            a.label++, n = i[1], i = [0];
                                            continue;
                                        case 7:
                                            i = a.ops.pop(), a.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = (o = a.trys).length > 0 && o[o.length - 1]) && (6 === i[0] || 2 === i[0])) {
                                                a = 0;
                                                continue
                                            }
                                            if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                                a.label = i[1];
                                                break
                                            }
                                            if (6 === i[0] && a.label < o[1]) {
                                                a.label = o[1], o = i;
                                                break
                                            }
                                            if (o && a.label < o[2]) {
                                                a.label = o[2], a.ops.push(i);
                                                break
                                            }
                                            o[2] && a.ops.pop(), a.trys.pop();
                                            continue
                                    }
                                    i = e.call(t, a)
                                } catch (s) {
                                    i = [6, s], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & i[0]) throw i[1];
                                return {
                                    value: i[0] ? i[1] : void 0,
                                    done: !0
                                }
                            }([i, s])
                        }
                    }
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var s = r(44639),
                c = r(1963),
                u = r(48471),
                l = r(54819),
                h = r(11103);
            r(71654);
            var f = function(t) {
                function e(e) {
                    var r = t.call(this) || this;
                    return r.scrollFriction = .095, r.zoomFriction = .095, r.minVisibleSeconds = .01, r.maxVisibleSeconds = 30, r.defaultMarkerColor = 1697420, r.defaultRegionColor = 10219745, r.defaultRegionAlpha = .85, r.alwaysZoomToMidpoint = !1, r.zoomT = 0, r.markers = new Map, r.regions = new Map, r.element = document.createElement("div"), r.element.style.position = "relative", r.canvas = document.createElement("canvas"), r.element.appendChild(r.canvas), r.createContext(), r.setupWavformProgram(), r.setupMarkerProgram(), r.setupRegionProgram(), r.bindEventHandlers(), r.setDefaults(), e && r.load(e), r
                }
                var r;
                return n(e, t), r = e, e.from = function(t, e) {
                    return i(this, void 0, void 0, (function() {
                        return a(this, (function(n) {
                            return [2, (new r).load(t, e)]
                        }))
                    }))
                }, Object.defineProperty(e.prototype, "width", {
                    set: function(t) {
                        this.canvas.width = t * (devicePixelRatio || 1), this.canvas.style.width = t + "px"
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "height", {
                    set: function(t) {
                        this.canvas.height = t * (devicePixelRatio || 1), this.canvas.style.height = t + "px"
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "startTime", {
                    set: function(t) {
                        this.nextTick(this.dispatchTimeChangeEvent)
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "endTime", {
                    set: function(t) {
                        this.nextTick(this.dispatchTimeChangeEvent)
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "sampleRate", {
                    set: function(t) {
                        this.useProgram(this.waveformProgram), this.context.uniform1i(this.waveformSampleRateLocation, this.sampleRate), this.disableRender(), this.scheduleWaveformRefresh()
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "sampleScale", {
                    set: function(t) {
                        this.useProgram(this.waveformProgram), this.context.uniform1f(this.waveformSampleScaleLocation, this.sampleScale)
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "source", {
                    set: function(t) {
                        this.waveformColor = this.waveformColor, this.sampleRate = this.sampleRate || t.sampleRate, this.startTime = this.maxVisibleSeconds / -2, this.endTime = this.maxVisibleSeconds / 2, this.zoom(0, 0), this.disableRender(), this.scheduleWaveformRefresh()
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "backgroundColor", {
                    set: function(t) {
                        var e = this.decimalColorToNormalizedRGBArray(t),
                            r = e[0],
                            n = e[1],
                            o = e[2];
                        this.context.clearColor(r, n, o, 1)
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "waveformColor", {
                    set: function(t) {
                        var e = this.decimalColorToNormalizedRGBArray(t),
                            r = e[0],
                            n = e[1],
                            o = e[2];
                        this.useProgram(this.waveformProgram), this.context.uniform1i(this.waveformUseSampleColorsLocation, 0), this.context.uniform3f(this.waveformColorLocation, r, n, o)
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "interactive", {
                    set: function(t) {
                        t ? (this.canvas.addEventListener("touchstart", this.onTouchStart), this.canvas.addEventListener("mousedown", this.onTouchStart), this.canvas.addEventListener("wheel", this.onWheel)) : (this.canvas.addEventListener("touchstart", this.onTouchStart), this.canvas.addEventListener("mousedown", this.onTouchStart), this.canvas.removeEventListener("wheel", this.onWheel), cancelAnimationFrame(this.touchPhysicsRequestId))
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "duration", {
                    get: function() {
                        return this.source ? this.source.duration : 0
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "midpoint", {
                    get: function() {
                        return this.startTime + this.timeRange / 2
                    },
                    set: function(t) {
                        var e = this.timeRange / 2;
                        this.startTime = t - e, this.endTime = t + e
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "timeRange", {
                    get: function() {
                        return this.endTime - this.startTime
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "pixelsPerSecond", {
                    get: function() {
                        return this.width / this.timeRange
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "zoomLevel", {
                    get: function() {
                        return Math.max(0, Math.min(1, this.zoomCurve(this.zoomT)))
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "isPanning", {
                    get: function() {
                        return Math.abs(this.scrollVelocity) >= .1
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "isZooming", {
                    get: function() {
                        return Math.abs(this.zoomVelocity) >= .1
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "totalSamples", {
                    get: function() {
                        return Math.round(this.duration * this.sampleRate)
                    },
                    enumerable: !0,
                    configurable: !0
                }), e.prototype.load = function(t, e) {
                    return i(this, void 0, void 0, (function() {
                        var n = this;
                        return a(this, (function(o) {
                            return [2, new Promise((function(o, s) {
                                return i(n, void 0, void 0, (function() {
                                    var n, c, u, l = this;
                                    return a(this, (function(h) {
                                        switch (h.label) {
                                            case 0:
                                                return t instanceof AudioBuffer ? (this.source = t, o(this), [3, 4]) : [3, 1];
                                            case 1:
                                                return t instanceof ArrayBuffer ? (n = this, [4, r.audioContext.decodeAudioData(t)]) : [3, 3];
                                            case 2:
                                                return n.source = h.sent(), o(this), [3, 4];
                                            case 3:
                                                t instanceof File ? ((c = new FileReader).onerror = s, c.onload = function() {
                                                    o(l.load(c.result))
                                                }, c.readAsArrayBuffer(t)) : "string" === typeof t ? ((u = new XMLHttpRequest).responseType = "arraybuffer", u.onerror = s, u.onload = function() {
                                                    return i(l, void 0, void 0, (function() {
                                                        return a(this, (function(t) {
                                                            return 200 === u.status ? o(this.load(u.response)) : s(u.statusText), [2]
                                                        }))
                                                    }))
                                                }, u.open("GET", t, !0), e && u.setRequestHeader("Authorization", "Bearer " + e), u.send()) : s("Invalid source for waveform"), h.label = 4;
                                            case 4:
                                                return [2]
                                        }
                                    }))
                                }))
                            }))]
                        }))
                    }))
                }, e.prototype.setColorsFromAnalysisData = function(t) {
                    var e = this,
                        r = this.createNormalizer(t.segments, (function(t) {
                            return t.timbre[1]
                        })),
                        n = this.createNormalizer(t.segments, (function(t) {
                            return t.timbre[0]
                        }));
                    this.sampleColors = new Float32Array(3 * this.totalSamples), t.segments.forEach((function(t) {
                        for (var o = 3 * Math.floor(t.start * e.sampleRate), i = 3 * Math.floor((t.start + t.duration) * e.sampleRate), a = e.mapValue(r(t.timbre[1]), 0, 1, .95, 1.85), s = n(t.timbre[0]), c = e.hsvColorToNormalizedRGBArray(a, 1, s), u = c[0], l = c[1], h = c[2], f = o; f < i; f += 3) e.sampleColors[f] = u, e.sampleColors[f + 1] = l, e.sampleColors[f + 2] = h
                    })), this.useProgram(this.waveformProgram), this.context.uniform1i(this.waveformUseSampleColorsLocation, 1), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.sampleColorBuffer), this.context.bufferData(this.context.ARRAY_BUFFER, this.sampleColors, this.context.STATIC_DRAW), this.scheduleRender()
                }, e.prototype.setMarker = function(t, e, r, n) {
                    void 0 === r && (r = this.defaultMarkerColor), this.markers.get(t) && this.deleteMarker(t), this.markers.set(t, {
                        attachment: n,
                        seconds: e,
                        color: r
                    }), n && !this.element.contains(n) && (this.element.appendChild(n), n.style.position = "absolute", n.style.left = n.style.left || "0", n.style.top = n.style.top || "0"), this.scheduleMarkerRefresh()
                }, e.prototype.getMarker = function(t) {
                    return this.markers.get(t)
                }, e.prototype.deleteMarker = function(t) {
                    var e = this.markers.get(t);
                    e && e.attachment && e.attachment.remove(), this.markers.delete(t), this.scheduleMarkerRefresh()
                }, e.prototype.clearMarkers = function() {
                    this.markers.clear(), this.scheduleMarkerRefresh()
                }, e.prototype.setRegion = function(t, e, r, n, o) {
                    void 0 === n && (n = this.defaultRegionColor), void 0 === o && (o = this.defaultRegionAlpha), this.regions.set(t, {
                        secondsStart: e,
                        secondsEnd: r,
                        color: n,
                        alpha: o
                    }), this.scheduleRegionRefresh()
                }, e.prototype.getRegion = function(t) {
                    return this.regions.get(t)
                }, e.prototype.deleteRegion = function(t) {
                    this.regions.delete(t), this.scheduleRegionRefresh()
                }, e.prototype.clearRegions = function() {
                    this.regions.clear(), this.scheduleRegionRefresh()
                }, e.prototype.scrollBySeconds = function(t) {
                    this.midpoint = Math.min(this.duration, Math.max(0, this.midpoint + t))
                }, e.prototype.zoom = function(t, e) {
                    void 0 === e && (e = this.midpoint), e = this.alwaysZoomToMidpoint ? this.midpoint : e, this.zoomT = Math.min(1, Math.max(0, t));
                    var r = (e - this.startTime) / this.timeRange,
                        n = this.mapValue(this.zoomLevel, 0, 1, this.maxVisibleSeconds, this.minVisibleSeconds);
                    this.startTime = e - n * r, this.endTime = e + n * (1 - r)
                }, e.prototype.getSecondsAtPoint = function(t) {
                    var e = t / this.width;
                    return this.startTime + e * this.timeRange
                }, e.prototype.getPointAtSeconds = function(t) {
                    return (t - this.startTime) / this.timeRange * this.width
                }, e.prototype.getSampleIndexAtPoint = function(t) {
                    var e = this.getSecondsAtPoint(t);
                    return Math.round(e * this.sampleRate)
                }, e.prototype.getSampleDataAtPoint = function(t) {
                    var e = this.getSampleIndexAtPoint(t);
                    return this.sampleData[e]
                }, e.prototype.render = function() {
                    this.canRender ? (this.context.clear(this.context.COLOR_BUFFER_BIT), this.context.viewport(0, 0, this.context.drawingBufferWidth, this.context.drawingBufferHeight), this.renderRegions(), this.renderWaveform(), this.renderMarkers()) : this.scheduleRender()
                }, e.prototype.createSnapshot = function(t, e, r, n, o, s) {
                    return void 0 === t && (t = this.width), void 0 === e && (e = this.height), void 0 === r && (r = this.startTime), void 0 === n && (n = this.endTime), void 0 === o && (o = !1), void 0 === s && (s = !1), i(this, void 0, void 0, (function() {
                        var i, c, u, l, h, f;
                        return a(this, (function(a) {
                            switch (a.label) {
                                case 0:
                                    return [4, this.waitForCanRender()];
                                case 1:
                                    return a.sent(), i = devicePixelRatio || 1, c = document.createElement("canvas"), u = c.getContext("2d"), l = new Image, c.style.height = e + "px", c.style.width = t + "px", c.height = e * i, c.width = t * i, h = this.startTime, f = this.endTime, this.startTime = r, this.endTime = n, this.context.clear(this.context.COLOR_BUFFER_BIT), this.context.viewport(0, 0, this.context.drawingBufferWidth, this.context.drawingBufferHeight), s && this.renderRegions(), this.renderWaveform(), o && this.renderMarkers(), u.scale(i, i), u.drawImage(this.canvas, 0, 0, this.canvas.width, this.canvas.height, 0, 0, t, e), this.startTime = h, this.endTime = f, this.context.clear(this.context.COLOR_BUFFER_BIT), this.render(), l.src = c.toDataURL(), [2, l]
                            }
                        }))
                    }))
                }, e.prototype.destroy = function() {
                    this.context.deleteProgram(this.waveformProgram), this.context.deleteProgram(this.markerProgram), this.context.deleteProgram(this.regionProgram), this.context.deleteBuffer(this.sampleDataBuffer), this.context.deleteBuffer(this.sampleIndexBuffer), this.context.deleteBuffer(this.sampleColorBuffer), this.context.deleteBuffer(this.markerPositionBuffer), this.context.deleteBuffer(this.markerColorBuffer), this.context.deleteBuffer(this.regionPositionBuffer), this.context.deleteBuffer(this.regionIndexBuffer), this.context.deleteBuffer(this.regionColorBuffer), cancelAnimationFrame(this.renderRequestId), cancelAnimationFrame(this.touchPhysicsRequestId), clearTimeout(this.waveformRefreshTimeoutId), clearTimeout(this.markerRefreshTimeoutId), clearTimeout(this.regionRefreshTimeoutId), this.context.getExtension("WEBGL_lose_context").loseContext()
                }, e.prototype.waitForCanRender = function() {
                    return i(this, void 0, void 0, (function() {
                        var t = this;
                        return a(this, (function(e) {
                            return [2, new Promise((function(e) {
                                var r = function() {
                                    t.canRender ? e() : setTimeout(r, 1)
                                };
                                r()
                            }))]
                        }))
                    }))
                }, e.prototype.renderWaveform = function() {
                    this.useProgram(this.waveformProgram), this.context.uniform2f(this.waveformTimeWindowLocation, this.startTime, this.endTime), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.sampleDataBuffer), this.context.vertexAttribPointer(this.waveformSampleDataLocation, 1, this.context.FLOAT, !1, 0, 0), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.sampleIndexBuffer), this.context.vertexAttribPointer(this.waveformSampleIndexLocation, 1, this.context.FLOAT, !1, 0, 0), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.sampleColorBuffer), this.context.vertexAttribPointer(this.waveformSampleColorLocation, 3, this.context.FLOAT, !1, 0, 0), this.context.enableVertexAttribArray(this.waveformSampleColorLocation);
                    var t = Math.max(0, Math.floor(this.startTime * this.sampleRate) - 1),
                        e = Math.min(this.totalSamples, Math.ceil(this.endTime * this.sampleRate) + 1) - t;
                    this.context.drawArrays(this.context.LINE_STRIP, t, e), this.context.disableVertexAttribArray(this.waveformSampleColorLocation)
                }, e.prototype.renderMarkers = function() {
                    var t = this;
                    this.markerPositions && this.markerPositions.length && (this.useProgram(this.markerProgram), this.context.uniform2f(this.markerTimeWindowLocation, this.startTime, this.endTime), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.markerPositionBuffer), this.context.vertexAttribPointer(this.markerPositionLocation, 2, this.context.FLOAT, !1, 0, 0), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.markerColorBuffer), this.context.vertexAttribPointer(this.markerColorLocation, 3, this.context.FLOAT, !1, 0, 0), this.context.drawArrays(this.context.LINES, 0, this.markerPositions.length / 2), this.markers.forEach((function(e) {
                        e.attachment && (e.attachment.style.transform = "translate3d(" + t.getPointAtSeconds(e.seconds) + "px,0,0)")
                    })))
                }, e.prototype.renderRegions = function() {
                    this.regionPositions && this.regionPositions.length && (this.useProgram(this.regionProgram), this.context.uniform2f(this.regionTimeWindowLocation, this.startTime, this.endTime), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.regionPositionBuffer), this.context.vertexAttribPointer(this.regionPositionLocation, 2, this.context.FLOAT, !1, 0, 0), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.regionColorBuffer), this.context.vertexAttribPointer(this.regionColorLocation, 4, this.context.FLOAT, !1, 0, 0), this.context.bindBuffer(this.context.ELEMENT_ARRAY_BUFFER, this.regionIndexBuffer), this.context.drawElements(this.context.TRIANGLES, this.regionIndices.length, this.context.UNSIGNED_SHORT, 0))
                }, e.prototype.createContext = function() {
                    try {
                        this.context = this.canvas.getContext("webgl", {
                            preserveDrawingBuffer: !0,
                            premultipliedAlpha: !1
                        }), this.context.enable(this.context.BLEND), this.context.blendFunc(this.context.SRC_ALPHA, this.context.ONE_MINUS_SRC_ALPHA)
                    } catch (t) {
                        throw "Failed to initialize webgl context"
                    }
                }, e.prototype.setDefaults = function() {
                    this.waveformColor = 16448250, this.sampleScale = 1, this.height = 150, this.width = 300
                }, e.prototype.useProgram = function(t) {
                    this.currentProgram !== t && (this.context.useProgram(t), this.currentProgram = t)
                }, e.prototype.setupWavformProgram = function() {
                    this.waveformProgram = this.createProgram(s.WaveformVS, s.WaveformFS), this.useProgram(this.waveformProgram), this.waveformSampleDataLocation = this.context.getAttribLocation(this.waveformProgram, "aSampleData"), this.waveformSampleIndexLocation = this.context.getAttribLocation(this.waveformProgram, "aSampleIndex"), this.waveformSampleColorLocation = this.context.getAttribLocation(this.waveformProgram, "aSampleColor"), this.waveformTimeWindowLocation = this.context.getUniformLocation(this.waveformProgram, "uTimeWindow"), this.waveformSampleRateLocation = this.context.getUniformLocation(this.waveformProgram, "uSampleRate"), this.waveformSampleScaleLocation = this.context.getUniformLocation(this.waveformProgram, "uSampleScale"), this.waveformColorLocation = this.context.getUniformLocation(this.waveformProgram, "uWaveformColor"), this.waveformUseSampleColorsLocation = this.context.getUniformLocation(this.waveformProgram, "uUseSampleColors"), this.context.enableVertexAttribArray(this.waveformSampleDataLocation), this.context.enableVertexAttribArray(this.waveformSampleIndexLocation), this.sampleDataBuffer = this.context.createBuffer(), this.sampleIndexBuffer = this.context.createBuffer(), this.sampleColorBuffer = this.context.createBuffer()
                }, e.prototype.setupMarkerProgram = function() {
                    this.markerProgram = this.createProgram(s.MarkerVS, s.MarkerFS), this.useProgram(this.markerProgram), this.markerPositionLocation = this.context.getAttribLocation(this.markerProgram, "aPosition"), this.markerColorLocation = this.context.getAttribLocation(this.markerProgram, "aColor"), this.markerTimeWindowLocation = this.context.getUniformLocation(this.markerProgram, "uTimeWindow"), this.context.enableVertexAttribArray(this.markerPositionLocation), this.context.enableVertexAttribArray(this.markerColorLocation), this.markerPositionBuffer = this.context.createBuffer(), this.markerColorBuffer = this.context.createBuffer()
                }, e.prototype.setupRegionProgram = function() {
                    this.regionProgram = this.createProgram(s.RegionVS, s.RegionFS), this.useProgram(this.regionProgram), this.regionPositionLocation = this.context.getAttribLocation(this.regionProgram, "aPosition"), this.regionColorLocation = this.context.getAttribLocation(this.regionProgram, "aColor"), this.regionTimeWindowLocation = this.context.getUniformLocation(this.regionProgram, "uTimeWindow"), this.context.enableVertexAttribArray(this.regionPositionLocation), this.context.enableVertexAttribArray(this.regionColorLocation), this.regionPositionBuffer = this.context.createBuffer(), this.regionIndexBuffer = this.context.createBuffer(), this.regionColorBuffer = this.context.createBuffer()
                }, e.prototype.mapValue = function(t, e, r, n, o) {
                    return n + (t - e) / (r - e) * (o - n)
                }, e.prototype.zoomCurve = function(t) {
                    return 1 + --t * t * t * t * t
                }, e.prototype.getLocalPointFromMouseEvent = function(t) {
                    var e = this.canvas.getBoundingClientRect();
                    return {
                        x: t.clientX - e.left,
                        y: t.clientY - e.top
                    }
                }, e.prototype.invalidate = function() {
                    this.nextTick(this.scheduleRender)
                }, e.prototype.bindEventHandlers = function() {
                    this.canvas.addEventListener("click", this.onClick)
                }, e.prototype.dispatchInteractEvent = function(t) {
                    this.dispatchEvent(new CustomEvent(t, {
                        detail: {
                            originalEvent: this.lastInteractionEvent,
                            velocity: "scroll" === t ? this.scrollVelocity : this.zoomVelocity,
                            zoomLevel: this.zoomLevel,
                            startTime: this.startTime,
                            endTime: this.endTime
                        }
                    }))
                }, e.prototype.dispatchTimeChangeEvent = function() {
                    this.dispatchEvent(new CustomEvent("change", {
                        detail: {
                            startTime: this.startTime,
                            endTime: this.endTime
                        }
                    }))
                }, e.prototype.createShader = function(t, e) {
                    var r = this.context.createShader(t);
                    if (this.context.shaderSource(r, e), this.context.compileShader(r), !this.context.getShaderParameter(r, this.context.COMPILE_STATUS)) throw this.context.getShaderInfoLog(r);
                    return r
                }, e.prototype.createProgram = function(t, e) {
                    var r = this.createShader(this.context.VERTEX_SHADER, t),
                        n = this.createShader(this.context.FRAGMENT_SHADER, e),
                        o = this.context.createProgram();
                    if (this.context.attachShader(o, r), this.context.attachShader(o, n), this.context.linkProgram(o), !this.context.getProgramParameter(o, this.context.LINK_STATUS)) throw this.context.getProgramInfoLog(o);
                    return o
                }, e.prototype.disableRender = function() {
                    this.canRender = !1
                }, e.prototype.enableRender = function() {
                    this.canRender = !0
                }, e.prototype.scheduleWaveformRefresh = function() {
                    clearTimeout(this.waveformRefreshTimeoutId), this.waveformRefreshTimeoutId = this.nextTick(this.refreshWaveform)
                }, e.prototype.scheduleMarkerRefresh = function() {
                    clearTimeout(this.markerRefreshTimeoutId), this.markerRefreshTimeoutId = this.nextTick(this.refreshMarkers)
                }, e.prototype.scheduleRegionRefresh = function() {
                    clearTimeout(this.regionRefreshTimeoutId), this.regionRefreshTimeoutId = this.nextTick(this.refreshRegions)
                }, e.prototype.scheduleRender = function() {
                    cancelAnimationFrame(this.renderRequestId), this.renderRequestId = requestAnimationFrame(this.render)
                }, e.prototype.nextTick = function(t) {
                    return setTimeout(t, 0)
                }, e.prototype.refreshWaveform = function() {
                    return i(this, void 0, void 0, (function() {
                        return a(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return this.disableRender(), this.source ? [4, this.refreshSampleData()] : [3, 5];
                                case 1:
                                    return t.sent(), [4, this.refreshSampleIndex()];
                                case 2:
                                    return t.sent(), [4, this.refreshSampleColors()];
                                case 3:
                                    return t.sent(), [4, this.refreshWaveformBuffers()];
                                case 4:
                                    return t.sent(), this.enableRender(), this.scheduleRender(), [3, 6];
                                case 5:
                                    this.scheduleWaveformRefresh(), t.label = 6;
                                case 6:
                                    return [2]
                            }
                        }))
                    }))
                }, e.prototype.refreshMarkers = function() {
                    return i(this, void 0, void 0, (function() {
                        var t, e, r = this;
                        return a(this, (function(n) {
                            return t = [], e = [], this.markers.forEach((function(n) {
                                var o = n.seconds,
                                    i = n.color,
                                    a = r.decimalColorToNormalizedRGBArray(i),
                                    s = a[0],
                                    c = a[1],
                                    u = a[2];
                                t.push(o, 1, o, -1), e.push(s, c, u, s, c, u)
                            })), this.markerPositions = new Float32Array(t), this.markerColors = new Float32Array(e), this.useProgram(this.markerProgram), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.markerPositionBuffer), this.context.bufferData(this.context.ARRAY_BUFFER, this.markerPositions, this.context.STATIC_DRAW), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.markerColorBuffer), this.context.bufferData(this.context.ARRAY_BUFFER, this.markerColors, this.context.STATIC_DRAW), this.scheduleRender(), [2]
                        }))
                    }))
                }, e.prototype.refreshRegions = function() {
                    return i(this, void 0, void 0, (function() {
                        var t, e, r, n, o = this;
                        return a(this, (function(i) {
                            return t = [], e = [], r = [], n = 0, this.regions.forEach((function(i) {
                                var a = i.secondsStart,
                                    s = i.secondsEnd,
                                    c = i.color,
                                    u = i.alpha,
                                    l = o.decimalColorToNormalizedRGBArray(c),
                                    h = l[0],
                                    f = l[1],
                                    p = l[2];
                                t.push(a, 1, a, -1, s, 1, s, -1), e.push(n, n + 1, n + 2, n + 2, n + 1, n + 3), r.push(h, f, p, u, h, f, p, u, h, f, p, u, h, f, p, u), n += 4
                            })), this.regionPositions = new Float32Array(t), this.regionIndices = new Uint16Array(e), this.regionColors = new Float32Array(r), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.regionPositionBuffer), this.context.bufferData(this.context.ARRAY_BUFFER, this.regionPositions, this.context.STATIC_DRAW), this.context.bindBuffer(this.context.ELEMENT_ARRAY_BUFFER, this.regionIndexBuffer), this.context.bufferData(this.context.ELEMENT_ARRAY_BUFFER, this.regionIndices, this.context.STATIC_DRAW), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.regionColorBuffer), this.context.bufferData(this.context.ARRAY_BUFFER, this.regionColors, this.context.STATIC_DRAW), this.scheduleRender(), [2]
                        }))
                    }))
                }, e.prototype.refreshSampleData = function() {
                    return i(this, void 0, void 0, (function() {
                        var t, e, r;
                        return a(this, (function(n) {
                            switch (n.label) {
                                case 0:
                                    return n.trys.push([0, 2, , 3]), t = new OfflineAudioContext(1, this.totalSamples, this.sampleRate), (e = t.createBufferSource()).buffer = this.source, e.connect(t.destination), e.start(), [4, t.startRendering()];
                                case 1:
                                    return r = n.sent(), this.sampleData = r.getChannelData(0), [3, 3];
                                case 2:
                                    return n.sent(), console.warn("Failed to create sample data at " + this.sampleData + "Hz"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                }, e.prototype.refreshSampleIndex = function() {
                    return i(this, void 0, void 0, (function() {
                        var t;
                        return a(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return t = this, [4, c.generateIndexArray.run(this.totalSamples)];
                                case 1:
                                    return t.sampleIndex = e.sent(), [2]
                            }
                        }))
                    }))
                }, e.prototype.refreshSampleColors = function() {
                    return i(this, void 0, void 0, (function() {
                        return a(this, (function(t) {
                            return this.sampleColors = new Float32Array(3 * this.totalSamples), [2]
                        }))
                    }))
                }, e.prototype.refreshWaveformBuffers = function() {
                    return i(this, void 0, void 0, (function() {
                        return a(this, (function(t) {
                            return this.useProgram(this.waveformProgram), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.sampleDataBuffer), this.context.bufferData(this.context.ARRAY_BUFFER, this.sampleData, this.context.STATIC_DRAW), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.sampleIndexBuffer), this.context.bufferData(this.context.ARRAY_BUFFER, this.sampleIndex, this.context.STATIC_DRAW), this.context.bindBuffer(this.context.ARRAY_BUFFER, this.sampleColorBuffer), this.context.bufferData(this.context.ARRAY_BUFFER, this.sampleColors, this.context.STATIC_DRAW), [2]
                        }))
                    }))
                }, e.prototype.updateTouchPhysics = function() {
                    cancelAnimationFrame(this.touchPhysicsRequestId), (this.isPanning || this.isZooming) && (this.touchPhysicsRequestId = requestAnimationFrame(this.updateTouchPhysics), this.isPanning && (this.scrollVelocity *= 1 - this.scrollFriction, this.scrollFromVelocity()), this.isZooming && (this.zoomVelocity *= 1 - this.zoomFriction, this.zoomFromVelocity()))
                }, e.prototype.scrollFromVelocity = function() {
                    this.scrollBySeconds(this.scrollVelocity / this.pixelsPerSecond), this.dispatchInteractEvent("scroll")
                }, e.prototype.zoomFromVelocity = function(t) {
                    void 0 === t && (t = this.getSecondsAtPoint(this.dragZoomOrigin.x)), this.zoom(this.zoomT + 6e-4 * this.zoomVelocity, t), this.dispatchInteractEvent("zoom")
                }, e.prototype.decimalColorToNormalizedRGBArray = function(t) {
                    return [((16711680 & t) >> 16) / 255, ((65280 & t) >> 8) / 255, (255 & t) / 255]
                }, e.prototype.hsvColorToNormalizedRGBArray = function(t, e, r) {
                    var n = Math.floor(6 * t),
                        o = 6 * t - n,
                        i = r * (1 - e),
                        a = r * (1 - o * e),
                        s = r * (1 - (1 - o) * e);
                    switch (n % 6) {
                        case 0:
                            return [r, s, i];
                        case 1:
                            return [a, r, i];
                        case 2:
                            return [i, r, s];
                        case 3:
                            return [i, a, r];
                        case 4:
                            return [s, i, r];
                        case 5:
                            return [r, i, a]
                    }
                }, e.prototype.createNormalizer = function(t, e) {
                    var r = t.map(e),
                        n = Math.min.apply(null, r),
                        o = Math.max.apply(null, r) - n;
                    return function(t) {
                        return (t - n) / o
                    }
                }, e.prototype.isDominantAxisX = function(t, e) {
                    return Math.abs(t) > Math.abs(e)
                }, e.prototype.onTouchStart = function(t) {
                    this.lastInteractionEvent = t, cancelAnimationFrame(this.touchPhysicsRequestId), document.addEventListener("mousemove", this.onTouchMove), document.addEventListener("touchmove", this.onTouchMove), document.addEventListener("mouseleave", this.onTouchEnd), document.addEventListener("touchend", this.onTouchEnd), document.addEventListener("mouseup", this.onTouchEnd), this.dragZoomOrigin = this.getLocalPointFromMouseEvent(t), this.scrollVelocity = 0, this.zoomVelocity = 0, this.lastTouchX = t.clientX, this.lastTouchY = t.clientY
                }, e.prototype.onTouchMove = function(t) {
                    this.lastInteractionEvent = t, this.scrollVelocity = -(t.clientX - this.lastTouchX), this.zoomVelocity = -(t.clientY - this.lastTouchY), this.lastTouchX = t.clientX, this.lastTouchY = t.clientY, this.isDominantAxisX(this.scrollVelocity, this.zoomVelocity) ? this.scrollFromVelocity() : this.zoomFromVelocity()
                }, e.prototype.onTouchEnd = function(t) {
                    this.lastInteractionEvent = t, document.removeEventListener("mousemove", this.onTouchMove), document.removeEventListener("touchmove", this.onTouchMove), document.removeEventListener("mouseleave", this.onTouchEnd), document.removeEventListener("touchend", this.onTouchEnd), document.removeEventListener("mouseup", this.onTouchEnd), this.isDominantAxisX(this.scrollVelocity, this.zoomVelocity) ? this.zoomVelocity = 0 : this.scrollVelocity = 0, this.updateTouchPhysics()
                }, e.prototype.onWheel = function(t) {
                    this.lastInteractionEvent = t, t.preventDefault(), this.isDominantAxisX(t.deltaX, t.deltaY) ? (this.scrollVelocity = t.deltaX, this.scrollBySeconds(this.scrollVelocity / this.pixelsPerSecond), this.dispatchInteractEvent("scroll")) : (this.zoomVelocity = t.deltaY, this.zoomFromVelocity(this.getSecondsAtPoint(this.getLocalPointFromMouseEvent(t).x)))
                }, e.prototype.onClick = function(t) {
                    if (!this.isPanning && !this.isZooming && (t.preventDefault(), this.canRender)) {
                        var e = this.getLocalPointFromMouseEvent(t);
                        this.dispatchEvent(new CustomEvent("click", {
                            detail: {
                                originalEvent: t,
                                seconds: this.getSecondsAtPoint(e.x),
                                sampleIndex: this.getSampleIndexAtPoint(e.x),
                                sampleData: this.getSampleDataAtPoint(e.x)
                            }
                        }))
                    }
                }, e.audioContext = new AudioContext, o([u.accessor(0), u.invalidate()], e.prototype, "width", null), o([u.accessor(0), u.invalidate()], e.prototype, "height", null), o([u.accessor(0), u.invalidate()], e.prototype, "startTime", null), o([u.accessor(0), u.invalidate()], e.prototype, "endTime", null), o([u.accessor(0), u.invalidate()], e.prototype, "sampleRate", null), o([u.accessor(0), u.invalidate()], e.prototype, "sampleScale", null), o([u.accessor(), u.invalidate()], e.prototype, "source", null), o([u.accessor(), u.invalidate()], e.prototype, "backgroundColor", null), o([u.accessor(), u.invalidate()], e.prototype, "waveformColor", null), o([u.accessor(!1)], e.prototype, "interactive", null), e = r = o([h.autobind], e)
            }(l.default);
            e.default = f
        },
        48471: function(t, e) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.accessor = function(t) {
                return function(e, r, n) {
                    var o = new Map,
                        i = n.set;
                    n.configurable = !0, n.enumerable = !0, n.get = function() {
                        return t
                    }, n.set = function(t) {
                        Object.defineProperty(this, r, {
                            enumerable: !0,
                            get: function() {
                                return o.get(this)
                            },
                            set: function(t) {
                                o.set(this, t), i.call(this, t)
                            }
                        }), this[r] = t
                    }
                }
            }, e.invalidate = function() {
                return function(t, e, r) {
                    var n = r.set;
                    r.set = function(e) {
                        n && n.call(this, e), t.invalidate.call(this)
                    }
                }
            }
        },
        11293: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var n = r(51768);
            e.default = n.default
        },
        44639: function(t, e) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = "\n  float map(float n, float a, float b, float x, float y) {\n    return x + ((n - a) / (b - a) * (y - x));\n  }\n";
            e.WaveformVS = "\n  " + r + "\n  uniform int uSampleRate;\n  uniform float uSampleScale;\n  uniform vec2 uTimeWindow;\n  uniform vec3 uWaveformColor;\n  uniform bool uUseSampleColors;\n  attribute float aSampleData;\n  attribute float aSampleIndex;\n  attribute vec3 aSampleColor;\n  varying lowp vec3 vColor;\n  void main() {\n    vec2 sampleRange = uTimeWindow * float(uSampleRate);\n    float x = map(aSampleIndex, sampleRange.x, sampleRange.y, -1.0, 1.0);\n    gl_Position = vec4(x, aSampleData * uSampleScale, 0.0, 1.0);\n    vColor = uUseSampleColors ? aSampleColor : uWaveformColor;\n  }\n", e.WaveformFS = "\n  precision mediump float;\n  varying lowp vec3 vColor;\n  void main() {\n    gl_FragColor = vec4(vColor, 1.0);\n  }\n", e.MarkerVS = "\n  " + r + "\n  uniform vec2 uTimeWindow;\n  attribute vec2 aPosition;\n  attribute vec3 aColor;\n  varying lowp vec3 vColor;\n  void main() {\n    float x = map(aPosition.x, uTimeWindow.x, uTimeWindow.y, -1.0, 1.0);\n    vColor = aColor;\n    gl_Position = vec4(x, aPosition.y, 0.0, 1.0);\n  }\n", e.MarkerFS = "\n  precision mediump float;\n  varying lowp vec3 vColor;\n  void main() {\n    gl_FragColor = vec4(vColor, 1.0);\n  }\n", e.RegionVS = "\n  " + r + "\n  uniform vec2 uTimeWindow;\n  attribute vec2 aPosition;\n  attribute vec4 aColor;\n  varying lowp vec4 vColor;\n  void main() {\n    float x = map(aPosition.x, uTimeWindow.x, uTimeWindow.y, -1.0, 1.0);\n    vColor = aColor;\n    gl_Position = vec4(x, aPosition.y, 0.0, 1.0);\n  }\n", e.RegionFS = "\n  precision mediump float;\n  varying lowp vec4 vColor;\n  void main() {\n    gl_FragColor = vColor;\n  }\n"
        },
        1963: function(t, e, r) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var n = r(13449);
            e.generateIndexArray = new n.default((function(t, e) {
                for (var r = new Float32Array(t), n = 0; n < r.length; r[n] = n++);
                e(r)
            }))
        },
        11103: function(t, e, r) {
            "use strict";
            r.r(e), r.d(e, {
                applyDecorators: function() {
                    return ee
                },
                autobind: function() {
                    return lt
                },
                debounce: function() {
                    return At
                },
                decorate: function() {
                    return kt
                },
                deprecate: function() {
                    return K
                },
                deprecated: function() {
                    return K
                },
                enumerable: function() {
                    return dt
                },
                extendDescriptor: function() {
                    return qt
                },
                lazyInitialize: function() {
                    return i
                },
                memoize: function() {
                    return rt
                },
                mixin: function() {
                    return jt
                },
                mixins: function() {
                    return jt
                },
                nonconfigurable: function() {
                    return gt
                },
                nonenumerable: function() {
                    return yt
                },
                override: function() {
                    return W
                },
                profile: function() {
                    return Jt
                },
                readonly: function() {
                    return ft
                },
                suppressWarnings: function() {
                    return $
                },
                throttle: function() {
                    return _t
                },
                time: function() {
                    return Vt
                }
            });
            var n = Object.defineProperty;

            function o(t, e, r) {
                var o = r.configurable,
                    i = r.enumerable,
                    a = r.initializer,
                    s = r.value;
                return {
                    configurable: o,
                    enumerable: i,
                    get: function() {
                        if (this !== t) {
                            var r = a ? a.call(this) : s;
                            return n(this, e, {
                                configurable: o,
                                enumerable: i,
                                writable: !0,
                                value: r
                            }), r
                        }
                    },
                    set: _(e)
                }
            }

            function i() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(o, e)
            }
            var a, s, c, u, l, h, f = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" === typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            };

            function p(t, e, r, n) {
                r && Object.defineProperty(t, e, {
                    enumerable: r.enumerable,
                    configurable: r.configurable,
                    writable: r.writable,
                    value: r.initializer ? r.initializer.call(n) : void 0
                })
            }

            function d(t, e, r, n, o) {
                var i = {};
                return Object.keys(n).forEach((function(t) {
                    i[t] = n[t]
                })), i.enumerable = !!i.enumerable, i.configurable = !!i.configurable, ("value" in i || i.initializer) && (i.writable = !0), i = r.slice().reverse().reduce((function(r, n) {
                    return n(t, e, r) || r
                }), i), o && void 0 !== i.initializer && (i.value = i.initializer ? i.initializer.call(o) : void 0, i.initializer = void 0), void 0 === i.initializer && (Object.defineProperty(t, e, i), i = null), i
            }

            function m(t) {
                if (Array.isArray(t)) {
                    for (var e = 0, r = Array(t.length); e < t.length; e++) r[e] = t[e];
                    return r
                }
                return Array.from(t)
            }
            var y = Object.defineProperty,
                v = Object.getOwnPropertyDescriptor,
                g = Object.getOwnPropertyNames,
                b = Object.getOwnPropertySymbols;

            function w(t, e) {
                return function(t) {
                    if (!t || !t.hasOwnProperty) return !1;
                    for (var e = ["value", "initializer", "get", "set"], r = 0, n = e.length; r < n; r++)
                        if (t.hasOwnProperty(e[r])) return !0;
                    return !1
                }(e[e.length - 1]) ? t.apply(void 0, m(e).concat([
                    []
                ])) : function() {
                    return t.apply(void 0, m(Array.prototype.slice.call(arguments)).concat([e]))
                }
            }
            var x = (a = function t() {
                    ! function(t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, t), p(this, "debounceTimeoutIds", s, this), p(this, "throttleTimeoutIds", c, this), p(this, "throttlePreviousTimestamps", u, this), p(this, "throttleTrailingArgs", l, this), p(this, "profileLastRan", h, this)
                }, s = d(a.prototype, "debounceTimeoutIds", [i], {
                    enumerable: !0,
                    initializer: function() {
                        return {}
                    }
                }), c = d(a.prototype, "throttleTimeoutIds", [i], {
                    enumerable: !0,
                    initializer: function() {
                        return {}
                    }
                }), u = d(a.prototype, "throttlePreviousTimestamps", [i], {
                    enumerable: !0,
                    initializer: function() {
                        return {}
                    }
                }), l = d(a.prototype, "throttleTrailingArgs", [i], {
                    enumerable: !0,
                    initializer: function() {
                        return null
                    }
                }), h = d(a.prototype, "profileLastRan", [i], {
                    enumerable: !0,
                    initializer: function() {
                        return null
                    }
                }), a),
                A = "function" === typeof Symbol ? Symbol("__core_decorators__") : "__core_decorators__";

            function P(t) {
                return !1 === t.hasOwnProperty(A) && y(t, A, {
                    value: new x
                }), t[A]
            }
            var R = b ? function(t) {
                return g(t).concat(b(t))
            } : g;

            function T(t) {
                var e = {};
                return R(t).forEach((function(r) {
                    return e[r] = v(t, r)
                })), e
            }

            function _(t) {
                return function(e) {
                    return Object.defineProperty(this, t, {
                        configurable: !0,
                        writable: !0,
                        enumerable: !0,
                        value: e
                    }), e
                }
            }

            function S(t, e) {
                return t.bind ? t.bind(e) : function() {
                    return t.apply(e, arguments)
                }
            }
            var E = "object" === ("undefined" === typeof console ? "undefined" : f(console)) && console && "function" === typeof console.warn ? S(console.warn, console) : function() {},
                k = {};

            function O(t) {
                !0 !== k[t] && (k[t] = !0, E("DEPRECATION: " + t))
            }
            var C = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" === typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                },
                F = function() {
                    function t(t, e) {
                        for (var r = 0; r < e.length; r++) {
                            var n = e[r];
                            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n)
                        }
                    }
                    return function(e, r, n) {
                        return r && t(e.prototype, r), n && t(e, n), e
                    }
                }();
            var B = "{child} does not properly override {parent}",
                L = /^function ([_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*)?(\([^\)]*\))[\s\S]+$/,
                j = function() {
                    function t(e, r, n, o) {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), this.parentKlass = e, this.childKlass = r, this.parentDescriptor = n, this.childDescriptor = o
                    }
                    return F(t, [{
                        key: "_getTopic",
                        value: function(t) {
                            return void 0 === t ? null : "value" in t ? t.value : "get" in t ? t.get : "set" in t ? t.set : void 0
                        }
                    }, {
                        key: "_extractTopicSignature",
                        value: function(t) {
                            return "function" === ("undefined" === typeof t ? "undefined" : C(t)) ? this._extractFunctionSignature(t) : this.key
                        }
                    }, {
                        key: "_extractFunctionSignature",
                        value: function(t) {
                            var e = this;
                            return t.toString().replace(L, (function(t) {
                                var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : e.key,
                                    n = arguments[2];
                                return r + n
                            }))
                        }
                    }, {
                        key: "key",
                        get: function() {
                            return this.childDescriptor.key
                        }
                    }, {
                        key: "parentNotation",
                        get: function() {
                            return this.parentKlass.constructor.name + "#" + this.parentPropertySignature
                        }
                    }, {
                        key: "childNotation",
                        get: function() {
                            return this.childKlass.constructor.name + "#" + this.childPropertySignature
                        }
                    }, {
                        key: "parentTopic",
                        get: function() {
                            return this._getTopic(this.parentDescriptor)
                        }
                    }, {
                        key: "childTopic",
                        get: function() {
                            return this._getTopic(this.childDescriptor)
                        }
                    }, {
                        key: "parentPropertySignature",
                        get: function() {
                            return this._extractTopicSignature(this.parentTopic)
                        }
                    }, {
                        key: "childPropertySignature",
                        get: function() {
                            return this._extractTopicSignature(this.childTopic)
                        }
                    }]), F(t, [{
                        key: "assert",
                        value: function(t) {
                            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                            !0 !== t && this.error(B + e)
                        }
                    }, {
                        key: "error",
                        value: function(t) {
                            var e = this;
                            throw t = t.replace("{parent}", (function(t) {
                                return e.parentNotation
                            })).replace("{child}", (function(t) {
                                return e.childNotation
                            })), new SyntaxError(t)
                        }
                    }]), t
                }();

            function M(t) {
                return t.hasOwnProperty("value") ? "data" : t.hasOwnProperty("get") || t.hasOwnProperty("set") ? "accessor" : "data"
            }

            function I(t, e, r) {
                r.assert(t.length === e.length)
            }

            function D(t, e, r) {
                var n = M(t),
                    o = M(e);
                switch (n !== o && r.error('descriptor types do not match. {parent} is "' + n + '", {child} is "' + o + '"'), o) {
                    case "data":
                        ! function(t, e, r) {
                            var n = C(t.value),
                                o = C(e.value);
                            "undefined" === n && "undefined" === o && r.error("descriptor values are both undefined. (class properties are are not currently supported)'"), n !== o && ("function" === o && void 0 === n || void 0 !== n) && r.error('value types do not match. {parent} is "' + n + '", {child} is "' + o + '"'), "function" === o ? I(t.value, e.value, r) : r.error('Unexpected error. Please file a bug with: {parent} is "' + n + '", {child} is "' + o + '"')
                        }(t, e, r);
                        break;
                    case "accessor":
                        ! function(t, e, r) {
                            var n = "function" === typeof t.get,
                                o = "function" === typeof e.get,
                                i = "function" === typeof t.set,
                                a = "function" === typeof e.set;
                            (n || o) && (!n && i && r.error("{parent} is setter but {child} is getter"), !o && a && r.error("{parent} is getter but {child} is setter"), I(t.get, e.get, r)), (i || a) && (!i && n && r.error("{parent} is getter but {child} is setter"), !a && o && r.error("{parent} is setter but {child} is getter"), I(t.set, e.set, r))
                        }(t, e, r)
                }
            }
            var z = [function(t) {
                return t.toLowerCase()
            }, function(t) {
                return t.toUpperCase()
            }, function(t) {
                return t + "s"
            }, function(t) {
                return t.slice(0, -1)
            }, function(t) {
                return t.slice(1, t.length)
            }];

            function U(t, e, r) {
                r.key = e;
                var n = Object.getPrototypeOf(t),
                    o = Object.getOwnPropertyDescriptor(n, e),
                    i = new j(n, t, o, r);
                if (void 0 === o) {
                    var a = function(t, e) {
                            for (var r = 0, n = z.length; r < n; r++) {
                                var o = (0, z[r])(e);
                                if (o in t) return o
                            }
                            return null
                        }(n, e),
                        s = a ? '\n\n  Did you mean "' + a + '"?' : "";
                    i.error("No descriptor matching {child} was found on the prototype chain." + s)
                }
                return D(o, r, i), r
            }

            function W() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(U, e)
            }
            var V = Object.assign || function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                },
                Y = function(t, e) {
                    if (Array.isArray(t)) return t;
                    if (Symbol.iterator in Object(t)) return function(t, e) {
                        var r = [],
                            n = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, s = t[Symbol.iterator](); !(n = (a = s.next()).done) && (r.push(a.value), !e || r.length !== e); n = !0);
                        } catch (c) {
                            o = !0, i = c
                        } finally {
                            try {
                                !n && s.return && s.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return r
                    }(t, e);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance")
                };

            function N(t, e, r, n) {
                var o = Y(n, 2),
                    i = o[0],
                    a = void 0 === i ? "This function will be removed in future versions." : i,
                    s = o[1],
                    c = void 0 === s ? {} : s;
                if ("function" !== typeof r.value) throw new SyntaxError("Only functions can be marked as deprecated");
                var u = t.constructor.name + "#" + e;
                return c.url && (a += "\n\n    See " + c.url + " for more details.\n\n"), V({}, r, {
                    value: function() {
                        return E("DEPRECATION " + u + ": " + a), r.value.apply(this, arguments)
                    }
                })
            }

            function K() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(N, e)
            }
            var X = Object.assign || function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                },
                q = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" === typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                };

            function G() {}

            function H(t, e, r) {
                if ("object" === ("undefined" === typeof console ? "undefined" : q(console))) {
                    var n = console.warn;
                    console.warn = G;
                    var o = e.apply(t, r);
                    return console.warn = n, o
                }
                return e.apply(t, r)
            }

            function Z(t, e, r) {
                return X({}, r, {
                    value: function() {
                        return H(this, r.value, arguments)
                    }
                })
            }

            function $() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(Z, e)
            }
            var J = Object.assign || function(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var r = arguments[e];
                    for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                }
                return t
            };

            function Q(t, e) {
                return e === Object(e) ? e : t[e] || (t[e] = {})
            }

            function tt(t, e, r, n, o) {
                var i = e.apply(t, r);
                return n[o] = i, i
            }

            function et(t, e, r) {
                var n = function(t) {
                        var e = void 0,
                            r = void 0;
                        return t.value ? (e = t.value, r = "value") : t.get ? (e = t.get, r = "get") : t.set && (e = t.set, r = "set"), {
                            fn: e,
                            wrapKey: r
                        }
                    }(r),
                    o = n.fn,
                    i = n.wrapKey,
                    a = new WeakMap,
                    s = Object.create(null),
                    c = Object.create(null),
                    u = 0;
                return J({}, r, function(t, e, r) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = r, t
                }({}, i, (function() {
                    for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                    for (var n = "0", i = 0, l = e.length; i < l; i++) {
                        var h = e[i],
                            f = Q(c, h),
                            p = a.get(f);
                        void 0 === p && (p = ++u, a.set(f, p)), n += p
                    }
                    return s[n] || tt(this, o, arguments, s, n)
                })))
            }

            function rt() {
                O("@memoize is deprecated and will be removed shortly. Use @memoize from lodash-decorators.\n\n  https://www.npmjs.com/package/lodash-decorators");
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(et, e)
            }

            function nt(t) {
                if (Array.isArray(t)) {
                    for (var e = 0, r = Array(t.length); e < t.length; e++) r[e] = t[e];
                    return r
                }
                return Array.from(t)
            }
            var ot = Object.defineProperty,
                it = Object.getPrototypeOf,
                at = void 0;

            function st(t) {
                for (var e = T(t.prototype), r = R(e), n = 0, o = r.length; n < o; n++) {
                    var i = r[n],
                        a = e[i];
                    "function" === typeof a.value && "constructor" !== i && ot(t.prototype, i, ct(t.prototype, i, a))
                }
            }

            function ct(t, e, r) {
                var n = r.value,
                    o = r.configurable,
                    i = r.enumerable;
                if ("function" !== typeof n) throw new SyntaxError("@autobind can only be used on functions, not: " + n);
                var a = t.constructor;
                return {
                    configurable: o,
                    enumerable: i,
                    get: function() {
                        if (this === t) return n;
                        if (this.constructor !== a && it(this).constructor === a) return n;
                        if (this.constructor !== a && e in this.constructor.prototype) return function(t, e) {
                            if ("undefined" === typeof WeakMap) throw new Error("Using @autobind on " + e.name + "() requires WeakMap support due to its use of super." + e.name + "()\n      See https://github.com/jayphelps/core-decorators.js/issues/20");
                            at || (at = new WeakMap), !1 === at.has(t) && at.set(t, new WeakMap);
                            var r = at.get(t);
                            return !1 === r.has(e) && r.set(e, S(e, t)), r.get(e)
                        }(this, n);
                        var r = S(n, this);
                        return ot(this, e, {
                            configurable: !0,
                            writable: !0,
                            enumerable: !1,
                            value: r
                        }), r
                    },
                    set: _(e)
                }
            }

            function ut(t) {
                return 1 === t.length ? st.apply(void 0, nt(t)) : ct.apply(void 0, nt(t))
            }

            function lt() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return 0 === e.length ? function() {
                    return ut(arguments)
                } : ut(e)
            }

            function ht(t, e, r) {
                return r.writable = !1, r
            }

            function ft() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(ht, e)
            }

            function pt(t, e, r) {
                return r.enumerable = !0, r
            }

            function dt() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(pt, e)
            }

            function mt(t, e, r) {
                return r.enumerable = !1, r
            }

            function yt() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(mt, e)
            }

            function vt(t, e, r) {
                return r.configurable = !1, r
            }

            function gt() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(vt, e)
            }
            var bt = Object.assign || function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                },
                wt = function(t, e) {
                    if (Array.isArray(t)) return t;
                    if (Symbol.iterator in Object(t)) return function(t, e) {
                        var r = [],
                            n = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, s = t[Symbol.iterator](); !(n = (a = s.next()).done) && (r.push(a.value), !e || r.length !== e); n = !0);
                        } catch (c) {
                            o = !0, i = c
                        } finally {
                            try {
                                !n && s.return && s.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return r
                    }(t, e);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance")
                };

            function xt(t, e, r, n) {
                var o = wt(n, 2),
                    i = o[0],
                    a = void 0 === i ? 300 : i,
                    s = o[1],
                    c = void 0 !== s && s,
                    u = r.value;
                if ("function" !== typeof u) throw new SyntaxError("Only functions can be debounced");
                return bt({}, r, {
                    value: function() {
                        var t = this,
                            r = P(this),
                            n = r.debounceTimeoutIds,
                            o = n[e],
                            i = c && !o,
                            s = arguments;
                        clearTimeout(o), n[e] = setTimeout((function() {
                            delete n[e], c || u.apply(t, s)
                        }), a), i && u.apply(this, s)
                    }
                })
            }

            function At() {
                O("@debounce is deprecated and will be removed shortly. Use @debounce from lodash-decorators.\n\n  https://www.npmjs.com/package/lodash-decorators");
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(xt, e)
            }
            var Pt = Object.assign || function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                },
                Rt = function(t, e) {
                    if (Array.isArray(t)) return t;
                    if (Symbol.iterator in Object(t)) return function(t, e) {
                        var r = [],
                            n = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, s = t[Symbol.iterator](); !(n = (a = s.next()).done) && (r.push(a.value), !e || r.length !== e); n = !0);
                        } catch (c) {
                            o = !0, i = c
                        } finally {
                            try {
                                !n && s.return && s.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return r
                    }(t, e);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance")
                };

            function Tt(t, e, r, n) {
                var o = Rt(n, 2),
                    i = o[0],
                    a = void 0 === i ? 300 : i,
                    s = o[1],
                    c = void 0 === s ? {} : s,
                    u = r.value;
                if ("function" !== typeof u) throw new SyntaxError("Only functions can be throttled");
                return !1 !== c.leading && (c.leading = !0), !1 !== c.trailing && (c.trailing = !0), Pt({}, r, {
                    value: function() {
                        var t = this,
                            r = P(this),
                            n = r.throttleTimeoutIds,
                            o = r.throttlePreviousTimestamps,
                            i = n[e],
                            s = o[e] || 0,
                            l = Date.now();
                        c.trailing && (r.throttleTrailingArgs = arguments), s || !1 !== c.leading || (s = l);
                        var h = a - (l - s);
                        h <= 0 ? (clearTimeout(i), delete n[e], o[e] = l, u.apply(this, arguments)) : !i && c.trailing && (n[e] = setTimeout((function() {
                            o[e] = !1 === c.leading ? 0 : Date.now(), delete n[e], u.apply(t, r.throttleTrailingArgs), r.throttleTrailingArgs = null
                        }), h))
                    }
                })
            }

            function _t() {
                O("@throttle is deprecated and will be removed shortly. Use @throttle from lodash-decorators.\n\n  https://www.npmjs.com/package/lodash-decorators");
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(Tt, e)
            }
            var St = Object.defineProperty;

            function Et(t, e, r, n) {
                var o, i = (o = n, Array.isArray(o) ? o : Array.from(o)),
                    a = i[0],
                    s = i.slice(1),
                    c = r.configurable,
                    u = r.enumerable,
                    l = r.writable,
                    h = r.get,
                    f = r.set,
                    p = r.value,
                    d = !!h;
                return {
                    configurable: c,
                    enumerable: u,
                    get: function() {
                        var t = d ? h.call(this) : p,
                            r = a.call.apply(a, [this, t].concat(function(t) {
                                if (Array.isArray(t)) {
                                    for (var e = 0, r = Array(t.length); e < t.length; e++) r[e] = t[e];
                                    return r
                                }
                                return Array.from(t)
                            }(s)));
                        if (d) return r;
                        var n = {
                            configurable: c,
                            enumerable: u
                        };
                        return n.value = r, n.writable = l, St(this, e, n), r
                    },
                    set: d ? f : _()
                }
            }

            function kt() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(Et, e)
            }
            var Ot = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" === typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                },
                Ct = Object.defineProperty,
                Ft = Object.getPrototypeOf;

            function Bt(t, e) {
                if (r = t, "[object Symbol]" === Object.prototype.toString.call(r) && "object" === ("undefined" === typeof r ? "undefined" : Ot(r))) {
                    do {
                        if (e === Object.prototype) return "undefined" !== typeof e[t];
                        if (e.hasOwnProperty(t)) return !0
                    } while (e = Ft(e));
                    return !1
                }
                return t in e;
                var r
            }

            function Lt(t, e) {
                if (!e.length) throw new SyntaxError("@mixin() class " + t.name + " requires at least one mixin as an argument");
                for (var r = 0, n = e.length; r < n; r++)
                    for (var o = T(e[r]), i = R(o), a = 0, s = i.length; a < s; a++) {
                        var c = i[a];
                        Bt(c, t.prototype) || Ct(t.prototype, c, o[c])
                    }
            }

            function jt() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return O("@mixin is deprecated and will be removed shortly. Use @mixin from lodash-decorators.\n\n  https://www.npmjs.com/package/lodash-decorators"), "function" === typeof e[0] ? Lt(e[0], []) : function(t) {
                    return Lt(t, e)
                }
            }
            var Mt = Object.assign || function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                },
                It = function(t, e) {
                    if (Array.isArray(t)) return t;
                    if (Symbol.iterator in Object(t)) return function(t, e) {
                        var r = [],
                            n = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, s = t[Symbol.iterator](); !(n = (a = s.next()).done) && (r.push(a.value), !e || r.length !== e); n = !0);
                        } catch (c) {
                            o = !0, i = c
                        } finally {
                            try {
                                !n && s.return && s.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return r
                    }(t, e);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance")
                },
                Dt = {},
                zt = {
                    time: console.time ? console.time.bind(console) : function(t) {
                        Dt[t] = new Date
                    },
                    timeEnd: console.timeEnd ? console.timeEnd.bind(console) : function(t) {
                        var e = new Date - Dt[t];
                        delete Dt[t], console.log(t + ": " + e + "ms")
                    }
                },
                Ut = 0;

            function Wt(t, e, r, n) {
                var o = It(n, 2),
                    i = o[0],
                    a = void 0 === i ? null : i,
                    s = o[1],
                    c = void 0 === s ? zt : s,
                    u = r.value;
                if (null === a && (a = t.constructor.name + "." + e), "function" !== typeof u) throw new SyntaxError("@time can only be used on functions, not: " + u);
                return Mt({}, r, {
                    value: function() {
                        var t = a + "-" + Ut;
                        Ut++, c.time(t);
                        try {
                            return u.apply(this, arguments)
                        } finally {
                            c.timeEnd(t)
                        }
                    }
                })
            }

            function Vt() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(Wt, e)
            }
            var Yt = Object.assign || function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                },
                Nt = Object.getPrototypeOf,
                Kt = Object.getOwnPropertyDescriptor;

            function Xt(t, e, r) {
                var n = Nt(t),
                    o = Kt(n, e);
                return Yt({}, o, {
                    value: r.value,
                    initializer: r.initializer,
                    get: r.get || o.get,
                    set: r.set || o.set
                })
            }

            function qt() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w(Xt, e)
            }
            var Gt = Object.assign || function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = arguments[e];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                    }
                    return t
                },
                Ht = function(t, e) {
                    if (Array.isArray(t)) return t;
                    if (Symbol.iterator in Object(t)) return function(t, e) {
                        var r = [],
                            n = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, s = t[Symbol.iterator](); !(n = (a = s.next()).done) && (r.push(a.value), !e || r.length !== e); n = !0);
                        } catch (c) {
                            o = !0, i = c
                        } finally {
                            try {
                                !n && s.return && s.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return r
                    }(t, e);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance")
                },
                Zt = (console, {
                    profile: console.profile ? S(console.profile, console) : function() {},
                    profileEnd: console.profileEnd ? S(console.profileEnd, console) : function() {},
                    warn: E
                });

            function $t(t, e, r, n) {
                var o = Ht(n, 3),
                    i = o[0],
                    a = void 0 === i ? null : i,
                    s = o[1],
                    c = void 0 !== s && s,
                    u = o[2],
                    l = void 0 === u ? Zt : u;
                if (!Jt.__enabled) return Jt.__warned || (l.warn("console.profile is not supported. All @profile decorators are disabled."), Jt.__warned = !0), r;
                var h = r.value;
                if (null === a && (a = t.constructor.name + "." + e), "function" !== typeof h) throw new SyntaxError("@profile can only be used on functions, not: " + h);
                return Gt({}, r, {
                    value: function() {
                        var t = Date.now(),
                            e = P(this);
                        (!0 === c && !e.profileLastRan || !1 === c || "number" === typeof c && t - e.profileLastRan > c || "function" === typeof c && c.apply(this, arguments)) && (l.profile(a), e.profileLastRan = t);
                        try {
                            return h.apply(this, arguments)
                        } finally {
                            l.profileEnd(a)
                        }
                    }
                })
            }

            function Jt() {
                for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                return w($t, e)
            }
            Jt.__enabled = !!console.profile, Jt.__warned = !1;
            var Qt = Object.defineProperty,
                te = Object.getOwnPropertyDescriptor;

            function ee(t, e) {
                var r = t.prototype;
                for (var n in e)
                    for (var o = e[n], i = 0, a = o.length; i < a; i++) {
                        var s = o[i];
                        Qt(r, n, s(r, n, te(r, n)))
                    }
                return t
            }
        },
        71654: function(t, e, r) {
            var n, o = r(20729);
            ! function(t) {
                ! function(e) {
                    var n = "object" === typeof r.g ? r.g : "object" === typeof self ? self : "object" === typeof this ? this : Function("return this;")(),
                        i = a(t);

                    function a(t, e) {
                        return function(r, n) {
                            "function" !== typeof t[r] && Object.defineProperty(t, r, {
                                configurable: !0,
                                writable: !0,
                                value: n
                            }), e && e(r, n)
                        }
                    }
                    "undefined" === typeof n.Reflect ? n.Reflect = t : i = a(n.Reflect, i),
                        function(t) {
                            var e = Object.prototype.hasOwnProperty,
                                r = "function" === typeof Symbol,
                                n = r && "undefined" !== typeof Symbol.toPrimitive ? Symbol.toPrimitive : "@@toPrimitive",
                                i = r && "undefined" !== typeof Symbol.iterator ? Symbol.iterator : "@@iterator",
                                a = "function" === typeof Object.create,
                                s = {
                                    __proto__: []
                                }
                            instanceof Array, c = !a && !s, u = {
                                create: a ? function() {
                                    return ot(Object.create(null))
                                } : s ? function() {
                                    return ot({
                                        __proto__: null
                                    })
                                } : function() {
                                    return ot({})
                                },
                                has: c ? function(t, r) {
                                    return e.call(t, r)
                                } : function(t, e) {
                                    return e in t
                                },
                                get: c ? function(t, r) {
                                    return e.call(t, r) ? t[r] : void 0
                                } : function(t, e) {
                                    return t[e]
                                }
                            }, l = Object.getPrototypeOf(Function), h = "object" === typeof o && o.env && "true" === o.env.REFLECT_METADATA_USE_MAP_POLYFILL, f = h || "function" !== typeof Map || "function" !== typeof Map.prototype.entries ? et() : Map, p = h || "function" !== typeof Set || "function" !== typeof Set.prototype.entries ? rt() : Set, d = new(h || "function" !== typeof WeakMap ? nt() : WeakMap);

                            function m(t, e, r, n) {
                                if (M(r)) {
                                    if (!K(t)) throw new TypeError;
                                    if (!q(e)) throw new TypeError;
                                    return T(t, e)
                                }
                                if (!K(t)) throw new TypeError;
                                if (!z(e)) throw new TypeError;
                                if (!z(n) && !M(n) && !I(n)) throw new TypeError;
                                return I(n) && (n = void 0), _(t, e, r = N(r), n)
                            }

                            function y(t, e) {
                                function r(r, n) {
                                    if (!z(r)) throw new TypeError;
                                    if (!M(n) && !G(n)) throw new TypeError;
                                    F(t, e, r, n)
                                }
                                return r
                            }

                            function v(t, e, r, n) {
                                if (!z(r)) throw new TypeError;
                                return M(n) || (n = N(n)), F(t, e, r, n)
                            }

                            function g(t, e, r) {
                                if (!z(e)) throw new TypeError;
                                return M(r) || (r = N(r)), E(t, e, r)
                            }

                            function b(t, e, r) {
                                if (!z(e)) throw new TypeError;
                                return M(r) || (r = N(r)), k(t, e, r)
                            }

                            function w(t, e, r) {
                                if (!z(e)) throw new TypeError;
                                return M(r) || (r = N(r)), O(t, e, r)
                            }

                            function x(t, e, r) {
                                if (!z(e)) throw new TypeError;
                                return M(r) || (r = N(r)), C(t, e, r)
                            }

                            function A(t, e) {
                                if (!z(t)) throw new TypeError;
                                return M(e) || (e = N(e)), B(t, e)
                            }

                            function P(t, e) {
                                if (!z(t)) throw new TypeError;
                                return M(e) || (e = N(e)), L(t, e)
                            }

                            function R(t, e, r) {
                                if (!z(e)) throw new TypeError;
                                M(r) || (r = N(r));
                                var n = S(e, r, !1);
                                if (M(n)) return !1;
                                if (!n.delete(t)) return !1;
                                if (n.size > 0) return !0;
                                var o = d.get(e);
                                return o.delete(r), o.size > 0 || d.delete(e), !0
                            }

                            function T(t, e) {
                                for (var r = t.length - 1; r >= 0; --r) {
                                    var n = (0, t[r])(e);
                                    if (!M(n) && !I(n)) {
                                        if (!q(n)) throw new TypeError;
                                        e = n
                                    }
                                }
                                return e
                            }

                            function _(t, e, r, n) {
                                for (var o = t.length - 1; o >= 0; --o) {
                                    var i = (0, t[o])(e, r, n);
                                    if (!M(i) && !I(i)) {
                                        if (!z(i)) throw new TypeError;
                                        n = i
                                    }
                                }
                                return n
                            }

                            function S(t, e, r) {
                                var n = d.get(t);
                                if (M(n)) {
                                    if (!r) return;
                                    n = new f, d.set(t, n)
                                }
                                var o = n.get(e);
                                if (M(o)) {
                                    if (!r) return;
                                    o = new f, n.set(e, o)
                                }
                                return o
                            }

                            function E(t, e, r) {
                                if (k(t, e, r)) return !0;
                                var n = tt(e);
                                return !I(n) && E(t, n, r)
                            }

                            function k(t, e, r) {
                                var n = S(e, r, !1);
                                return !M(n) && V(n.has(t))
                            }

                            function O(t, e, r) {
                                if (k(t, e, r)) return C(t, e, r);
                                var n = tt(e);
                                return I(n) ? void 0 : O(t, n, r)
                            }

                            function C(t, e, r) {
                                var n = S(e, r, !1);
                                if (!M(n)) return n.get(t)
                            }

                            function F(t, e, r, n) {
                                S(r, n, !0).set(t, e)
                            }

                            function B(t, e) {
                                var r = L(t, e),
                                    n = tt(t);
                                if (null === n) return r;
                                var o = B(n, e);
                                if (o.length <= 0) return r;
                                if (r.length <= 0) return o;
                                for (var i = new p, a = [], s = 0, c = r; s < c.length; s++) {
                                    var u = c[s];
                                    i.has(u) || (i.add(u), a.push(u))
                                }
                                for (var l = 0, h = o; l < h.length; l++) {
                                    u = h[l];
                                    i.has(u) || (i.add(u), a.push(u))
                                }
                                return a
                            }

                            function L(t, e) {
                                var r = [],
                                    n = S(t, e, !1);
                                if (M(n)) return r;
                                for (var o = Z(n.keys()), i = 0;;) {
                                    var a = J(o);
                                    if (!a) return r.length = i, r;
                                    var s = $(a);
                                    try {
                                        r[i] = s
                                    } catch (c) {
                                        try {
                                            Q(o)
                                        } finally {
                                            throw c
                                        }
                                    }
                                    i++
                                }
                            }

                            function j(t) {
                                if (null === t) return 1;
                                switch (typeof t) {
                                    case "undefined":
                                        return 0;
                                    case "boolean":
                                        return 2;
                                    case "string":
                                        return 3;
                                    case "symbol":
                                        return 4;
                                    case "number":
                                        return 5;
                                    case "object":
                                        return null === t ? 1 : 6;
                                    default:
                                        return 6
                                }
                            }

                            function M(t) {
                                return void 0 === t
                            }

                            function I(t) {
                                return null === t
                            }

                            function D(t) {
                                return "symbol" === typeof t
                            }

                            function z(t) {
                                return "object" === typeof t ? null !== t : "function" === typeof t
                            }

                            function U(t, e) {
                                switch (j(t)) {
                                    case 0:
                                    case 1:
                                    case 2:
                                    case 3:
                                    case 4:
                                    case 5:
                                        return t
                                }
                                var r = 3 === e ? "string" : 5 === e ? "number" : "default",
                                    o = H(t, n);
                                if (void 0 !== o) {
                                    var i = o.call(t, r);
                                    if (z(i)) throw new TypeError;
                                    return i
                                }
                                return W(t, "default" === r ? "number" : r)
                            }

                            function W(t, e) {
                                if ("string" === e) {
                                    var r = t.toString;
                                    if (X(r))
                                        if (!z(o = r.call(t))) return o;
                                    if (X(n = t.valueOf))
                                        if (!z(o = n.call(t))) return o
                                } else {
                                    var n;
                                    if (X(n = t.valueOf))
                                        if (!z(o = n.call(t))) return o;
                                    var o, i = t.toString;
                                    if (X(i))
                                        if (!z(o = i.call(t))) return o
                                }
                                throw new TypeError
                            }

                            function V(t) {
                                return !!t
                            }

                            function Y(t) {
                                return "" + t
                            }

                            function N(t) {
                                var e = U(t, 3);
                                return D(e) ? e : Y(e)
                            }

                            function K(t) {
                                return Array.isArray ? Array.isArray(t) : t instanceof Object ? t instanceof Array : "[object Array]" === Object.prototype.toString.call(t)
                            }

                            function X(t) {
                                return "function" === typeof t
                            }

                            function q(t) {
                                return "function" === typeof t
                            }

                            function G(t) {
                                switch (j(t)) {
                                    case 3:
                                    case 4:
                                        return !0;
                                    default:
                                        return !1
                                }
                            }

                            function H(t, e) {
                                var r = t[e];
                                if (void 0 !== r && null !== r) {
                                    if (!X(r)) throw new TypeError;
                                    return r
                                }
                            }

                            function Z(t) {
                                var e = H(t, i);
                                if (!X(e)) throw new TypeError;
                                var r = e.call(t);
                                if (!z(r)) throw new TypeError;
                                return r
                            }

                            function $(t) {
                                return t.value
                            }

                            function J(t) {
                                var e = t.next();
                                return !e.done && e
                            }

                            function Q(t) {
                                var e = t.return;
                                e && e.call(t)
                            }

                            function tt(t) {
                                var e = Object.getPrototypeOf(t);
                                if ("function" !== typeof t || t === l) return e;
                                if (e !== l) return e;
                                var r = t.prototype,
                                    n = r && Object.getPrototypeOf(r);
                                if (null == n || n === Object.prototype) return e;
                                var o = n.constructor;
                                return "function" !== typeof o || o === t ? e : o
                            }

                            function et() {
                                var t = {},
                                    e = [],
                                    r = function() {
                                        function t(t, e, r) {
                                            this._index = 0, this._keys = t, this._values = e, this._selector = r
                                        }
                                        return t.prototype["@@iterator"] = function() {
                                            return this
                                        }, t.prototype[i] = function() {
                                            return this
                                        }, t.prototype.next = function() {
                                            var t = this._index;
                                            if (t >= 0 && t < this._keys.length) {
                                                var r = this._selector(this._keys[t], this._values[t]);
                                                return t + 1 >= this._keys.length ? (this._index = -1, this._keys = e, this._values = e) : this._index++, {
                                                    value: r,
                                                    done: !1
                                                }
                                            }
                                            return {
                                                value: void 0,
                                                done: !0
                                            }
                                        }, t.prototype.throw = function(t) {
                                            throw this._index >= 0 && (this._index = -1, this._keys = e, this._values = e), t
                                        }, t.prototype.return = function(t) {
                                            return this._index >= 0 && (this._index = -1, this._keys = e, this._values = e), {
                                                value: t,
                                                done: !0
                                            }
                                        }, t
                                    }();
                                return function() {
                                    function e() {
                                        this._keys = [], this._values = [], this._cacheKey = t, this._cacheIndex = -2
                                    }
                                    return Object.defineProperty(e.prototype, "size", {
                                        get: function() {
                                            return this._keys.length
                                        },
                                        enumerable: !0,
                                        configurable: !0
                                    }), e.prototype.has = function(t) {
                                        return this._find(t, !1) >= 0
                                    }, e.prototype.get = function(t) {
                                        var e = this._find(t, !1);
                                        return e >= 0 ? this._values[e] : void 0
                                    }, e.prototype.set = function(t, e) {
                                        var r = this._find(t, !0);
                                        return this._values[r] = e, this
                                    }, e.prototype.delete = function(e) {
                                        var r = this._find(e, !1);
                                        if (r >= 0) {
                                            for (var n = this._keys.length, o = r + 1; o < n; o++) this._keys[o - 1] = this._keys[o], this._values[o - 1] = this._values[o];
                                            return this._keys.length--, this._values.length--, e === this._cacheKey && (this._cacheKey = t, this._cacheIndex = -2), !0
                                        }
                                        return !1
                                    }, e.prototype.clear = function() {
                                        this._keys.length = 0, this._values.length = 0, this._cacheKey = t, this._cacheIndex = -2
                                    }, e.prototype.keys = function() {
                                        return new r(this._keys, this._values, n)
                                    }, e.prototype.values = function() {
                                        return new r(this._keys, this._values, o)
                                    }, e.prototype.entries = function() {
                                        return new r(this._keys, this._values, a)
                                    }, e.prototype["@@iterator"] = function() {
                                        return this.entries()
                                    }, e.prototype[i] = function() {
                                        return this.entries()
                                    }, e.prototype._find = function(t, e) {
                                        return this._cacheKey !== t && (this._cacheIndex = this._keys.indexOf(this._cacheKey = t)), this._cacheIndex < 0 && e && (this._cacheIndex = this._keys.length, this._keys.push(t), this._values.push(void 0)), this._cacheIndex
                                    }, e
                                }();

                                function n(t, e) {
                                    return t
                                }

                                function o(t, e) {
                                    return e
                                }

                                function a(t, e) {
                                    return [t, e]
                                }
                            }

                            function rt() {
                                return function() {
                                    function t() {
                                        this._map = new f
                                    }
                                    return Object.defineProperty(t.prototype, "size", {
                                        get: function() {
                                            return this._map.size
                                        },
                                        enumerable: !0,
                                        configurable: !0
                                    }), t.prototype.has = function(t) {
                                        return this._map.has(t)
                                    }, t.prototype.add = function(t) {
                                        return this._map.set(t, t), this
                                    }, t.prototype.delete = function(t) {
                                        return this._map.delete(t)
                                    }, t.prototype.clear = function() {
                                        this._map.clear()
                                    }, t.prototype.keys = function() {
                                        return this._map.keys()
                                    }, t.prototype.values = function() {
                                        return this._map.values()
                                    }, t.prototype.entries = function() {
                                        return this._map.entries()
                                    }, t.prototype["@@iterator"] = function() {
                                        return this.keys()
                                    }, t.prototype[i] = function() {
                                        return this.keys()
                                    }, t
                                }()
                            }

                            function nt() {
                                var t = 16,
                                    r = u.create(),
                                    n = o();
                                return function() {
                                    function t() {
                                        this._key = o()
                                    }
                                    return t.prototype.has = function(t) {
                                        var e = i(t, !1);
                                        return void 0 !== e && u.has(e, this._key)
                                    }, t.prototype.get = function(t) {
                                        var e = i(t, !1);
                                        return void 0 !== e ? u.get(e, this._key) : void 0
                                    }, t.prototype.set = function(t, e) {
                                        return i(t, !0)[this._key] = e, this
                                    }, t.prototype.delete = function(t) {
                                        var e = i(t, !1);
                                        return void 0 !== e && delete e[this._key]
                                    }, t.prototype.clear = function() {
                                        this._key = o()
                                    }, t
                                }();

                                function o() {
                                    var t;
                                    do {
                                        t = "@@WeakMap@@" + c()
                                    } while (u.has(r, t));
                                    return r[t] = !0, t
                                }

                                function i(t, r) {
                                    if (!e.call(t, n)) {
                                        if (!r) return;
                                        Object.defineProperty(t, n, {
                                            value: u.create()
                                        })
                                    }
                                    return t[n]
                                }

                                function a(t, e) {
                                    for (var r = 0; r < e; ++r) t[r] = 255 * Math.random() | 0;
                                    return t
                                }

                                function s(t) {
                                    return "function" === typeof Uint8Array ? "undefined" !== typeof crypto ? crypto.getRandomValues(new Uint8Array(t)) : "undefined" !== typeof msCrypto ? msCrypto.getRandomValues(new Uint8Array(t)) : a(new Uint8Array(t), t) : a(new Array(t), t)
                                }

                                function c() {
                                    var e = s(t);
                                    e[6] = 79 & e[6] | 64, e[8] = 191 & e[8] | 128;
                                    for (var r = "", n = 0; n < t; ++n) {
                                        var o = e[n];
                                        4 !== n && 6 !== n && 8 !== n || (r += "-"), o < 16 && (r += "0"), r += o.toString(16).toLowerCase()
                                    }
                                    return r
                                }
                            }

                            function ot(t) {
                                return t.__ = void 0, delete t.__, t
                            }
                            t("decorate", m), t("metadata", y), t("defineMetadata", v), t("hasMetadata", g), t("hasOwnMetadata", b), t("getMetadata", w), t("getOwnMetadata", x), t("getMetadataKeys", A), t("getOwnMetadataKeys", P), t("deleteMetadata", R)
                        }(i)
                }()
            }(n || (n = {}))
        }
    }
]);
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [497], {
        87015: function(t, s, e) {
            e.d(s, {
                W: function() {
                    return y
                }
            });
            var n = e(7279),
                o = e(46532),
                i = e(76729),
                r = e(12764),
                a = e(84717),
                u = e(62838),
                h = e(97708),
                l = e(7696),
                c = e(28066),
                p = e(96510),
                d = e(33776),
                f = e(46422);
            class y extends f.mh {
                constructor(t) {
                    if (super({}), this.containerNodes = new Set, this.name = t.name, null == this.name) {
                        const t = this.getClassName().toLowerCase();
                        this.name = (0, o.s)(t)
                    }
                    if (this.supportsMasking = !1, this.trainable_ = !0, Array.isArray(t.inputs) ? this.inputs = t.inputs.slice() : this.inputs = [t.inputs], Array.isArray(t.outputs) ? this.outputs = t.outputs.slice() : this.outputs = [t.outputs], a.Tw(this.inputs).length !== this.inputs.length) throw new i.nu(`The list of inputs passed to the model is redundant. All inputs should only appear once. Found: ${this.inputs.map((t=>t.name))}`);
                    a.Tw(this.outputs).length !== this.outputs.length && console.warn(`The list of outputs passed to the model is redundant. All outputs should only appear once. Found: ${this.outputs.map((t=>t.name))}`), this.inputLayers = [], this.inputLayersNodeIndices = [], this.inputLayersTensorIndices = [], this.outputLayers = [], this.outputLayersNodeIndices = [], this.outputLayersTensorIndices = [], this.layers = [], this.internalContainerRefs = [];
                    for (const o of this.outputs) {
                        const t = o.sourceLayer,
                            s = o.nodeIndex,
                            e = o.tensorIndex;
                        this.outputLayers.push(t), this.outputLayersNodeIndices.push(s), this.outputLayersTensorIndices.push(e)
                    }
                    for (const o of this.inputs) {
                        const t = o.sourceLayer,
                            s = o.nodeIndex,
                            e = o.tensorIndex;
                        a.hu(0 === s, "input layer has >1 nodes"), a.hu(0 === e, "input layer has >1 tensors"), this.inputLayers.push(t), this.inputLayersNodeIndices.push(s), this.inputLayersTensorIndices.push(e)
                    }
                    this.inputNames = [], this.outputNames = [], this.feedInputShapes = [], this.feedInputNames = [], this.feedOutputNames = [];
                    for (let o = 0; o < this.inputLayers.length; o++) {
                        const s = this.inputLayers[o];
                        if (!(s instanceof d.l)) throw new TypeError(`Input layers to a LayersModel must be InputLayer objects. Received inputs: ${t.inputs}. Input ${o} (0-based) originates from layer type ${s.getClassName()}.`);
                        this.inputNames.push(s.name), this.feedInputShapes.push(s.batchInputShape), this.feedInputNames.push(s.name)
                    }
                    for (const o of this.outputLayers) this.outputNames.push(o.name);
                    this.internalInputShapes = this.inputs.map((t => t.shape)), this.internalOutputShapes = this.outputs.map((t => t.shape));
                    const s = {},
                        e = {},
                        n = {},
                        r = {},
                        u = {},
                        h = [],
                        l = (t, s, e, n, o, r) => {
                            null != n && null != o && null != r || (n = t.sourceLayer, o = t.nodeIndex, r = t.tensorIndex);
                            const a = n.inboundNodes[o];
                            if (-1 !== e.indexOf(a)) throw new i.LH(`The tensor ${t.name} at layer "${n.name}" is part of a cycle.`);
                            if (-1 !== s.indexOf(a)) return;
                            this.containerNodes.add(y.nodeKey(n, o)), n.id in u || (u[n.id] = Object.keys(u).length), -1 === e.indexOf(a) && e.push(a);
                            const c = a.inboundLayers.length;
                            for (let i = 0; i < c; i++) {
                                const t = a.inputTensors[i],
                                    n = a.inboundLayers[i],
                                    o = a.nodeIndices[i],
                                    r = a.tensorIndices[i];
                                l(t, s, e, n, o, r)
                            }
                            for (s.push(a); e.indexOf(a) >= 0;) e.splice(e.indexOf(a), 1);
                            h.push(a)
                        },
                        c = [],
                        p = [];
                    for (const o of this.outputs) l(o, c, p);
                    const m = h.slice().reverse();
                    for (const o of m) {
                        e[o.id] = o, o.id in s || (s[o.id] = 0);
                        let t = s[o.id];
                        const i = null == n[o.outboundLayer.id] ? 0 : n[o.outboundLayer.id];
                        t = Math.max(t, i), n[o.outboundLayer.id] = t, r[o.outboundLayer.id] = o.outboundLayer, s[o.id] = t;
                        for (let n = 0; n < o.inboundLayers.length; n++) {
                            const i = o.inboundLayers[n],
                                r = o.nodeIndices[n],
                                a = i.inboundNodes[r],
                                u = null == s[a.id] ? 0 : s[a.id];
                            s[a.id] = Math.max(t + 1, u), e[a.id] = a
                        }
                    }
                    const g = {};
                    for (const o in s) {
                        const t = s[o];
                        t in g || (g[t] = []), g[t].push(e[o])
                    }
                    const b = {};
                    for (const o in n) {
                        const t = n[o];
                        t in b || (b[t] = []), b[t].push(r[o])
                    }
                    let L = Object.keys(b).map((t => parseInt(t, 10))).sort(a.L7);
                    this.layers = [];
                    for (const o of L) {
                        const t = b[o];
                        t.sort(((t, s) => {
                            const e = u[t.id],
                                n = u[s.id];
                            return e < n ? -1 : e > n ? 1 : 0
                        }));
                        for (const s of t) s instanceof y && this.internalContainerRefs.push(s), this.layers.push(s)
                    }
                    this.layersByDepth = b, L = Object.keys(g).map((t => parseInt(t, 10))).sort(a.L7);
                    const w = this.inputs.slice(),
                        N = [];
                    for (const o of L)
                        for (const t of g[o]) {
                            const s = t.outboundLayer;
                            if (null != s) {
                                for (const e of t.inputTensors)
                                    if (-1 === w.indexOf(e)) throw new i.LH(`Graph disconnected: cannot obtain value for tensor ${e} at layer "${s.name}". The following previous layers were accessed without issue: ${N}`);
                                for (const s of t.outputTensors) w.push(s);
                                N.push(s.name)
                            }
                        }
                    this.nodesByDepth = g;
                    const I = this.layers.map((t => t.name));
                    for (const o of I) {
                        const t = I.filter((t => t === o)).length;
                        if (1 !== t) throw new i.LH(`The name "${o}" is used ${t} times in the model. All layer names should be unique. Layer names: ` + JSON.stringify(I))
                    }
                    this.outboundNodes = [], this.inboundNodes = [], new f.NB({
                        outboundLayer: this,
                        inboundLayers: [],
                        nodeIndices: [],
                        tensorIndices: [],
                        inputTensors: this.inputs,
                        outputTensors: this.outputs,
                        inputMasks: this.inputs.map((t => null)),
                        outputMasks: this.outputs.map((t => null)),
                        inputShapes: this.inputs.map((t => t.shape)),
                        outputShapes: this.outputs.map((t => t.shape))
                    }), this.built = !0, this._refCount = 1
                }
                assertNotDisposed() {
                    if (0 === this._refCount) throw new Error(`Container '${this.name}' is already disposed.`)
                }
                dispose() {
                    this.assertNotDisposed();
                    const t = {
                        refCountAfterDispose: null,
                        numDisposedVariables: 0
                    };
                    if (0 === --this._refCount) {
                        for (const s of this.layers) t.numDisposedVariables += s.dispose().numDisposedVariables;
                        for (const s of this.internalContainerRefs) t.numDisposedVariables += s.dispose().numDisposedVariables
                    }
                    return t.refCountAfterDispose = this._refCount, t
                }
                get trainable() {
                    return this.trainable_
                }
                set trainable(t) {
                    this.layers.forEach((s => {
                        s._trainableWeights.forEach((s => s.trainable = t))
                    })), this.trainable_ = t
                }
                get trainableWeights() {
                    if (this._trainableWeights.length > 0) throw new i.nu("Container instance unexpectedly contains _trainableWeights.The trainable weights of a Container are a union of the trainable weights of its consituent Layers. Its own _trainableWeights must remain an empty Array.");
                    if (!this.trainable) return [];
                    let t = [];
                    for (const s of this.layers) t = t.concat(s.trainableWeights);
                    return t
                }
                get nonTrainableWeights() {
                    const t = [];
                    for (const s of this.layers) t.push(...s.nonTrainableWeights);
                    if (!this.trainable) {
                        const s = [];
                        for (const t of this.layers) s.push(...t.trainableWeights);
                        return s.concat(t)
                    }
                    return t
                }
                get weights() {
                    return this.trainableWeights.concat(this.nonTrainableWeights)
                }
                loadWeights(t, s = !0) {
                    const e = {};
                    let n = 0;
                    for (const r of this.layers)
                        for (const t of r.weights) {
                            if (null != e[t.originalName]) throw new i.nu(`Duplicate weight name: ${t.originalName}`);
                            e[t.originalName] = t, n++
                        }
                    const o = [];
                    for (const r in t) {
                        let n = r;
                        if (null == e[r]) {
                            const t = r.split("/");
                            n = t.slice(0, -2).concat([t[t.length - 1]]).join("/")
                        }
                        if (null != e[n]) o.push([e[n], t[r]]);
                        else if (s) throw new i.nu(`Provided weight data has no target variable: ${r}`);
                        delete e[n]
                    }
                    if (s) {
                        const t = [];
                        for (const s in e) t.push(s);
                        if (t.length > 0) throw new i.nu(`${t.length} of ${n} weights are not set: ${t}`)
                    }(0, l.zb)(o)
                }
                updatedConfig() {
                    const t = this.getConfig(),
                        s = {};
                    return s.className = this.getClassName(), s.config = t, s.kerasVersion = `tfjs-layers ${c.i}`, s.backend = "TensorFlow.js", s
                }
                toJSON(t, s = !0) {
                    const e = (0, u.q)(this.updatedConfig());
                    return s ? JSON.stringify(e) : e
                }
                call(t, s) {
                    return (0, n.lub)((() => {
                        t = a.zZ(t);
                        const e = new p.l2;
                        for (let s = 0; s < this.inputs.length; ++s) e.add(this.inputs[s], t[s]);
                        return (0, p.ht)(this.outputs, e, s)
                    }))
                }
                computeMask(t, s) {
                    return (0, n.lub)((() => {
                        let e;
                        return t = a.zZ(t), e = null == s ? a.JE(null, t.length) : a.zZ(s), this.runInternalGraph(t, e)[1]
                    }))
                }
                computeOutputShape(t) {
                    const s = h.x6(t);
                    if (s.length !== this.inputLayers.length) throw new i.nu(`Invalid inputShape argument ${t}: model has ${this.inputLayers.length} tensor inputs.`);
                    const e = {};
                    for (let i = 0; i < s.length; i++) {
                        const t = this.inputLayers[i],
                            n = s[i];
                        e[t.name + "_0_0"] = n
                    }
                    const n = Object.keys(this.nodesByDepth).map((t => parseInt(t, 10))).sort(a.L7);
                    if (n.length > 1)
                        for (const i of n) {
                            const t = this.nodesByDepth[i];
                            for (const s of t) {
                                const t = s.outboundLayer;
                                if (-1 !== this.inputLayers.map((t => t.id)).indexOf(t.id)) continue;
                                const n = [];
                                for (let a = 0; a < s.inboundLayers.length; a++) {
                                    const t = s.inboundLayers[a],
                                        o = s.nodeIndices[a],
                                        i = s.tensorIndices[a],
                                        r = e[`${t.name}_${o}_${i}`];
                                    n.push(r)
                                }
                                const o = t.computeOutputShape(a.Bq(n)),
                                    i = h.x6(o),
                                    r = t.inboundNodes.indexOf(s);
                                for (let s = 0; s < i.length; s++) {
                                    e[`${t.name}_${r}_${s}`] = i[s]
                                }
                            }
                        }
                    const o = [],
                        r = [];
                    for (let i = 0; i < this.outputLayers.length; i++) {
                        const t = this.outputLayers[i],
                            s = this.outputLayersNodeIndices[i],
                            e = this.outputLayersTensorIndices[i],
                            n = `${t.name}_${s}_${e}`;
                        r.push(n)
                    }
                    for (let i = 0; i < r.length; i++) {
                        const t = r[i];
                        a.hu(t in e), o.push(e[t])
                    }
                    return a.Bq(o)
                }
                runInternalGraph(t, s) {
                    null == s && (s = a.JE(null, t.length));
                    const e = {};
                    for (let i = 0; i < this.inputs.length; ++i) {
                        const n = this.inputs[i],
                            o = t[i],
                            r = s[i];
                        e[n.id] = [o, r]
                    }
                    const n = Object.keys(this.nodesByDepth).map((t => parseInt(t, 10))).sort(a.L7);
                    for (const h of n) {
                        const t = this.nodesByDepth[h];
                        for (const s of t) {
                            const t = s.outboundLayer,
                                n = s.inputTensors,
                                o = s.outputTensors,
                                r = new Array;
                            for (const s of n) s.id in e && r.push(e[s.id]);
                            if (r.length === n.length) {
                                let n, u, h, l, c = {};
                                if (null != s.callArgs && (c = s.callArgs), 1 === r.length) {
                                    const [s, e] = r[0];
                                    null == c.mask && (c.mask = e), h = a.zZ(t.call(s, c)), l = a.zZ(t.computeMask(s, e)), n = [s], u = [e]
                                } else n = r.map((t => t[0])), u = r.map((t => t[1])), null == c.mask && (c.mask = u), h = a.zZ(t.call(n, c)), l = a.zZ(t.computeMask(n, u));
                                if (t.activityRegularizer) throw new i.nj("LayersModel invocation with concrete Tensor value(s) in the presence of activity regularizer(s) is not supported yet.");
                                for (let t = 0; t < o.length; ++t) {
                                    const s = o[t],
                                        n = h[t],
                                        i = l[t];
                                    e[s.id] = [n, i]
                                }
                            }
                        }
                    }
                    const o = [],
                        r = [],
                        u = [];
                    for (const i of this.outputs) {
                        a.hu(i.id in e, `Could not compute output ${i.name} : ${i.id}`);
                        const [t, s] = e[i.id];
                        u.push(t.shape), o.push(t), r.push(s)
                    }
                    return [o, r, u]
                }
                buildNodeConversionMap(t) {
                    const s = {};
                    let e;
                    for (const n of this.layers) {
                        e = n instanceof y ? 1 : 0;
                        for (let t = 0; t < n.inboundNodes.length; t++) {
                            const o = y.nodeKey(n, t);
                            this.containerNodes.has(o) && (s[o] = e, e += 1)
                        }
                    }
                    return s
                }
                getLayer(t, s) {
                    if (null != s) {
                        if (this.layers.length <= s) throw new i.nu(`Was asked to retrieve layer at index ${s}, but model only has ${this.layers.length} layer(s).`);
                        return this.layers[s]
                    }
                    if (null == t) throw new i.nu("Provide either a layer name or layer index");
                    for (const e of this.layers)
                        if (e.name === t) return e;
                    throw new i.nu(`No such layer: ${t}`)
                }
                calculateLosses() {
                    return (0, n.lub)((() => {
                        const t = [];
                        for (const s of this.layers)
                            for (let e = 0; e < s.inboundNodes.length; ++e) {
                                const n = y.nodeKey(s, e);
                                this.containerNodes.has(n) && t.push(...s.calculateLosses())
                            }
                        return t
                    }))
                }
                getConfig() {
                    const t = {
                            name: this.name
                        },
                        s = this.buildNodeConversionMap(this.layers),
                        e = [];
                    for (const r of this.layers) {
                        const t = r.getClassName(),
                            n = r.getConfig(),
                            o = [];
                        for (let e = 0; e < r.inboundNodes.length; e++) {
                            const t = r.inboundNodes[e],
                                n = y.nodeKey(r, e);
                            let a = {};
                            if (this.containerNodes.has(n)) {
                                if (t.callArgs) try {
                                    JSON.stringify(t.callArgs), a = t.callArgs
                                } catch (i) {
                                    console.warn(`Layer ${r.name} was passed non-serializable keyword arguments: ${t.callArgs}. They will not be included in the serialized model (and thus will be missing at deserialization time).`), a = {}
                                }
                                if (t.inboundLayers.length > 0) {
                                    const e = [];
                                    for (let n = 0; n < t.inboundLayers.length; n++) {
                                        const o = t.inboundLayers[n],
                                            i = t.nodeIndices[n],
                                            r = t.tensorIndices[n];
                                        let u = s[y.nodeKey(o, i)];
                                        null == u && (u = 0), e.push([o.name, u, r, a])
                                    }
                                    o.push(e)
                                }
                            }
                        }
                        const a = {};
                        a.name = r.name, a.className = t, a.config = n, a.inboundNodes = o, e.push(a)
                    }
                    t.layers = e;
                    const n = [];
                    for (let r = 0; r < this.inputLayers.length; r++) {
                        const t = this.inputLayers[r],
                            e = this.inputLayersNodeIndices[r],
                            o = y.nodeKey(t, e);
                        if (!this.containerNodes.has(o)) continue;
                        let i = s[o];
                        null !== i && void 0 !== i || (i = 0);
                        const a = this.inputLayersTensorIndices[r];
                        n.push([t.name, i, a])
                    }
                    t.inputLayers = n;
                    const o = [];
                    for (let r = 0; r < this.outputLayers.length; r++) {
                        const t = this.outputLayers[r],
                            e = this.outputLayersNodeIndices[r],
                            n = y.nodeKey(t, e);
                        if (!this.containerNodes.has(n)) continue;
                        let i = s[n];
                        null !== i && void 0 !== i || (i = 0);
                        const a = this.outputLayersTensorIndices[r];
                        o.push([t.name, i, a])
                    }
                    return t.outputLayers = o, t
                }
                static fromConfig(t, s, e = {}, n = !1) {
                    const o = {},
                        u = {};

                    function h(t, s) {
                        t.name in u ? u[t.name].push(s) : u[t.name] = [s]
                    }

                    function l(t, s) {
                        const e = [];
                        let n;
                        for (const i of s) {
                            const r = i[0],
                                a = i[1],
                                u = i[2];
                            if (n = null == i[3] ? {} : i[3], !(r in o)) return void h(t, s);
                            const l = o[r];
                            if (l.inboundNodes.length <= a) return void h(t, s);
                            const c = l.inboundNodes[a];
                            e.push(c.outputTensors[u])
                        }
                        e.length > 0 && t.apply(a.Bq(e), n)
                    }

                    function c(t) {
                        const e = t.name,
                            a = (0, r.v)(t, null != s.customObjects ? s.customObjects : {});
                        a.setFastWeightInitDuringBuild(n), o[e] = a;
                        t.inboundNodes.forEach((t => {
                            if (!(t instanceof Array)) throw new i.nu(`Corrupted configuration, expected array for nodeData: ${t}`);
                            h(a, t)
                        }))
                    }
                    const p = s.name,
                        d = s.layers;
                    for (const i of d) c(i);
                    for (; !a.nK(u);)
                        for (const t of d) {
                            const s = o[t.name];
                            if (s.name in u) {
                                const t = u[s.name];
                                delete u[s.name];
                                for (const e of t) l(s, e)
                            }
                        }
                    const f = [],
                        y = [],
                        m = s.inputLayers;
                    for (const i of m) {
                        const t = i[0],
                            s = i[1],
                            e = i[2];
                        a.hu(t in o);
                        const n = o[t].inboundNodes[s].outputTensors;
                        f.push(n[e])
                    }
                    const g = s.outputLayers;
                    for (const i of g) {
                        const t = i[0],
                            s = i[1],
                            e = i[2];
                        a.hu(t in o);
                        const n = o[t].inboundNodes[s].outputTensors;
                        y.push(n[e])
                    }
                    return new t({
                        inputs: f,
                        outputs: y,
                        name: p
                    })
                }
                get stateful() {
                    if (this._stateful) throw new i.nu("Container instance unexpectedly has _stateful = true. The statefulness of a Container is determined by the Layers it contains. Its _stateful property must remain the default false.");
                    for (const t of this.layers)
                        if (t.stateful) return !0;
                    return !1
                }
                resetStates() {
                    (0, n.lub)((() => {
                        this.layers.forEach((t => {
                            t.stateful && t.resetStates()
                        }))
                    }))
                }
            }
        }
    }
]);
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [226], {
        75586: function(f, e, a) {
            a.d(e, {
                Wb: function() {
                    return s
                }
            });
            const s = {
                base: {
                    background: {
                        base: "#ffffff",
                        highlight: "#f6f6f6",
                        press: "#b7b7b7",
                        elevated: {
                            base: "#ffffff",
                            highlight: "#f6f6f6",
                            press: "#b7b7b7"
                        },
                        tinted: {
                            base: "rgba(0, 0, 0, 0.08)",
                            highlight: "rgba(0, 0, 0, 0.05)",
                            press: "rgba(0, 0, 0, 0.12)"
                        },
                        unsafeForSmallText: {
                            base: "#ffffff",
                            highlight: "#ffffff",
                            press: "#ffffff"
                        }
                    },
                    text: {
                        base: "#000000",
                        subdued: "#6a6a6a",
                        brightAccent: "#117a37",
                        negative: "#d31225",
                        warning: "#9d5a00",
                        positive: "#117a37",
                        announcement: "#0c67d3"
                    },
                    essential: {
                        base: "#000000",
                        subdued: "#878787",
                        brightAccent: "#169b45",
                        negative: "#e91429",
                        warning: "#c77200",
                        positive: "#169b45",
                        announcement: "#0d72ea"
                    },
                    decorative: {
                        base: "#000000",
                        subdued: "#dedede"
                    }
                },
                brightAccent: {
                    background: {
                        base: "#1ed760",
                        highlight: "#1fdf64",
                        press: "#169c46",
                        elevated: {
                            base: "#1ed760",
                            highlight: "#1ed760",
                            press: "#1ed760"
                        },
                        tinted: {
                            base: "#1ed760",
                            highlight: "#1ed760",
                            press: "#1ed760"
                        },
                        unsafeForSmallText: {
                            base: "#1ed760",
                            highlight: "#1ed760",
                            press: "#1ed760"
                        }
                    },
                    text: {
                        base: "#000000",
                        subdued: "#000000",
                        brightAccent: "#000000",
                        negative: "#000000",
                        warning: "#000000",
                        positive: "#000000",
                        announcement: "#000000"
                    },
                    essential: {
                        base: "#000000",
                        subdued: "#000000",
                        brightAccent: "#000000",
                        negative: "#000000",
                        warning: "#000000",
                        positive: "#000000",
                        announcement: "#000000"
                    },
                    decorative: {
                        base: "#000000",
                        subdued: "#1abc54"
                    }
                },
                negative: {
                    background: {
                        base: "#e91429",
                        highlight: "#de1327",
                        press: "#920d1a",
                        elevated: {
                            base: "#e91429",
                            highlight: "#e91429",
                            press: "#e91429"
                        },
                        tinted: {
                            base: "#e91429",
                            highlight: "#e91429",
                            press: "#e91429"
                        },
                        unsafeForSmallText: {
                            base: "#e91429",
                            highlight: "#e91429",
                            press: "#e91429"
                        }
                    },
                    text: {
                        base: "#ffffff",
                        subdued: "#ffffff",
                        brightAccent: "#ffffff",
                        negative: "#ffffff",
                        warning: "#ffffff",
                        positive: "#ffffff",
                        announcement: "#ffffff"
                    },
                    essential: {
                        base: "#ffffff",
                        subdued: "#ffffff",
                        brightAccent: "#ffffff",
                        negative: "#ffffff",
                        warning: "#ffffff",
                        positive: "#ffffff",
                        announcement: "#ffffff"
                    },
                    decorative: {
                        base: "#ffffff",
                        subdued: "#ee3a4c"
                    }
                },
                warning: {
                    background: {
                        base: "#ffa42b",
                        highlight: "#ffaf45",
                        press: "#c57100",
                        elevated: {
                            base: "#ffa42b",
                            highlight: "#ffa42b",
                            press: "#ffa42b"
                        },
                        tinted: {
                            base: "#ffa42b",
                            highlight: "#ffa42b",
                            press: "#ffa42b"
                        },
                        unsafeForSmallText: {
                            base: "#ffa42b",
                            highlight: "#ffa42b",
                            press: "#ffa42b"
                        }
                    },
                    text: {
                        base: "#000000",
                        subdued: "#000000",
                        brightAccent: "#000000",
                        negative: "#000000",
                        warning: "#000000",
                        positive: "#000000",
                        announcement: "#000000"
                    },
                    essential: {
                        base: "#000000",
                        subdued: "#000000",
                        brightAccent: "#000000",
                        negative: "#000000",
                        warning: "#000000",
                        positive: "#000000",
                        announcement: "#000000"
                    },
                    decorative: {
                        base: "#000000",
                        subdued: "#f18900"
                    }
                },
                positive: {
                    background: {
                        base: "#1ed760",
                        highlight: "#1fdf64",
                        press: "#169c46",
                        elevated: {
                            base: "#1ed760",
                            highlight: "#1ed760",
                            press: "#1ed760"
                        },
                        tinted: {
                            base: "#1ed760",
                            highlight: "#1ed760",
                            press: "#1ed760"
                        },
                        unsafeForSmallText: {
                            base: "#1ed760",
                            highlight: "#1ed760",
                            press: "#1ed760"
                        }
                    },
                    text: {
                        base: "#000000",
                        subdued: "#000000",
                        brightAccent: "#000000",
                        negative: "#000000",
                        warning: "#000000",
                        positive: "#000000",
                        announcement: "#000000"
                    },
                    essential: {
                        base: "#000000",
                        subdued: "#000000",
                        brightAccent: "#000000",
                        negative: "#000000",
                        warning: "#000000",
                        positive: "#000000",
                        announcement: "#000000"
                    },
                    decorative: {
                        base: "#000000",
                        subdued: "#1abc54"
                    }
                },
                announcement: {
                    background: {
                        base: "#0d72ea",
                        highlight: "#0c6ddf",
                        press: "#084791",
                        elevated: {
                            base: "#0d72ea",
                            highlight: "#0d72ea",
                            press: "#0d72ea"
                        },
                        tinted: {
                            base: "#0d72ea",
                            highlight: "#0d72ea",
                            press: "#0d72ea"
                        },
                        unsafeForSmallText: {
                            base: "#0d72ea",
                            highlight: "#0d72ea",
                            press: "#0d72ea"
                        }
                    },
                    text: {
                        base: "#ffffff",
                        subdued: "#ffffff",
                        brightAccent: "#ffffff",
                        negative: "#ffffff",
                        warning: "#ffffff",
                        positive: "#ffffff",
                        announcement: "#ffffff"
                    },
                    essential: {
                        base: "#ffffff",
                        subdued: "#ffffff",
                        brightAccent: "#ffffff",
                        negative: "#ffffff",
                        warning: "#ffffff",
                        positive: "#ffffff",
                        announcement: "#ffffff"
                    },
                    decorative: {
                        base: "#ffffff",
                        subdued: "#2a86f3"
                    }
                },
                invertedDark: {
                    background: {
                        base: "#000000",
                        highlight: "#0d0d0d",
                        press: "#3f3f3f",
                        elevated: {
                            base: "#000000",
                            highlight: "#000000",
                            press: "#000000"
                        },
                        tinted: {
                            base: "#000000",
                            highlight: "#000000",
                            press: "#000000"
                        },
                        unsafeForSmallText: {
                            base: "#000000",
                            highlight: "#000000",
                            press: "#000000"
                        }
                    },
                    text: {
                        base: "#ffffff",
                        subdued: "#8f8f8f",
                        brightAccent: "#1ed760",
                        negative: "#ffffff",
                        warning: "#ffffff",
                        positive: "#ffffff",
                        announcement: "#ffffff"
                    },
                    essential: {
                        base: "#ffffff",
                        subdued: "#5e5e5e",
                        brightAccent: "#1ed760",
                        negative: "#ffffff",
                        warning: "#ffffff",
                        positive: "#ffffff",
                        announcement: "#ffffff"
                    },
                    decorative: {
                        base: "#ffffff",
                        subdued: "#1f1f1f"
                    }
                },
                invertedLight: {
                    background: {
                        base: "#ffffff",
                        highlight: "#f6f6f6",
                        press: "#b7b7b7",
                        elevated: {
                            base: "#ffffff",
                            highlight: "#ffffff",
                            press: "#ffffff"
                        },
                        tinted: {
                            base: "#ffffff",
                            highlight: "#ffffff",
                            press: "#ffffff"
                        },
                        unsafeForSmallText: {
                            base: "#ffffff",
                            highlight: "#ffffff",
                            press: "#ffffff"
                        }
                    },
                    text: {
                        base: "#000000",
                        subdued: "#5e5e5e",
                        brightAccent: "#12833a",
                        negative: "#000000",
                        warning: "#000000",
                        positive: "#000000",
                        announcement: "#000000"
                    },
                    essential: {
                        base: "#000000",
                        subdued: "#8f8f8f",
                        brightAccent: "#17a449",
                        negative: "#000000",
                        warning: "#000000",
                        positive: "#000000",
                        announcement: "#000000"
                    },
                    decorative: {
                        base: "#000000",
                        subdued: "#dedede"
                    }
                },
                mutedAccent: {
                    background: {
                        base: "#121212",
                        highlight: "#1a1a1a",
                        press: "#000000",
                        tinted: {
                            base: "rgba(255, 255, 255, 0.07)",
                            highlight: "rgba(255, 255, 255, 0.1)",
                            press: "rgba(255, 255, 255, 0.04)"
                        },
                        elevated: {
                            base: "#121212",
                            highlight: "#121212",
                            press: "#121212"
                        },
                        unsafeForSmallText: {
                            base: "#121212",
                            highlight: "#121212",
                            press: "#121212"
                        }
                    },
                    text: {
                        base: "#ffffff",
                        subdued: "#a7a7a7",
                        brightAccent: "#1ed760",
                        negative: "#ffffff",
                        warning: "#ffffff",
                        positive: "#ffffff",
                        announcement: "#ffffff"
                    },
                    essential: {
                        base: "#ffffff",
                        subdued: "#727272",
                        brightAccent: "#1ed760",
                        negative: "#ffffff",
                        warning: "#ffffff",
                        positive: "#ffffff",
                        announcement: "#ffffff"
                    },
                    decorative: {
                        base: "#ffffff",
                        subdued: "#292929"
                    }
                },
                overMedia: {
                    background: {
                        base: "rgba(0, 0, 0, 0.53)",
                        highlight: "rgba(0, 0, 0, 0.56)",
                        press: "rgba(0, 0, 0, 0.71)",
                        unsafeForSmallText: {
                            base: "rgba(0, 0, 0, 0.42)",
                            highlight: "rgba(0, 0, 0, 0.44)",
                            press: "rgba(0, 0, 0, 0.61)"
                        },
                        elevated: {
                            base: "rgba(0, 0, 0, 0.53)",
                            highlight: "rgba(0, 0, 0, 0.53)",
                            press: "rgba(0, 0, 0, 0.53)"
                        },
                        tinted: {
                            base: "rgba(0, 0, 0, 0.53)",
                            highlight: "rgba(0, 0, 0, 0.53)",
                            press: "rgba(0, 0, 0, 0.53)"
                        }
                    },
                    text: {
                        base: "#ffffff",
                        subdued: "#ffffff",
                        brightAccent: "#ffffff",
                        negative: "#ffffff",
                        warning: "#ffffff",
                        positive: "#ffffff",
                        announcement: "#ffffff"
                    },
                    essential: {
                        base: "#ffffff",
                        subdued: "#ffffff",
                        brightAccent: "#ffffff",
                        negative: "#ffffff",
                        warning: "#ffffff",
                        positive: "#ffffff",
                        announcement: "#ffffff"
                    },
                    decorative: {
                        base: "#ffffff",
                        subdued: "rgba(255, 255, 255, 0.13)"
                    }
                }
            }
        }
    }
]);
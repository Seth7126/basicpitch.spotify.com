"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [264], {
        79309: function(i, t, e) {
            e.d(t, {
                aP: function() {
                    return m
                },
                fN: function() {
                    return b
                },
                nx: function() {
                    return v
                }
            });
            var n = e(7279),
                s = e(88649),
                r = e(30870),
                a = e(61918),
                l = e(35953),
                h = e(27239),
                o = e(46422),
                d = e(76729),
                u = e(72279),
                p = e(84755),
                c = e(9049),
                g = e(84717),
                f = e(97708);

            function m(i, t) {
                return (0, n.lub)((() => ((0, l.cj)(t), "channelsFirst" === t ? n.p4s(i, [0, 2, 3, 1]) : i)))
            }

            function b(i, t) {
                return (0, n.lub)((() => ((0, l.cj)(t), "channelsFirst" === t ? n.p4s(i, [0, 2, 3, 4, 1]) : i)))
            }

            function k(i, t, e, s = 1, h = "valid", o, u = 1) {
                return (0, n.lub)((() => {
                    if (null == o && (o = (0, r.rf)()), (0, l.cj)(o), 3 !== i.shape.length) throw new d.nu(`The input of a conv1dWithBias operation should be 3, but is ${i.shape.length} instead.`);
                    if (3 !== t.shape.length) throw new d.nu(`The kernel for a conv1dWithBias operation should be 3, but is ${t.shape.length} instead`);
                    if (null != e && 1 !== e.shape.length) throw new d.nu(`The bias for a conv1dWithBias operation should be 1, but is ${t.shape.length} instead`);
                    if ("channelsFirst" === o && (i = n.p4s(i, [0, 2, 1])), "causal" === h) throw new d.nj("The support for CAUSAL padding mode in conv1dWithBias is not implemented yet.");
                    let p = n.PAt(i, t, s, "same" === h ? "same" : "valid", "NWC", u);
                    return null != e && (p = a.a2(p, e)), p
                }))
            }

            function w(i, t, e, s = [1, 1], a = "valid", h, o, u = null) {
                return (0, n.lub)((() => {
                    if (null == h && (h = (0, r.rf)()), (0, l.cj)(h), 3 !== i.rank && 4 !== i.rank) throw new d.nu(`conv2dWithBiasActivation expects input to be of rank 3 or 4, but received ${i.rank}.`);
                    if (3 !== t.rank && 4 !== t.rank) throw new d.nu(`conv2dWithBiasActivation expects kernel to be of rank 3 or 4, but received ${i.rank}.`);
                    let p = m(i, h);
                    if ("causal" === a) throw new d.nj("The support for CAUSAL padding mode in conv1dWithBias is not implemented yet.");
                    return p = n.imm.conv2d({
                        x: p,
                        filter: t,
                        strides: s,
                        pad: "same" === a ? "same" : "valid",
                        dilations: o,
                        dataFormat: "NHWC",
                        bias: e,
                        activation: u
                    }), "channelsFirst" === h && (p = n.p4s(p, [0, 3, 1, 2])), p
                }))
            }

            function z(i, t, e, s = [1, 1, 1], h = "valid", o, u) {
                return (0, n.lub)((() => {
                    if (null == o && (o = (0, r.rf)()), (0, l.cj)(o), 4 !== i.rank && 5 !== i.rank) throw new d.nu(`conv3dWithBias expects input to be of rank 4 or 5, but received ${i.rank}.`);
                    if (4 !== t.rank && 5 !== t.rank) throw new d.nu(`conv3dWithBias expects kernel to be of rank 4 or 5, but received ${i.rank}.`);
                    let p = b(i, o);
                    if ("causal" === h) throw new d.nj("The support for CAUSAL padding mode in conv3dWithBias is not implemented yet.");
                    return p = n.pdZ(p, t, s, "same" === h ? "same" : "valid", "NDHWC", u), null != e && (p = a.a2(p, e)), "channelsFirst" === o && (p = n.p4s(p, [0, 4, 1, 2, 3])), p
                }))
            }
            class v extends o.mh {
                constructor(i, t) {
                    if (super(t), this.bias = null, this.DEFAULT_KERNEL_INITIALIZER = "glorotNormal", this.DEFAULT_BIAS_INITIALIZER = "zeros", v.verifyArgs(t), this.rank = i, g.iQ(this.rank, "rank"), 1 !== this.rank && 2 !== this.rank && 3 !== this.rank) throw new d.nj(`Convolution layer for rank other than 1, 2, or 3 (${this.rank}) is not implemented yet.`);
                    if (this.kernelSize = (0, c.AF)(t.kernelSize, i, "kernelSize"), this.strides = (0, c.AF)(null == t.strides ? 1 : t.strides, i, "strides"), this.padding = null == t.padding ? "valid" : t.padding, (0, l.zb)(this.padding), this.dataFormat = null == t.dataFormat ? "channelsLast" : t.dataFormat, (0, l.cj)(this.dataFormat), this.activation = (0, s.aI)(t.activation), this.useBias = null == t.useBias || t.useBias, this.biasInitializer = (0, u.L5)(t.biasInitializer || this.DEFAULT_BIAS_INITIALIZER), this.biasConstraint = (0, h.Ad)(t.biasConstraint), this.biasRegularizer = (0, p.EC)(t.biasRegularizer), this.activityRegularizer = (0, p.EC)(t.activityRegularizer), this.dilationRate = (0, c.AF)(null == t.dilationRate ? 1 : t.dilationRate, i, "dilationRate"), 1 === this.rank && Array.isArray(this.dilationRate) && 1 !== this.dilationRate.length) throw new d.nu(`dilationRate must be a number or an array of a single number for 1D convolution, but received ${JSON.stringify(this.dilationRate)}`);
                    if (2 === this.rank) {
                        if ("number" === typeof this.dilationRate) this.dilationRate = [this.dilationRate, this.dilationRate];
                        else if (2 !== this.dilationRate.length) throw new d.nu(`dilationRate must be a number or array of two numbers for 2D convolution, but received ${JSON.stringify(this.dilationRate)}`)
                    } else if (3 === this.rank)
                        if ("number" === typeof this.dilationRate) this.dilationRate = [this.dilationRate, this.dilationRate, this.dilationRate];
                        else if (3 !== this.dilationRate.length) throw new d.nu(`dilationRate must be a number or array of three numbers for 3D convolution, but received ${JSON.stringify(this.dilationRate)}`)
                }
                static verifyArgs(i) {
                    if (g.hu("kernelSize" in i, "required key 'kernelSize' not in config"), "number" !== typeof i.kernelSize && !g.Mx(i.kernelSize, "number", 1, 3)) throw new d.nu(`BaseConv expects config.kernelSize to be number or number[] with length 1, 2, or 3, but received ${JSON.stringify(i.kernelSize)}.`)
                }
                getConfig() {
                    const i = {
                            kernelSize: this.kernelSize,
                            strides: this.strides,
                            padding: this.padding,
                            dataFormat: this.dataFormat,
                            dilationRate: this.dilationRate,
                            activation: (0, s.GD)(this.activation),
                            useBias: this.useBias,
                            biasInitializer: (0, u.Cx)(this.biasInitializer),
                            biasRegularizer: (0, p.SG)(this.biasRegularizer),
                            activityRegularizer: (0, p.SG)(this.activityRegularizer),
                            biasConstraint: (0, h.xF)(this.biasConstraint)
                        },
                        t = super.getConfig();
                    return Object.assign(i, t), i
                }
            }
            class C extends v {
                constructor(i, t) {
                    super(i, t), this.kernel = null, C.verifyArgs(t), this.filters = t.filters, g.iQ(this.filters, "filters"), this.kernelInitializer = (0, u.L5)(t.kernelInitializer || this.DEFAULT_KERNEL_INITIALIZER), this.kernelConstraint = (0, h.Ad)(t.kernelConstraint), this.kernelRegularizer = (0, p.EC)(t.kernelRegularizer)
                }
                build(i) {
                    i = (0, f.Wf)(i);
                    const t = "channelsFirst" === this.dataFormat ? 1 : i.length - 1;
                    if (null == i[t]) throw new d.nu(`The channel dimension of the input should be defined. Found ${i[t]}`);
                    const e = i[t],
                        n = this.kernelSize.concat([e, this.filters]);
                    this.kernel = this.addWeight("kernel", n, null, this.kernelInitializer, this.kernelRegularizer, !0, this.kernelConstraint), this.useBias && (this.bias = this.addWeight("bias", [this.filters], null, this.biasInitializer, this.biasRegularizer, !0, this.biasConstraint)), this.inputSpec = [{
                        ndim: this.rank + 2,
                        axes: {
                            [t]: e
                        }
                    }], this.built = !0
                }
                call(i, t) {
                    return (0, n.lub)((() => {
                        let t;
                        i = (0, f.nQ)(i);
                        const e = null == this.bias ? null : this.bias.read(),
                            n = g.WT(this.activation.getClassName());
                        if (null != n && 2 === this.rank) t = w(i, this.kernel.read(), e, this.strides, this.padding, this.dataFormat, this.dilationRate, n);
                        else {
                            if (1 === this.rank) t = k(i, this.kernel.read(), e, this.strides[0], this.padding, this.dataFormat, this.dilationRate[0]);
                            else if (2 === this.rank) t = w(i, this.kernel.read(), e, this.strides, this.padding, this.dataFormat, this.dilationRate);
                            else {
                                if (3 !== this.rank) throw new d.nj("convolutions greater than 3D are not implemented yet.");
                                t = z(i, this.kernel.read(), e, this.strides, this.padding, this.dataFormat, this.dilationRate)
                            }
                            null != this.activation && (t = this.activation.apply(t))
                        }
                        return t
                    }))
                }
                computeOutputShape(i) {
                    i = (0, f.Wf)(i);
                    const t = [],
                        e = "channelsLast" === this.dataFormat ? i.slice(1, i.length - 1) : i.slice(2);
                    for (let s = 0; s < e.length; ++s) {
                        const i = (0, c.kt)(e[s], this.kernelSize[s], this.padding, this.strides[s], "number" === typeof this.dilationRate ? this.dilationRate : this.dilationRate[s]);
                        t.push(i)
                    }
                    let n = [i[0]];
                    return "channelsLast" === this.dataFormat ? (n = n.concat(t), n.push(this.filters)) : (n.push(this.filters), n = n.concat(t)), n
                }
                getConfig() {
                    const i = {
                            filters: this.filters,
                            kernelInitializer: (0, u.Cx)(this.kernelInitializer),
                            kernelRegularizer: (0, p.SG)(this.kernelRegularizer),
                            kernelConstraint: (0, h.xF)(this.kernelConstraint)
                        },
                        t = super.getConfig();
                    return Object.assign(i, t), i
                }
                static verifyArgs(i) {
                    if (!("filters" in i) || "number" !== typeof i.filters || i.filters < 1) throw new d.nu(`Convolution layer expected config.filters to be a 'number' > 0 but got ${JSON.stringify(i.filters)}`)
                }
            }
            class S extends C {
                constructor(i) {
                    super(2, i), S.verifyArgs(i)
                }
                getConfig() {
                    const i = super.getConfig();
                    return delete i.rank, i
                }
                static verifyArgs(i) {
                    if ("number" !== typeof i.kernelSize && !g.Mx(i.kernelSize, "number", 1, 2)) throw new d.nu(`Conv2D expects config.kernelSize to be number or number[] with length 1 or 2, but received ${JSON.stringify(i.kernelSize)}.`)
                }
            }
            S.className = "Conv2D", n.m7h.registerClass(S);
            class F extends C {
                constructor(i) {
                    super(3, i), F.verifyArgs(i)
                }
                getConfig() {
                    const i = super.getConfig();
                    return delete i.rank, i
                }
                static verifyArgs(i) {
                    if ("number" !== typeof i.kernelSize && (!Array.isArray(i.kernelSize) || 1 !== i.kernelSize.length && 3 !== i.kernelSize.length)) throw new d.nu(`Conv3D expects config.kernelSize to be number or [number, number, number], but received ${JSON.stringify(i.kernelSize)}.`)
                }
            }
            F.className = "Conv3D", n.m7h.registerClass(F);
            class I extends S {
                constructor(i) {
                    if (super(i), this.inputSpec = [new o.Zg({
                            ndim: 4
                        })], "same" !== this.padding && "valid" !== this.padding) throw new d.nu(`Conv2DTranspose currently supports only padding modes 'same' and 'valid', but received padding mode ${this.padding}`)
                }
                build(i) {
                    if (4 !== (i = (0, f.Wf)(i)).length) throw new d.nu("Input should have rank 4; Received input shape: " + JSON.stringify(i));
                    const t = "channelsFirst" === this.dataFormat ? 1 : i.length - 1;
                    if (null == i[t]) throw new d.nu("The channel dimension of the inputs should be defined. Found `None`.");
                    const e = i[t],
                        n = this.kernelSize.concat([this.filters, e]);
                    this.kernel = this.addWeight("kernel", n, "float32", this.kernelInitializer, this.kernelRegularizer, !0, this.kernelConstraint), this.useBias && (this.bias = this.addWeight("bias", [this.filters], "float32", this.biasInitializer, this.biasRegularizer, !0, this.biasConstraint)), this.inputSpec = [new o.Zg({
                        ndim: 4,
                        axes: {
                            [t]: e
                        }
                    })], this.built = !0
                }
                call(i, t) {
                    return n.lub((() => {
                        let t = (0, f.nQ)(i);
                        if (4 !== t.shape.length) throw new d.nu(`Conv2DTranspose.call() expects input tensor to be rank-4, but received a tensor of rank-${t.shape.length}`);
                        const e = t.shape,
                            s = e[0];
                        let r, l;
                        "channelsFirst" === this.dataFormat ? (r = 2, l = 3) : (r = 1, l = 2);
                        const h = e[r],
                            o = e[l],
                            u = this.kernelSize[0],
                            p = this.kernelSize[1],
                            g = this.strides[0],
                            m = this.strides[1],
                            b = [s, (0, c.$U)(h, g, u, this.padding), (0, c.$U)(o, m, p, this.padding), this.filters];
                        "channelsLast" !== this.dataFormat && (t = n.p4s(t, [0, 2, 3, 1]));
                        let k = n.bc(t, this.kernel.read(), b, this.strides, this.padding);
                        return "channelsLast" !== this.dataFormat && (k = n.p4s(k, [0, 3, 1, 2])), null != this.bias && (k = a.a2(k, this.bias.read(), this.dataFormat)), null != this.activation && (k = this.activation.apply(k)), k
                    }))
                }
                computeOutputShape(i) {
                    const t = (i = (0, f.Wf)(i)).slice();
                    let e, n, s;
                    "channelsFirst" === this.dataFormat ? (e = 1, n = 2, s = 3) : (e = 3, n = 1, s = 2);
                    const r = this.kernelSize[0],
                        a = this.kernelSize[1],
                        l = this.strides[0],
                        h = this.strides[1];
                    return t[e] = this.filters, t[n] = (0, c.$U)(t[n], l, r, this.padding), t[s] = (0, c.$U)(t[s], h, a, this.padding), t
                }
                getConfig() {
                    const i = super.getConfig();
                    return delete i.dilationRate, i
                }
            }
            I.className = "Conv2DTranspose", n.m7h.registerClass(I);
            class R extends F {
                constructor(i) {
                    if (super(i), this.inputSpec = [new o.Zg({
                            ndim: 5
                        })], "same" !== this.padding && "valid" !== this.padding) throw new d.nu(`Conv3DTranspose currently supports only padding modes 'same' and 'valid', but received padding mode ${this.padding}`)
                }
                build(i) {
                    if (5 !== (i = (0, f.Wf)(i)).length) throw new d.nu("Input should have rank 5; Received input shape: " + JSON.stringify(i));
                    const t = "channelsFirst" === this.dataFormat ? 1 : i.length - 1;
                    if (null == i[t]) throw new d.nu("The channel dimension of the inputs should be defined. Found `None`.");
                    const e = i[t],
                        n = this.kernelSize.concat([this.filters, e]);
                    this.kernel = this.addWeight("kernel", n, "float32", this.kernelInitializer, this.kernelRegularizer, !0, this.kernelConstraint), this.useBias && (this.bias = this.addWeight("bias", [this.filters], "float32", this.biasInitializer, this.biasRegularizer, !0, this.biasConstraint)), this.inputSpec = [new o.Zg({
                        ndim: 5,
                        axes: {
                            [t]: e
                        }
                    })], this.built = !0
                }
                call(i, t) {
                    return n.lub((() => {
                        let t = (0, f.nQ)(i);
                        if (5 !== t.shape.length) throw new d.nu(`Conv3DTranspose.call() expects input tensor to be rank-4, but received a tensor of rank-${t.shape.length}`);
                        const e = t.shape,
                            s = e[0];
                        let r, l, h;
                        "channelsFirst" === this.dataFormat ? (h = 2, r = 3, l = 4) : (h = 1, r = 2, l = 3);
                        const o = e[h],
                            u = e[r],
                            p = e[l],
                            g = this.kernelSize[0],
                            m = this.kernelSize[1],
                            b = this.kernelSize[2],
                            k = this.strides[0],
                            w = this.strides[1],
                            z = this.strides[2],
                            v = [s, (0, c.$U)(o, k, g, this.padding), (0, c.$U)(u, w, m, this.padding), (0, c.$U)(p, z, b, this.padding), this.filters];
                        "channelsLast" !== this.dataFormat && (t = n.p4s(t, [0, 2, 3, 4, 1]));
                        let C = n.$QV(t, this.kernel.read(), v, this.strides, this.padding);
                        return "channelsLast" !== this.dataFormat && (C = n.p4s(C, [0, 4, 1, 2, 3])), null !== this.bias && (C = a.a2(C, this.bias.read(), this.dataFormat)), null !== this.activation && (C = this.activation.apply(C)), C
                    }))
                }
                computeOutputShape(i) {
                    const t = (i = (0, f.Wf)(i)).slice();
                    let e, n, s, r;
                    "channelsFirst" === this.dataFormat ? (e = 1, n = 2, s = 3, r = 4) : (e = 4, n = 1, s = 2, r = 3);
                    const a = this.kernelSize[0],
                        l = this.kernelSize[1],
                        h = this.kernelSize[2],
                        o = this.strides[0],
                        d = this.strides[1],
                        u = this.strides[2];
                    return t[e] = this.filters, t[n] = (0, c.$U)(t[n], o, a, this.padding), t[s] = (0, c.$U)(t[s], d, l, this.padding), t[r] = (0, c.$U)(t[r], u, h, this.padding), t
                }
                getConfig() {
                    const i = super.getConfig();
                    return delete i.dilationRate, i
                }
            }
            R.className = "Conv3DTranspose", n.m7h.registerClass(R);
            class y extends C {
                constructor(i, t) {
                    if (super(i, t), this.DEFAULT_DEPTHWISE_INITIALIZER = "glorotUniform", this.DEFAULT_POINTWISE_INITIALIZER = "glorotUniform", this.depthwiseKernel = null, this.pointwiseKernel = null, null == t.filters) throw new d.nu("The `filters` configuration field is required by SeparableConv, but is unspecified.");
                    if (null != t.kernelInitializer || null != t.kernelRegularizer || null != t.kernelConstraint) throw new d.nu("Fields kernelInitializer, kernelRegularizer and kernelConstraint are invalid for SeparableConv2D. Use depthwiseInitializer, depthwiseRegularizer, depthwiseConstraint, pointwiseInitializer, pointwiseRegularizer and pointwiseConstraint instead.");
                    if (null != t.padding && "same" !== t.padding && "valid" !== t.padding) throw new d.nu(`SeparableConv${this.rank}D supports only padding modes: 'same' and 'valid', but received ${JSON.stringify(t.padding)}`);
                    this.depthMultiplier = null == t.depthMultiplier ? 1 : t.depthMultiplier, this.depthwiseInitializer = (0, u.L5)(t.depthwiseInitializer || this.DEFAULT_DEPTHWISE_INITIALIZER), this.depthwiseRegularizer = (0, p.EC)(t.depthwiseRegularizer), this.depthwiseConstraint = (0, h.Ad)(t.depthwiseConstraint), this.pointwiseInitializer = (0, u.L5)(t.depthwiseInitializer || this.DEFAULT_POINTWISE_INITIALIZER), this.pointwiseRegularizer = (0, p.EC)(t.pointwiseRegularizer), this.pointwiseConstraint = (0, h.Ad)(t.pointwiseConstraint)
                }
                build(i) {
                    if ((i = (0, f.Wf)(i)).length < this.rank + 2) throw new d.nu(`Inputs to SeparableConv${this.rank}D should have rank ${this.rank+2}, but received input shape: ${JSON.stringify(i)}`);
                    const t = "channelsFirst" === this.dataFormat ? 1 : i.length - 1;
                    if (null == i[t] || i[t] < 0) throw new d.nu(`The channel dimension of the inputs should be defined, but found ${JSON.stringify(i[t])}`);
                    const e = i[t],
                        n = this.kernelSize.concat([e, this.depthMultiplier]),
                        s = [];
                    for (let a = 0; a < this.rank; ++a) s.push(1);
                    s.push(e * this.depthMultiplier, this.filters);
                    const r = !0;
                    this.depthwiseKernel = this.addWeight("depthwise_kernel", n, "float32", this.depthwiseInitializer, this.depthwiseRegularizer, r, this.depthwiseConstraint), this.pointwiseKernel = this.addWeight("pointwise_kernel", s, "float32", this.pointwiseInitializer, this.pointwiseRegularizer, r, this.pointwiseConstraint), this.useBias ? this.bias = this.addWeight("bias", [this.filters], "float32", this.biasInitializer, this.biasRegularizer, r, this.biasConstraint) : this.bias = null, this.inputSpec = [new o.Zg({
                        ndim: this.rank + 2,
                        axes: {
                            [t]: e
                        }
                    })], this.built = !0
                }
                call(i, t) {
                    return (0, n.lub)((() => {
                        let t;
                        if (i = (0, f.nQ)(i), 1 === this.rank) throw new d.nj("1D separable convolution is not implemented yet.");
                        return 2 === this.rank && ("channelsFirst" === this.dataFormat && (i = n.p4s(i, [0, 2, 3, 1])), t = n.U_I(i, this.depthwiseKernel.read(), this.pointwiseKernel.read(), this.strides, this.padding, this.dilationRate, "NHWC")), this.useBias && (t = a.a2(t, this.bias.read(), this.dataFormat)), null != this.activation && (t = this.activation.apply(t)), "channelsFirst" === this.dataFormat && (t = n.p4s(t, [0, 3, 1, 2])), t
                    }))
                }
                getConfig() {
                    const i = super.getConfig();
                    return delete i.rank, delete i.kernelInitializer, delete i.kernelRegularizer, delete i.kernelConstraint, i.depthwiseInitializer = (0, u.Cx)(this.depthwiseInitializer), i.pointwiseInitializer = (0, u.Cx)(this.pointwiseInitializer), i.depthwiseRegularizer = (0, p.SG)(this.depthwiseRegularizer), i.pointwiseRegularizer = (0, p.SG)(this.pointwiseRegularizer), i.depthwiseConstraint = (0, h.xF)(this.depthwiseConstraint), i.pointwiseConstraint = (0, h.xF)(this.pointwiseConstraint), i
                }
            }
            y.className = "SeparableConv";
            class A extends y {
                constructor(i) {
                    super(2, i)
                }
            }
            A.className = "SeparableConv2D", n.m7h.registerClass(A);
            class N extends C {
                constructor(i) {
                    super(1, i), N.verifyArgs(i), this.inputSpec = [{
                        ndim: 3
                    }]
                }
                getConfig() {
                    const i = super.getConfig();
                    return delete i.rank, delete i.dataFormat, i
                }
                static verifyArgs(i) {
                    if ("number" !== typeof i.kernelSize && !g.Mx(i.kernelSize, "number", 1, 1)) throw new d.nu(`Conv1D expects config.kernelSize to be number or number[] with length 1, but received ${JSON.stringify(i.kernelSize)}.`)
                }
            }
            N.className = "Conv1D", n.m7h.registerClass(N);
            class T extends o.mh {
                constructor(i) {
                    super(i), "number" === typeof i.cropping ? this.cropping = [
                        [i.cropping, i.cropping],
                        [i.cropping, i.cropping]
                    ] : "number" === typeof i.cropping[0] ? this.cropping = [
                        [i.cropping[0], i.cropping[0]],
                        [i.cropping[1], i.cropping[1]]
                    ] : this.cropping = i.cropping, this.dataFormat = void 0 === i.dataFormat ? "channelsLast" : i.dataFormat, this.inputSpec = [{
                        ndim: 4
                    }]
                }
                computeOutputShape(i) {
                    return "channelsFirst" === this.dataFormat ? [i[0], i[1], i[2] - this.cropping[0][0] - this.cropping[0][1], i[3] - this.cropping[1][0] - this.cropping[1][1]] : [i[0], i[1] - this.cropping[0][0] - this.cropping[0][1], i[2] - this.cropping[1][0] - this.cropping[1][1], i[3]]
                }
                call(i, t) {
                    return (0, n.lub)((() => {
                        if (i = (0, f.nQ)(i), "channelsLast" === this.dataFormat) {
                            const t = a.uI(i, this.cropping[0][0], i.shape[1] - this.cropping[0][0] - this.cropping[0][1], 2);
                            return a.uI(t, this.cropping[1][0], i.shape[2] - this.cropping[1][1] - this.cropping[1][0], 3)
                        } {
                            const t = a.uI(i, this.cropping[0][0], i.shape[2] - this.cropping[0][0] - this.cropping[0][1], 3);
                            return a.uI(t, this.cropping[1][0], i.shape[3] - this.cropping[1][1] - this.cropping[1][0], 4)
                        }
                    }))
                }
                getConfig() {
                    const i = {
                            cropping: this.cropping,
                            dataFormat: this.dataFormat
                        },
                        t = super.getConfig();
                    return Object.assign(i, t), i
                }
            }
            T.className = "Cropping2D", n.m7h.registerClass(T);
            class x extends o.mh {
                constructor(i) {
                    super(i), this.DEFAULT_SIZE = [2, 2], this.inputSpec = [{
                        ndim: 4
                    }], this.size = null == i.size ? this.DEFAULT_SIZE : i.size, this.dataFormat = null == i.dataFormat ? "channelsLast" : i.dataFormat, (0, l.cj)(this.dataFormat), this.interpolation = null == i.interpolation ? "nearest" : i.interpolation, (0, l.wU)(this.interpolation)
                }
                computeOutputShape(i) {
                    if ("channelsFirst" === this.dataFormat) {
                        const t = null == i[2] ? null : this.size[0] * i[2],
                            e = null == i[3] ? null : this.size[1] * i[3];
                        return [i[0], i[1], t, e]
                    } {
                        const t = null == i[1] ? null : this.size[0] * i[1],
                            e = null == i[2] ? null : this.size[1] * i[2];
                        return [i[0], t, e, i[3]]
                    }
                }
                call(i, t) {
                    return n.lub((() => {
                        let t = (0, f.nQ)(i);
                        const e = t.shape;
                        if ("channelsFirst" === this.dataFormat) {
                            t = n.p4s(t, [0, 2, 3, 1]);
                            const i = this.size[0] * e[2],
                                s = this.size[1] * e[3],
                                r = "nearest" === this.interpolation ? n.BHj.resizeNearestNeighbor(t, [i, s]) : n.BHj.resizeBilinear(t, [i, s]);
                            return n.p4s(r, [0, 3, 1, 2])
                        } {
                            const i = this.size[0] * e[1],
                                s = this.size[1] * e[2];
                            return "nearest" === this.interpolation ? n.BHj.resizeNearestNeighbor(t, [i, s]) : n.BHj.resizeBilinear(t, [i, s])
                        }
                    }))
                }
                getConfig() {
                    const i = {
                            size: this.size,
                            dataFormat: this.dataFormat,
                            interpolation: this.interpolation
                        },
                        t = super.getConfig();
                    return Object.assign(i, t), i
                }
            }
            x.className = "UpSampling2D", n.m7h.registerClass(x)
        }
    }
]);
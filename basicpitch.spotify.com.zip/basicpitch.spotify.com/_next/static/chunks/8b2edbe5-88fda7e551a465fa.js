"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [389], {
        26639: function(t, e, i) {
            i.d(e, {
                $p: function() {
                    return S
                },
                U7: function() {
                    return E
                },
                _0: function() {
                    return T
                },
                lx: function() {
                    return z
                },
                nd: function() {
                    return A
                }
            });
            var s = i(7279),
                r = i(88649),
                n = i(61918),
                l = i(35953),
                a = i(27239),
                u = i(46422),
                o = i(76729),
                h = i(72279),
                c = i(84755),
                p = i(84717),
                g = i(66520),
                d = i(97708),
                I = i(7696),
                C = i(12764);

            function z(t, e, i, s) {
                if (Array.isArray(t)) {
                    if (null != e || null != i) throw new o.nu("When inputs is an array, neither initialState or constants should be provided");
                    null != s && (i = t.slice(t.length - s, t.length), t = t.slice(0, t.length - s)), t.length > 1 && (e = t.slice(1, t.length)), t = t[0]
                }

                function r(t) {
                    return null == t || Array.isArray(t) ? t : [t]
                }
                return {
                    inputs: t,
                    initialState: e = r(e),
                    constants: i = r(i)
                }
            }

            function A(t, e, i, r = !1, n, l, a = !1, u = !1) {
                return s.lub((() => {
                    const h = e.shape.length;
                    if (h < 3) throw new o.nu(`Input should be at least 3D, but is ${h}D.`);
                    const c = [1, 0].concat(g.w6(2, h));
                    if (e = s.p4s(e, c), null != l) throw new o.nj("The rnn() functoin of the deeplearn.js backend does not support constants yet.");
                    a && console.warn("Backend rnn(): the unroll = true option is not applicable to the imperative deeplearn.js backend."), null != n && ((n = s.pju(s.pju(n, "bool"), "float32")).rank === h - 1 && (n = s.dt4(n, -1)), n = s.p4s(n, c)), r && (e = s.GYS(e, 0), null != n && (n = s.GYS(n, 0)));
                    const p = [];
                    let d, I = i;
                    const C = e.shape[0],
                        z = s.HHK(e);
                    let A, S;
                    null != n && (A = s.HHK(n));
                    for (let e = 0; e < C; ++e) {
                        const i = z[e],
                            r = s.lub((() => t(i, I)));
                        if (null == n) d = r[0], I = r[1];
                        else {
                            const t = s.lub((() => {
                                const t = A[e],
                                    i = s.luU(s.JpU(t), t);
                                return {
                                    output: s.IHx(s.dC7(r[0], t), s.dC7(I[0], i)),
                                    newStates: I.map(((e, n) => s.IHx(s.dC7(r[1][n], t), s.dC7(e, i))))
                                }
                            }));
                            d = t.output, I = t.newStates
                        }
                        u && p.push(d)
                    }
                    if (u) {
                        const t = 1;
                        S = s.knu(p, t)
                    }
                    return [d, S, I]
                }))
            }
            class S extends u.mh {
                constructor(t) {
                    let e;
                    if (super(t), null == t.cell) throw new o.nu("cell property is missing for the constructor of RNN.");
                    if (e = Array.isArray(t.cell) ? new D({
                            cells: t.cell
                        }) : t.cell, null == e.stateSize) throw new o.nu("The RNN cell should have an attribute `stateSize` (tuple of integers, one integer per RNN state).");
                    this.cell = e, this.returnSequences = null != t.returnSequences && t.returnSequences, this.returnState = null != t.returnState && t.returnState, this.goBackwards = null != t.goBackwards && t.goBackwards, this._stateful = null != t.stateful && t.stateful, this.unroll = null != t.unroll && t.unroll, this.supportsMasking = !0, this.inputSpec = [new u.Zg({
                        ndim: 3
                    })], this.stateSpec = null, this.states_ = null, this.numConstants = null, this.keptStates = []
                }
                getStates() {
                    if (null == this.states_) {
                        const t = Array.isArray(this.cell.stateSize) ? this.cell.stateSize.length : 1;
                        return g.w6(0, t).map((t => null))
                    }
                    return this.states_
                }
                setStates(t) {
                    this.states_ = t
                }
                computeOutputShape(t) {
                    (0, d.XO)(t) && (t = t[0]);
                    let e = this.cell.stateSize;
                    Array.isArray(e) || (e = [e]);
                    const i = e[0];
                    let s;
                    if (s = this.returnSequences ? [t[0], t[1], i] : [t[0], i], this.returnState) {
                        const i = [];
                        for (const s of e) i.push([t[0], s]);
                        return [s].concat(i)
                    }
                    return s
                }
                computeMask(t, e) {
                    return s.lub((() => {
                        Array.isArray(e) && (e = e[0]);
                        const t = this.returnSequences ? e : null;
                        if (this.returnState) {
                            const e = this.states.map((t => null));
                            return [t].concat(e)
                        }
                        return t
                    }))
                }
                get states() {
                    if (null == this.states_) {
                        const t = Array.isArray(this.cell.stateSize) ? this.cell.stateSize.length : 1,
                            e = [];
                        for (let i = 0; i < t; ++i) e.push(null);
                        return e
                    }
                    return this.states_
                }
                set states(t) {
                    this.states_ = t
                }
                build(t) {
                    if (null != this.numConstants) throw new o.nj("Constants support is not implemented in RNN yet.");
                    (0, d.XO)(t) && (t = t[0]);
                    const e = this.stateful ? t[0] : null,
                        i = t.slice(2);
                    this.inputSpec[0] = new u.Zg({
                        shape: [e, null, ...i]
                    });
                    const r = [t[0]].concat(t.slice(2));
                    let n;
                    if (this.cell.build(r), n = Array.isArray(this.cell.stateSize) ? this.cell.stateSize : [this.cell.stateSize], null != this.stateSpec) {
                        if (!s.D5U.arraysEqual(this.stateSpec.map((t => t.shape[t.shape.length - 1])), n)) throw new o.nu(`An initialState was passed that is not compatible with cell.stateSize. Received stateSpec=${this.stateSpec}; However cell.stateSize is ${this.cell.stateSize}`)
                    } else this.stateSpec = n.map((t => new u.Zg({
                        shape: [null, t]
                    })));
                    this.stateful && this.resetStates()
                }
                resetStates(t, e = !1) {
                    (0, s.lub)((() => {
                        if (!this.stateful) throw new o.j1("Cannot call resetStates() on an RNN Layer that is not stateful.");
                        const i = this.inputSpec[0].shape[0];
                        if (null == i) throw new o.nu("If an RNN is stateful, it needs to know its batch size. Specify the batch size of your input tensors: \n- If using a Sequential model, specify the batch size by passing a `batchInputShape` option to your first layer.\n- If using the functional API, specify the batch size by passing a `batchShape` option to your Input layer.");
                        if (null == this.states_) Array.isArray(this.cell.stateSize) ? this.states_ = this.cell.stateSize.map((t => s.lls([i, t]))) : this.states_ = [s.lls([i, this.cell.stateSize])];
                        else if (null == t) s.B90(this.states_), null != this.keptStates && (s.B90(this.keptStates), this.keptStates = []), Array.isArray(this.cell.stateSize) ? this.states_ = this.cell.stateSize.map((t => s.lls([i, t]))) : this.states_[0] = s.lls([i, this.cell.stateSize]);
                        else {
                            if (Array.isArray(t) || (t = [t]), t.length !== this.states_.length) throw new o.nu(`Layer ${this.name} expects ${this.states_.length} state(s), but it received ${t.length} state value(s). Input received: ${t}`);
                            !0 === e ? this.keptStates.push(this.states_.slice()) : s.B90(this.states_);
                            for (let e = 0; e < this.states_.length; ++e) {
                                const r = t[e],
                                    n = Array.isArray(this.cell.stateSize) ? this.cell.stateSize[e] : this.cell.stateSize,
                                    l = [i, n];
                                if (!s.D5U.arraysEqual(r.shape, l)) throw new o.nu(`State ${e} is incompatible with layer ${this.name}: expected shape=${l}, received shape=${r.shape}`);
                                this.states_[e] = r
                            }
                        }
                        this.states_ = this.states_.map((t => s.CnY(t.clone())))
                    }))
                }
                apply(t, e) {
                    let i = null == e ? null : e.initialState,
                        s = null == e ? null : e.constants;
                    null == e && (e = {});
                    const r = z(t, i, s, this.numConstants);
                    t = r.inputs, i = r.initialState, s = r.constants;
                    let n = [],
                        l = [];
                    if (null != i) {
                        e.initialState = i, n = n.concat(i), this.stateSpec = [];
                        for (const t of i) this.stateSpec.push(new u.Zg({
                            shape: t.shape
                        }));
                        l = l.concat(this.stateSpec)
                    }
                    null != s && (e.constants = s, n = n.concat(s), this.numConstants = s.length);
                    if (n[0] instanceof u.Iy) {
                        const i = [t].concat(n),
                            s = this.inputSpec.concat(l),
                            r = this.inputSpec;
                        this.inputSpec = s;
                        const a = super.apply(i, e);
                        return this.inputSpec = r, a
                    }
                    return super.apply(t, e)
                }
                call(t, e) {
                    return (0, s.lub)((() => {
                        const i = null == e ? null : e.mask,
                            s = null == e ? null : e.training;
                        let r = null == e ? null : e.initialState;
                        t = (0, d.nQ)(t), null == r && (r = this.stateful ? this.states_ : this.getInitialState(t));
                        const n = Array.isArray(this.cell.stateSize) ? this.cell.stateSize.length : 1;
                        if (r.length !== n) throw new o.nu(`RNN Layer has ${n} state(s) but was passed ${r.length} initial state(s).`);
                        this.unroll && console.warn("Ignoring unroll = true for RNN layer, due to imperative backend.");
                        const l = {
                                training: s
                            },
                            a = A(((t, e) => {
                                const i = this.cell.call([t].concat(e), l);
                                return [i[0], i.slice(1)]
                            }), t, r, this.goBackwards, i, null, this.unroll, this.returnSequences),
                            u = a[0],
                            h = a[1],
                            c = a[2];
                        this.stateful && this.resetStates(c, s);
                        const p = this.returnSequences ? h : u;
                        return this.returnState ? [p].concat(c) : p
                    }))
                }
                getInitialState(t) {
                    return (0, s.lub)((() => {
                        let e = s.lls(t.shape);
                        return e = s.Smz(e, [1, 2]), e = n.dt(e), Array.isArray(this.cell.stateSize) ? this.cell.stateSize.map((t => t > 1 ? n.Gg(e, [1, t]) : e)) : this.cell.stateSize > 1 ? [n.Gg(e, [1, this.cell.stateSize])] : [e]
                    }))
                }
                get trainableWeights() {
                    return this.trainable ? this.cell.trainableWeights : []
                }
                get nonTrainableWeights() {
                    return this.trainable ? this.cell.nonTrainableWeights : this.cell.weights
                }
                setFastWeightInitDuringBuild(t) {
                    super.setFastWeightInitDuringBuild(t), null != this.cell && this.cell.setFastWeightInitDuringBuild(t)
                }
                getConfig() {
                    const t = super.getConfig(),
                        e = {
                            returnSequences: this.returnSequences,
                            returnState: this.returnState,
                            goBackwards: this.goBackwards,
                            stateful: this.stateful,
                            unroll: this.unroll
                        };
                    null != this.numConstants && (e.numConstants = this.numConstants);
                    const i = this.cell.getConfig();
                    return this.getClassName() === S.className && (e.cell = {
                        className: this.cell.getClassName(),
                        config: i
                    }), Object.assign({}, i, t, e)
                }
                static fromConfig(t, e, i = {}) {
                    const s = e.cell,
                        r = (0, C.v)(s, i);
                    return new t(Object.assign(e, {
                        cell: r
                    }))
                }
            }
            S.className = "RNN", s.m7h.registerClass(S);
            class f extends u.mh {}
            class k extends f {
                constructor(t) {
                    super(t), this.DEFAULT_ACTIVATION = "tanh", this.DEFAULT_KERNEL_INITIALIZER = "glorotNormal", this.DEFAULT_RECURRENT_INITIALIZER = "orthogonal", this.DEFAULT_BIAS_INITIALIZER = "zeros", this.units = t.units, (0, p.iQ)(this.units, "units"), this.activation = (0, r.aI)(null == t.activation ? this.DEFAULT_ACTIVATION : t.activation), this.useBias = null == t.useBias || t.useBias, this.kernelInitializer = (0, h.L5)(t.kernelInitializer || this.DEFAULT_KERNEL_INITIALIZER), this.recurrentInitializer = (0, h.L5)(t.recurrentInitializer || this.DEFAULT_RECURRENT_INITIALIZER), this.biasInitializer = (0, h.L5)(t.biasInitializer || this.DEFAULT_BIAS_INITIALIZER), this.kernelRegularizer = (0, c.EC)(t.kernelRegularizer), this.recurrentRegularizer = (0, c.EC)(t.recurrentRegularizer), this.biasRegularizer = (0, c.EC)(t.biasRegularizer), this.kernelConstraint = (0, a.Ad)(t.kernelConstraint), this.recurrentConstraint = (0, a.Ad)(t.recurrentConstraint), this.biasConstraint = (0, a.Ad)(t.biasConstraint), this.dropout = g.VV([1, g.Fp([0, null == t.dropout ? 0 : t.dropout])]), this.recurrentDropout = g.VV([1, g.Fp([0, null == t.recurrentDropout ? 0 : t.recurrentDropout])]), this.dropoutFunc = t.dropoutFunc, this.stateSize = this.units, this.dropoutMask = null, this.recurrentDropoutMask = null
                }
                build(t) {
                    t = (0, d.Wf)(t), this.kernel = this.addWeight("kernel", [t[t.length - 1], this.units], null, this.kernelInitializer, this.kernelRegularizer, !0, this.kernelConstraint), this.recurrentKernel = this.addWeight("recurrent_kernel", [this.units, this.units], null, this.recurrentInitializer, this.recurrentRegularizer, !0, this.recurrentConstraint), this.useBias ? this.bias = this.addWeight("bias", [this.units], null, this.biasInitializer, this.biasRegularizer, !0, this.biasConstraint) : this.bias = null, this.built = !0
                }
                call(t, e) {
                    return (0, s.lub)((() => {
                        if (2 !== t.length) throw new o.nu(`SimpleRNNCell expects 2 input Tensors, got ${t.length}.`);
                        let i = t[1];
                        t = t[0];
                        const r = null != e.training && e.training;
                        let l;
                        0 < this.dropout && this.dropout < 1 && null == this.dropoutMask && (this.dropoutMask = T({
                            ones: () => s.JpU(t),
                            rate: this.dropout,
                            training: r,
                            dropoutFunc: this.dropoutFunc
                        })), 0 < this.recurrentDropout && this.recurrentDropout < 1 && null == this.recurrentDropoutMask && (this.recurrentDropoutMask = T({
                            ones: () => s.JpU(i),
                            rate: this.recurrentDropout,
                            training: r,
                            dropoutFunc: this.dropoutFunc
                        }));
                        const a = this.dropoutMask,
                            u = this.recurrentDropoutMask;
                        l = null != a ? n.AK(s.dC7(t, a), this.kernel.read()) : n.AK(t, this.kernel.read()), null != this.bias && (l = n.a2(l, this.bias.read())), null != u && (i = s.dC7(i, u));
                        let h = s.IHx(l, n.AK(i, this.recurrentKernel.read()));
                        return null != this.activation && (h = this.activation.apply(h)), [h, h]
                    }))
                }
                getConfig() {
                    const t = super.getConfig(),
                        e = {
                            units: this.units,
                            activation: (0, r.GD)(this.activation),
                            useBias: this.useBias,
                            kernelInitializer: (0, h.Cx)(this.kernelInitializer),
                            recurrentInitializer: (0, h.Cx)(this.recurrentInitializer),
                            biasInitializer: (0, h.Cx)(this.biasInitializer),
                            kernelRegularizer: (0, c.SG)(this.kernelRegularizer),
                            recurrentRegularizer: (0, c.SG)(this.recurrentRegularizer),
                            biasRegularizer: (0, c.SG)(this.biasRegularizer),
                            activityRegularizer: (0, c.SG)(this.activityRegularizer),
                            kernelConstraint: (0, a.xF)(this.kernelConstraint),
                            recurrentConstraint: (0, a.xF)(this.recurrentConstraint),
                            biasConstraint: (0, a.xF)(this.biasConstraint),
                            dropout: this.dropout,
                            recurrentDropout: this.recurrentDropout
                        };
                    return Object.assign({}, t, e)
                }
            }
            k.className = "SimpleRNNCell", s.m7h.registerClass(k);
            class b extends S {
                constructor(t) {
                    t.cell = new k(t), super(t)
                }
                call(t, e) {
                    return (0, s.lub)((() => {
                        null != this.cell.dropoutMask && (s.B90(this.cell.dropoutMask), this.cell.dropoutMask = null), null != this.cell.recurrentDropoutMask && (s.B90(this.cell.recurrentDropoutMask), this.cell.recurrentDropoutMask = null);
                        const i = null == e ? null : e.mask,
                            r = null == e ? null : e.training,
                            n = null == e ? null : e.initialState;
                        return super.call(t, {
                            mask: i,
                            training: r,
                            initialState: n
                        })
                    }))
                }
                static fromConfig(t, e) {
                    return new t(e)
                }
            }
            b.className = "SimpleRNN", s.m7h.registerClass(b);
            class R extends f {
                constructor(t) {
                    if (super(t), this.DEFAULT_ACTIVATION = "tanh", this.DEFAULT_RECURRENT_ACTIVATION = "hardSigmoid", this.DEFAULT_KERNEL_INITIALIZER = "glorotNormal", this.DEFAULT_RECURRENT_INITIALIZER = "orthogonal", this.DEFAULT_BIAS_INITIALIZER = "zeros", t.resetAfter) throw new o.nu("GRUCell does not support reset_after parameter set to true.");
                    this.units = t.units, (0, p.iQ)(this.units, "units"), this.activation = (0, r.aI)(void 0 === t.activation ? this.DEFAULT_ACTIVATION : t.activation), this.recurrentActivation = (0, r.aI)(void 0 === t.recurrentActivation ? this.DEFAULT_RECURRENT_ACTIVATION : t.recurrentActivation), this.useBias = null == t.useBias || t.useBias, this.kernelInitializer = (0, h.L5)(t.kernelInitializer || this.DEFAULT_KERNEL_INITIALIZER), this.recurrentInitializer = (0, h.L5)(t.recurrentInitializer || this.DEFAULT_RECURRENT_INITIALIZER), this.biasInitializer = (0, h.L5)(t.biasInitializer || this.DEFAULT_BIAS_INITIALIZER), this.kernelRegularizer = (0, c.EC)(t.kernelRegularizer), this.recurrentRegularizer = (0, c.EC)(t.recurrentRegularizer), this.biasRegularizer = (0, c.EC)(t.biasRegularizer), this.kernelConstraint = (0, a.Ad)(t.kernelConstraint), this.recurrentConstraint = (0, a.Ad)(t.recurrentConstraint), this.biasConstraint = (0, a.Ad)(t.biasConstraint), this.dropout = g.VV([1, g.Fp([0, null == t.dropout ? 0 : t.dropout])]), this.recurrentDropout = g.VV([1, g.Fp([0, null == t.recurrentDropout ? 0 : t.recurrentDropout])]), this.dropoutFunc = t.dropoutFunc, this.implementation = t.implementation, this.stateSize = this.units, this.dropoutMask = null, this.recurrentDropoutMask = null
                }
                build(t) {
                    const e = (t = (0, d.Wf)(t))[t.length - 1];
                    this.kernel = this.addWeight("kernel", [e, 3 * this.units], null, this.kernelInitializer, this.kernelRegularizer, !0, this.kernelConstraint), this.recurrentKernel = this.addWeight("recurrent_kernel", [this.units, 3 * this.units], null, this.recurrentInitializer, this.recurrentRegularizer, !0, this.recurrentConstraint), this.useBias ? this.bias = this.addWeight("bias", [3 * this.units], null, this.biasInitializer, this.biasRegularizer, !0, this.biasConstraint) : this.bias = null, this.built = !0
                }
                call(t, e) {
                    return (0, s.lub)((() => {
                        if (2 !== t.length) throw new o.nu(`GRUCell expects 2 input Tensors (inputs, h, c), got ${t.length}.`);
                        const i = null != e.training && e.training;
                        let r = t[1];
                        t = t[0], 0 < this.dropout && this.dropout < 1 && null == this.dropoutMask && (this.dropoutMask = T({
                            ones: () => s.JpU(t),
                            rate: this.dropout,
                            training: i,
                            count: 3,
                            dropoutFunc: this.dropoutFunc
                        })), 0 < this.recurrentDropout && this.recurrentDropout < 1 && null == this.recurrentDropoutMask && (this.recurrentDropoutMask = T({
                            ones: () => s.JpU(r),
                            rate: this.recurrentDropout,
                            training: i,
                            count: 3,
                            dropoutFunc: this.dropoutFunc
                        }));
                        const l = this.dropoutMask,
                            a = this.recurrentDropoutMask;
                        let u, h, c;
                        0 < this.dropout && this.dropout < 1 && (t = s.dC7(t, l[0]));
                        let p = n.AK(t, this.kernel.read());
                        this.useBias && (p = n.a2(p, this.bias.read())), 0 < this.recurrentDropout && this.recurrentDropout < 1 && (r = s.dC7(r, a[0]));
                        const g = this.recurrentKernel.read(),
                            [d, I] = s.Vl2(g, [2 * this.units, this.units], g.rank - 1),
                            C = n.AK(r, d),
                            [z, A, S] = s.Vl2(p, 3, p.rank - 1),
                            [f, k] = s.Vl2(C, 2, C.rank - 1);
                        u = this.recurrentActivation.apply(s.IHx(z, f)), h = this.recurrentActivation.apply(s.IHx(A, k));
                        const b = n.AK(s.dC7(h, r), I);
                        c = this.activation.apply(s.IHx(S, b));
                        const R = s.IHx(s.dC7(u, r), s.dC7(s.IHx(1, s.W76(u)), c));
                        return [R, R]
                    }))
                }
                getConfig() {
                    const t = super.getConfig(),
                        e = {
                            units: this.units,
                            activation: (0, r.GD)(this.activation),
                            recurrentActivation: (0, r.GD)(this.recurrentActivation),
                            useBias: this.useBias,
                            kernelInitializer: (0, h.Cx)(this.kernelInitializer),
                            recurrentInitializer: (0, h.Cx)(this.recurrentInitializer),
                            biasInitializer: (0, h.Cx)(this.biasInitializer),
                            kernelRegularizer: (0, c.SG)(this.kernelRegularizer),
                            recurrentRegularizer: (0, c.SG)(this.recurrentRegularizer),
                            biasRegularizer: (0, c.SG)(this.biasRegularizer),
                            activityRegularizer: (0, c.SG)(this.activityRegularizer),
                            kernelConstraint: (0, a.xF)(this.kernelConstraint),
                            recurrentConstraint: (0, a.xF)(this.recurrentConstraint),
                            biasConstraint: (0, a.xF)(this.biasConstraint),
                            dropout: this.dropout,
                            recurrentDropout: this.recurrentDropout,
                            implementation: this.implementation,
                            resetAfter: !1
                        };
                    return Object.assign({}, t, e)
                }
            }
            R.className = "GRUCell", s.m7h.registerClass(R);
            class m extends S {
                constructor(t) {
                    0 === t.implementation && console.warn("`implementation=0` has been deprecated, and now defaults to `implementation=1`. Please update your layer call."), t.cell = new R(t), super(t)
                }
                call(t, e) {
                    return (0, s.lub)((() => {
                        null != this.cell.dropoutMask && (s.B90(this.cell.dropoutMask), this.cell.dropoutMask = null), null != this.cell.recurrentDropoutMask && (s.B90(this.cell.recurrentDropoutMask), this.cell.recurrentDropoutMask = null);
                        const i = null == e ? null : e.mask,
                            r = null == e ? null : e.training,
                            n = null == e ? null : e.initialState;
                        return super.call(t, {
                            mask: i,
                            training: r,
                            initialState: n
                        })
                    }))
                }
                static fromConfig(t, e) {
                    return 0 === e.implmentation && (e.implementation = 1), new t(e)
                }
            }
            m.className = "GRU", s.m7h.registerClass(m);
            class E extends f {
                constructor(t) {
                    super(t), this.DEFAULT_ACTIVATION = "tanh", this.DEFAULT_RECURRENT_ACTIVATION = "hardSigmoid", this.DEFAULT_KERNEL_INITIALIZER = "glorotNormal", this.DEFAULT_RECURRENT_INITIALIZER = "orthogonal", this.DEFAULT_BIAS_INITIALIZER = "zeros", this.units = t.units, (0, p.iQ)(this.units, "units"), this.activation = (0, r.aI)(void 0 === t.activation ? this.DEFAULT_ACTIVATION : t.activation), this.recurrentActivation = (0, r.aI)(void 0 === t.recurrentActivation ? this.DEFAULT_RECURRENT_ACTIVATION : t.recurrentActivation), this.useBias = null == t.useBias || t.useBias, this.kernelInitializer = (0, h.L5)(t.kernelInitializer || this.DEFAULT_KERNEL_INITIALIZER), this.recurrentInitializer = (0, h.L5)(t.recurrentInitializer || this.DEFAULT_RECURRENT_INITIALIZER), this.biasInitializer = (0, h.L5)(t.biasInitializer || this.DEFAULT_BIAS_INITIALIZER), this.unitForgetBias = t.unitForgetBias, this.kernelRegularizer = (0, c.EC)(t.kernelRegularizer), this.recurrentRegularizer = (0, c.EC)(t.recurrentRegularizer), this.biasRegularizer = (0, c.EC)(t.biasRegularizer), this.kernelConstraint = (0, a.Ad)(t.kernelConstraint), this.recurrentConstraint = (0, a.Ad)(t.recurrentConstraint), this.biasConstraint = (0, a.Ad)(t.biasConstraint), this.dropout = g.VV([1, g.Fp([0, null == t.dropout ? 0 : t.dropout])]), this.recurrentDropout = g.VV([1, g.Fp([0, null == t.recurrentDropout ? 0 : t.recurrentDropout])]), this.dropoutFunc = t.dropoutFunc, this.implementation = t.implementation, this.stateSize = [this.units, this.units], this.dropoutMask = null, this.recurrentDropoutMask = null
                }
                build(t) {
                    var e;
                    const i = (t = (0, d.Wf)(t))[t.length - 1];
                    let s;
                    if (this.kernel = this.addWeight("kernel", [i, 4 * this.units], null, this.kernelInitializer, this.kernelRegularizer, !0, this.kernelConstraint), this.recurrentKernel = this.addWeight("recurrent_kernel", [this.units, 4 * this.units], null, this.recurrentInitializer, this.recurrentRegularizer, !0, this.recurrentConstraint), this.useBias) {
                        if (this.unitForgetBias) {
                            const t = this.biasInitializer,
                                i = this.units;
                            s = new((e = class extends h.m7 {
                                apply(e, s) {
                                    const r = t.apply([i]),
                                        l = (new h.M6).apply([i]),
                                        a = t.apply([2 * i]);
                                    return n.GZ(n.GZ(r, l), a)
                                }
                            }).className = "CustomInit", e)
                        } else s = this.biasInitializer;
                        this.bias = this.addWeight("bias", [4 * this.units], null, s, this.biasRegularizer, !0, this.biasConstraint)
                    } else this.bias = null;
                    this.built = !0
                }
                call(t, e) {
                    return (0, s.lub)((() => {
                        const i = null != e.training && e.training;
                        if (3 !== t.length) throw new o.nu(`LSTMCell expects 3 input Tensors (inputs, h, c), got ${t.length}.`);
                        let r = t[1];
                        const l = t[2];
                        t = t[0], 0 < this.dropout && this.dropout < 1 && null == this.dropoutMask && (this.dropoutMask = T({
                            ones: () => s.JpU(t),
                            rate: this.dropout,
                            training: i,
                            count: 4,
                            dropoutFunc: this.dropoutFunc
                        })), 0 < this.recurrentDropout && this.recurrentDropout < 1 && null == this.recurrentDropoutMask && (this.recurrentDropoutMask = T({
                            ones: () => s.JpU(r),
                            rate: this.recurrentDropout,
                            training: i,
                            count: 4,
                            dropoutFunc: this.dropoutFunc
                        }));
                        const a = this.dropoutMask,
                            u = this.recurrentDropoutMask;
                        let h, c, p, g;
                        0 < this.dropout && this.dropout < 1 && (t = s.dC7(t, a[0]));
                        let d = n.AK(t, this.kernel.read());
                        0 < this.recurrentDropout && this.recurrentDropout < 1 && (r = s.dC7(r, u[0])), d = s.IHx(d, n.AK(r, this.recurrentKernel.read())), this.useBias && (d = n.a2(d, this.bias.read()));
                        const [I, C, z, A] = s.Vl2(d, 4, d.rank - 1);
                        h = this.recurrentActivation.apply(I), c = this.recurrentActivation.apply(C), p = s.IHx(s.dC7(c, l), s.dC7(h, this.activation.apply(z))), g = this.recurrentActivation.apply(A);
                        const S = s.dC7(g, this.activation.apply(p));
                        return [S, S, p]
                    }))
                }
                getConfig() {
                    const t = super.getConfig(),
                        e = {
                            units: this.units,
                            activation: (0, r.GD)(this.activation),
                            recurrentActivation: (0, r.GD)(this.recurrentActivation),
                            useBias: this.useBias,
                            kernelInitializer: (0, h.Cx)(this.kernelInitializer),
                            recurrentInitializer: (0, h.Cx)(this.recurrentInitializer),
                            biasInitializer: (0, h.Cx)(this.biasInitializer),
                            unitForgetBias: this.unitForgetBias,
                            kernelRegularizer: (0, c.SG)(this.kernelRegularizer),
                            recurrentRegularizer: (0, c.SG)(this.recurrentRegularizer),
                            biasRegularizer: (0, c.SG)(this.biasRegularizer),
                            activityRegularizer: (0, c.SG)(this.activityRegularizer),
                            kernelConstraint: (0, a.xF)(this.kernelConstraint),
                            recurrentConstraint: (0, a.xF)(this.recurrentConstraint),
                            biasConstraint: (0, a.xF)(this.biasConstraint),
                            dropout: this.dropout,
                            recurrentDropout: this.recurrentDropout,
                            implementation: this.implementation
                        };
                    return Object.assign({}, t, e)
                }
            }
            E.className = "LSTMCell", s.m7h.registerClass(E);
            class N extends S {
                constructor(t) {
                    0 === t.implementation && console.warn("`implementation=0` has been deprecated, and now defaults to `implementation=1`. Please update your layer call."), t.cell = new E(t), super(t)
                }
                call(t, e) {
                    return (0, s.lub)((() => {
                        null != this.cell.dropoutMask && (s.B90(this.cell.dropoutMask), this.cell.dropoutMask = null), null != this.cell.recurrentDropoutMask && (s.B90(this.cell.recurrentDropoutMask), this.cell.recurrentDropoutMask = null);
                        const i = null == e ? null : e.mask,
                            r = null == e ? null : e.training,
                            n = null == e ? null : e.initialState;
                        return super.call(t, {
                            mask: i,
                            training: r,
                            initialState: n
                        })
                    }))
                }
                static fromConfig(t, e) {
                    return 0 === e.implmentation && (e.implementation = 1), new t(e)
                }
            }
            N.className = "LSTM", s.m7h.registerClass(N);
            class D extends f {
                constructor(t) {
                    super(t), this.cells = t.cells
                }
                get stateSize() {
                    const t = [];
                    for (const e of this.cells.slice().reverse()) Array.isArray(e.stateSize) ? t.push(...e.stateSize) : t.push(e.stateSize);
                    return t
                }
                call(t, e) {
                    return (0, s.lub)((() => {
                        let i = t.slice(1);
                        const s = [];
                        for (const t of this.cells.slice().reverse()) Array.isArray(t.stateSize) ? s.push(i.splice(0, t.stateSize.length)) : s.push(i.splice(0, 1));
                        s.reverse();
                        const r = [];
                        let n;
                        for (let l = 0; l < this.cells.length; ++l) {
                            const a = this.cells[l];
                            i = s[l], n = 0 === l ? [t[0]].concat(i) : [n[0]].concat(i), n = a.call(n, e), r.push(n.slice(1))
                        }
                        i = [];
                        for (const t of r.slice().reverse()) i.push(...t);
                        return [n[0]].concat(i)
                    }))
                }
                build(t) {
                    let e;
                    (0, d.XO)(t) && (t = t[0]), this.cells.forEach(((i, s) => {
                        (0, l.f4)(`RNNCell_${s}`, (() => {
                            i.build(t), e = Array.isArray(i.stateSize) ? i.stateSize[0] : i.stateSize, t = [t[0], e]
                        }))
                    })), this.built = !0
                }
                getConfig() {
                    const t = super.getConfig(),
                        e = {
                            cells: this.cells.map((t => ({
                                className: t.getClassName(),
                                config: t.getConfig()
                            })))
                        };
                    return Object.assign({}, t, e)
                }
                static fromConfig(t, e, i = {}) {
                    const s = [];
                    for (const r of e.cells) s.push((0, C.v)(r, i));
                    return new t({
                        cells: s
                    })
                }
                get trainableWeights() {
                    if (!this.trainable) return [];
                    const t = [];
                    for (const e of this.cells) t.push(...e.trainableWeights);
                    return t
                }
                get nonTrainableWeights() {
                    const t = [];
                    for (const e of this.cells) t.push(...e.nonTrainableWeights);
                    if (!this.trainable) {
                        const e = [];
                        for (const t of this.cells) e.push(...t.trainableWeights);
                        return e.concat(t)
                    }
                    return t
                }
                getWeights() {
                    const t = [];
                    for (const e of this.cells) t.push(...e.weights);
                    return (0, I.FQ)(t)
                }
                setWeights(t) {
                    const e = [];
                    for (const i of this.cells) {
                        const s = i.weights.length,
                            r = t.splice(s);
                        for (let t = 0; t < i.weights.length; ++t) e.push([i.weights[t], r[t]])
                    }(0, I.zb)(e)
                }
            }

            function T(t) {
                const {
                    ones: e,
                    rate: i,
                    training: r = !1,
                    count: l = 1,
                    dropoutFunc: a
                } = t, u = () => null != a ? a(e(), i) : n.rv(e(), i), o = () => n.KC(u, e, r);
                if (!l || l <= 1) return s.CnY(o().clone());
                return Array(l).fill(void 0).map(o).map((t => s.CnY(t.clone())))
            }
            D.className = "StackedRNNCells", s.m7h.registerClass(D)
        }
    }
]);
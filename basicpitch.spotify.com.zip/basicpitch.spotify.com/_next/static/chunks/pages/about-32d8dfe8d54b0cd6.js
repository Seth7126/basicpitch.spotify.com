(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [521], {
        63508: function(e, t, i) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/about", function() {
                return i(36115)
            }])
        },
        36115: function(e, t, i) {
            "use strict";
            i.r(t), i.d(t, {
                default: function() {
                    return W
                }
            });
            var n = i(97171),
                r = i(99195),
                o = i(44897),
                s = i(20465);

            function a() {
                var e = (0, n.useRouter)();
                return (0, s.jsxs)(r.$, {
                    style: {
                        paddingTop: 50
                    },
                    children: [(0, s.jsx)(o.H1, {
                        children: "About Basic Pitch from Spotify"
                    }), (0, s.jsx)(o.P, {
                        children: "Basic Pitch is a lightweight, lightning-fast audio-to-MIDI converter that features pitch bend detection and works on recordings of almost any instrument, including voice. It's brought to you by the researchers and engineers at Spotify's Audio Intelligence Lab."
                    }), (0, s.jsx)("div", {
                        style: {
                            textAlign: "center"
                        },
                        children: (0, s.jsx)(o.PL, {
                            onClick: function() {
                                return e.push("/")
                            },
                            style: {
                                textTransform: "none",
                                marginBottom: 0
                            },
                            children: "Try the demo now"
                        })
                    })]
                })
            }

            function c() {
                return (0, s.jsxs)(r.$, {
                    light: !0,
                    children: [(0, s.jsx)(o.H2, {
                        children: "Artificial intelligence, human thoughtfulness"
                    }), (0, s.jsx)(o.P, {
                        children: "Unlike most ML models, which can be big, burly, and wasteful, Basic Pitch was engineered to do its processing simply and efficiently \u2014 with <20 MB peak memory and <17K parameters. So the output is both high-quality and energy-friendly."
                    })]
                })
            }
            var h = i(7263),
                d = i.n(h);

            function l() {
                return (0, s.jsxs)(r.$, {
                    light: !0,
                    tint: !0,
                    children: [(0, s.jsx)(o.H2, {
                        children: "Free and open source"
                    }), (0, s.jsx)(o.P, {
                        children: "Whether you're a musician, a developer, or both, we'd love to hear what you do with the tech in Basic Pitch!"
                    }), (0, s.jsx)(o.H5, {
                        children: "Musicians & Producers"
                    }), (0, s.jsxs)(o.Ul, {
                        children: [(0, s.jsxs)("li", {
                            children: ["Get a jump start on your next composition. If you need to convert a recording to MIDI, you can use the", " ", (0, s.jsx)(d(), {
                                href: "/",
                                passHref: !0,
                                children: (0, s.jsx)(o.A, {
                                    target: "_self",
                                    children: "demo"
                                })
                            }), " ", "version of Basic Pitch right on this website, with no strings attached."]
                        }), (0, s.jsxs)("li", {
                            children: ["Then fine tune your composition in the DAW of your choice, including", " ", (0, s.jsx)(o.A, {
                                href: "https://www.soundtrap.com",
                                children: "Soundtrap"
                            }), ", the collaborative, online music studio from Spotify."]
                        })]
                    }), (0, s.jsx)(o.H5, {
                        children: "Developers & Researchers"
                    }), (0, s.jsxs)(o.Ul, {
                        children: [(0, s.jsxs)("li", {
                            children: ["Help us improve it! Grab the code on", " ", (0, s.jsx)(o.A, {
                                href: "https://github.com/spotify/basic-pitch/",
                                children: "GitHub"
                            }), " and integrate it into different production workflows."]
                        }), (0, s.jsx)("li", {
                            children: "Machine learning and audio researchers can also dive into the code to see how it all works."
                        })]
                    })]
                })
            }
            var u = i(33647),
                p = i(23169),
                m = i(6509);

            function g() {
                var e = (0, u.Z)(["\n  position: relative;\n  padding-bottom: 56.25%; /* 16:9 */\n  height: 0;\n  margin-bottom: ", ";\n  iframe {\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n  }\n"]);
                return g = function() {
                    return e
                }, e
            }
            var x = p.ZP.div(g(), m.nuo);

            function f() {
                var e = (0, u.Z)(["\n  display: flex;\n  flex-wrap: nowrap;\n  overflow: hidden;\n  align-items: center;\n\n  // & > :nth-child(2) {\n  //   margin-left: 5px;\n  // }\n"]);
                return f = function() {
                    return e
                }, e
            }
            var j = p.ZP.div(f()),
                y = "https://audio-understanding-dev.scdn.co/basic-pitch/";

            function w() {
                return (0, s.jsxs)(r.$, {
                    light: !0,
                    tint: !0,
                    children: [(0, s.jsx)(o.H2, {
                        children: "Listen to demo tracks"
                    }), (0, s.jsx)(o.P, {
                        children: "Hear music made using Basic Pitch, including Virgo by artist-producer Bad Snacks. Plus, original compositions by the Basic Pitch team at Spotify."
                    }), (0, s.jsx)(o.H3, {
                        children: "Virgo"
                    }), (0, s.jsx)(x, {
                        children: (0, s.jsx)("iframe", {
                            title: "Virgo by Bad Snacks on Spotify",
                            style: {
                                borderRadius: "12px"
                            },
                            allowFullScreen: !0,
                            src: "https://open.spotify.com/embed/track/4Vn7GceHAjOcPElx3S1lfy"
                        })
                    }), (0, s.jsx)(o.P, {}), (0, s.jsxs)(o.P, {
                        children: ["By ", (0, s.jsx)(o.A, {
                            href: "https://www.youtube.com/c/badsnacks",
                            children: "Bad Snacks"
                        }), " (Artist, Beatmaker, Violinist, Vocalist, Producer):", " ", (0, s.jsx)("blockquote", {
                            children: "\u201cSo [the violin part] is the part that I had the most fun with, by a long shot. Because this part was crazy. It starts with this violin solo, and I really just jammed. I wasn't thinking about things that would be easy to track. I just played how I would normally play. [\u2026] [Then I threw] it through a whole slew of plugins, because I wanted to hear this solo through so many different synths \u2014 and then I couldn't pick which synth that I wanted, so I just made a whole chorus of synths\u2026\u201d"
                        })]
                    }), (0, s.jsx)(o.P, {}), (0, s.jsx)(o.H3, {
                        children: "Op37 Maximum Shimmer"
                    }), (0, s.jsx)(j, {
                        children: (0, s.jsxs)("audio", {
                            controls: !0,
                            title: "Op37 Maximum Shimmer by Jan Van Balen - Basic Pitch Demo.mp3",
                            children: [(0, s.jsx)("track", {
                                kind: "captions"
                            }), (0, s.jsx)("source", {
                                src: "".concat(y, "Op37-Maximum-Shimmer.mp3")
                            })]
                        })
                    }), (0, s.jsx)(o.P, {}), (0, s.jsxs)(o.P, {
                        children: ["By ", (0, s.jsx)(o.A, {
                            href: "https://jvbalen.github.io/",
                            children: "Jan Van Balen"
                        }), " (Senior Research Scientist, Spotify):", " ", (0, s.jsxs)("blockquote", {
                            children: ["\u201cI started from a recording of", " ", (0, s.jsx)(o.A, {
                                href: "https://commons.wikimedia.org/wiki/File:Beethoven_piano_concerto_3_-_2nd_mvt.ogg",
                                children: "Beethoven\u2019s Piano Concerto No. 3, Op. 37"
                            }), ". I cut out a few four-bar loops from the \u201cAllegro con brio\u201d opening section, time-stretched them to a slower tempo, and fed the result to Basic Pitch. I used a low Frame Threshold of 0.1 and a slightly higher than default Minimum Note Length of 120 ms, resulting in a bunch of very dense MIDI files. From the most interesting one, I then rendered a kind of twinkly electric piano/bell texture that is lacking the note structure but keeps the harmonic structure of the original excerpt. Finally, I added a very sparse drum groove and a middle section that replaces the twinkly chords with a more minimal arpeggiated EP pattern, hoping to give the whole thing a bit more of a song-like structure.\u201d"]
                        })]
                    }), (0, s.jsx)(o.P, {}), (0, s.jsx)(o.H3, {
                        children: "fruit juice!"
                    }), (0, s.jsx)(j, {
                        children: (0, s.jsxs)("audio", {
                            controls: !0,
                            title: "fruit juice! by Hugo Flores Garc\xeda - Basic Pitch Demo.mp3",
                            children: [(0, s.jsx)("track", {
                                kind: "captions"
                            }), (0, s.jsx)("source", {
                                src: "".concat(y, "fruit-juice.mp3")
                            })]
                        })
                    }), (0, s.jsx)(o.P, {}), (0, s.jsxs)(o.P, {
                        children: ["By ", (0, s.jsx)(o.A, {
                            href: "https://hugofloresgarcia.github.io/",
                            children: "Hugo Flores Garc\xeda"
                        }), " (Summer Intern-Research Scientist, Spotify):", (0, s.jsx)("blockquote", {
                            children: "\u201cI recorded two guitar tracks, one that plays a recurring phrase, and another one that responds to the phrase with a short guitar solo. To add some color and energy to the tracks, I used Basic Pitch to convert both of my guitar tracks to MIDI, and resynthesized each phrase using a different combination of my own synths (like a wobbly Wurli, a \u201cvocoded\u201d Sawtooth, some swells for the chords, and a vibraphone). To make it groovy, I laid down a simple bassline and 808 beat.\u201d"
                        })]
                    }), (0, s.jsx)(o.P, {}), (0, s.jsx)(o.H3, {
                        children: "good snacks"
                    }), (0, s.jsx)(j, {
                        children: (0, s.jsxs)("audio", {
                            controls: !0,
                            title: "good snacks by Ching Sung and Rachel Bittner - Basic Pitch Demo.mp3",
                            children: [(0, s.jsx)("track", {
                                kind: "captions"
                            }), (0, s.jsx)("source", {
                                src: "".concat(y, "good-snacks.mp3")
                            })]
                        })
                    }), (0, s.jsx)(o.P, {}), (0, s.jsxs)(o.P, {
                        children: ["By ", (0, s.jsx)(o.A, {
                            href: "https://www.linkedin.com/in/chingsung/",
                            children: "Ching Sung"
                        }), " (Senior Product Manager, Spotify) and", " ", (0, s.jsx)(o.A, {
                            href: "http://rachelbittner.weebly.com/",
                            children: "Rachel Bittner"
                        }), " (Research Manager, Spotify):", (0, s.jsx)("blockquote", {
                            children: "\u201cWe started by recording a conversation about snacks we like. We transcribed each of our voice recordings using Basic Pitch, changing some of the MIDI adjustments to get a more accurate transcription. For both voices, we turned down the Model Confidence Threshold, shortened the Minimum Note Length, and adjusted the Minimum/Maximum Pitch to be within each of our speaking ranges. We added the generated MIDI files as extra tracks. Ching\u2019s voice is doubled using a piano sound font, and Rachel\u2019s using a xylophone sound font. We listened through the whole recording a couple of times to find moments where the transcription or words stood out to us, and emphasized those moments with extra/different MIDI instruments.\u201d"
                        })]
                    }), (0, s.jsx)(o.P, {}), (0, s.jsx)(o.H3, {
                        children: "Alla Tuna"
                    }), (0, s.jsx)(j, {
                        children: (0, s.jsxs)("audio", {
                            controls: !0,
                            title: "Alla Tuna by Daniel Stoller - Basic Pitch Demo.mp3",
                            children: [(0, s.jsx)("track", {
                                kind: "captions"
                            }), (0, s.jsx)("source", {
                                src: "".concat(y, "Alla-Tuna.mp3")
                            })]
                        })
                    }), (0, s.jsx)(o.P, {}), (0, s.jsxs)(o.P, {
                        children: ["By ", (0, s.jsx)(o.A, {
                            href: "https://dans.world/",
                            children: "Daniel Stoller"
                        }), " (Research Scientist, Spotify):", " ", (0, s.jsxs)("blockquote", {
                            children: ["\u201cI started from ", (0, s.jsx)(o.A, {
                                href: "https://www.jamendo.com/track/1829094/mozart-alla-turca-no-drums",
                                children: "Paul Werner\u2019s"
                            }), " comical interpretation of the well-known Sonata No. 11 in A major by Mozart (also called \u201cAlla Turca\u201d). Due to the repetitive nature of the piece, I decided to only focus on the initial few sections. For this song, Basic Pitch managed to detect many notes correctly, and the estimation errors it did make where musically still sensible (i.e. in-key, in-rhythm), which by accident added its own flair to the resulting music. I split all detected notes into high- and low-pitch and applied the Icecream VST to each, to generate a chiptune-like sound. The lower pitches were set to be a bit more in the background in terms of volume but also timbre, while the higher pitches contained the main melody and was given that typical, piercing chiptune style. I then added a simple drum line using a chiptune-style drum VST, and finished it off by time-aligning and pitch-correcting some notes that were too out of line.\u201d"]
                        })]
                    }), (0, s.jsx)(o.P, {}), (0, s.jsx)(o.H3, {
                        children: "Olives and oranges"
                    }), (0, s.jsx)(j, {
                        children: (0, s.jsxs)("audio", {
                            controls: !0,
                            title: "Olives and oranges by Juan Jos\xe9 Bosch - Basic Pitch Demo.mp3",
                            children: [(0, s.jsx)("track", {
                                kind: "captions"
                            }), (0, s.jsx)("source", {
                                src: "".concat(y, "Olives-and-oranges.mp3")
                            })]
                        })
                    }), (0, s.jsx)(o.P, {}), (0, s.jsxs)(o.P, {
                        children: ["By ", (0, s.jsx)(o.A, {
                            href: "http://www.juanjobosch.com/",
                            children: "Juan Jos\xe9 Bosch"
                        }), " (Research Scientist, Spotify):", " ", (0, s.jsx)("blockquote", {
                            children: "\u201cHow far could I go using only a single instrument recording and Basic Pitch? I tried to find out with a guitar recording from a song I made playing arpeggios, and ran it through Basic Pitch with different parameters to generate different musical elements in MIDI format. I first created a synth by running the transcription with default values, and then a bass by keeping only the lower notes and shifting them down one octave. I added pads by setting the parameters to get fewer long notes and then a simple electric guitar and toy piano by keeping the highest notes from the transcription and shifting them up. Finally, I created a simple percussion track by using the default transcription and mapped it to a percussive virtual instrument\u2026 so all the drum strokes you hear are linked to guitar note onsets. For some of the results I scaled note velocities down to get softer sounds from the virtual instruments, and sometimes edited one or two notes. I kept the guitar recording, created a simple arrangement with the rest of the instruments, a bit of mixing, and that\u2019s it!\u201d"
                        })]
                    }), (0, s.jsx)(o.P, {}), (0, s.jsx)(o.x4, {
                        children: (0, s.jsx)("div", {
                            dangerouslySetInnerHTML: {
                                __html: '\n<a rel="license" href="http://creativecommons.org/licenses/by/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by/4.0/80x15.png" /></a> <span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/Sound" property="dct:title" rel="dct:type">Op37 Maximum Shimmer</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="https://jvbalen.github.io/" property="cc:attributionName" rel="cc:attributionURL" style="color:inherit">Jan Van Balen</a>, <span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/Sound" property="dct:title" rel="dct:type">fruit juice!</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="https://hugofloresgarcia.github.io/" property="cc:attributionName" rel="cc:attributionURL" ; style="color:inherit">Hugo Flores Garc\xeda</a>, <span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/Sound" property="dct:title" rel="dct:type">good snacks</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="basicpitch.io" property="cc:attributionName" rel="cc:attributionURL" style="color:inherit">Ching Sung and Rachel Bittner</a>, <span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/Sound" property="dct:title" rel="dct:type">Alla Tuna</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="https://dans.world/" property="cc:attributionName" rel="cc:attributionURL" style="color:inherit">Daniel Stoller</a>, and <span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/Sound" property="dct:title" rel="dct:type">Olives and oranges</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="http://www.juanjobosch.com/" property="cc:attributionName" rel="cc:attributionURL" style="color:inherit">Juan Jos\xe9 Bosch</a> are each licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/4.0/" style="color:inherit">Creative Commons Attribution 4.0 International License</a>. Based on a work at <a xmlns:dct="http://purl.org/dc/terms/" href="basicpitch.io" rel="dct:source" style="color:inherit">basicpitch.io</a>.\n'
                            }
                        })
                    }), (0, s.jsx)(o.P, {})]
                })
            }

            function k() {
                return (0, s.jsxs)(r.$, {
                    light: !0,
                    tint: !0,
                    children: [(0, s.jsx)(o.H2, {
                        children: "Made for creators"
                    }), (0, s.jsx)(o.P, {
                        children: "Go from inspiration to production, faster. Hum a tune into your phone, drop the recording in Basic Pitch, and you'll get a very accurate MIDI version that you can then tweak and adjust to perfection in your DAW of choice."
                    }), (0, s.jsx)(x, {
                        children: (0, s.jsx)("iframe", {
                            title: "Bad Snacks: Spotify Made an Audio to MIDI Converter (?!?) - Basic Pitch Overview",
                            frameBorder: "0",
                            allowFullScreen: !0,
                            src: "https://www.youtube.com/embed/M7LQYW6DCb0?modestbranding=1&rel=0&iv_load_policy=3"
                        })
                    }), (0, s.jsx)(o.x4, {
                        as: "div",
                        style: {
                            textAlign: "center"
                        },
                        children: "We asked artist-producer Bad Snacks to try Basic Pitch \u2014 watch her create a new composition from scratch (14:33)."
                    }), (0, s.jsx)(o.P, {}), (0, s.jsx)(o.P, {}), (0, s.jsx)(x, {
                        children: (0, s.jsx)("iframe", {
                            title: "Spotify R&D \u2014 Basic Pitch demo: Convert audio into MIDI using ML",
                            frameBorder: "0",
                            allowFullScreen: !0,
                            src: "https://www.youtube.com/embed/DhlvfgS73ZQ?modestbranding=1&rel=0&iv_load_policy=3&list=PLf1KFlSkDLIAYLdb-SD9s8TdGy0rWIwVr&index=1"
                        })
                    }), (0, s.jsx)(o.x4, {
                        as: "div",
                        style: {
                            textAlign: "center"
                        },
                        children: "Watch this quick demo on how Basic Pitch works (1:34)."
                    })]
                })
            }

            function b() {
                return (0, s.jsxs)(r.$, {
                    light: !0,
                    children: [(0, s.jsx)(o.H2, {
                        children: "More from Spotify's Audio Intelligence Lab"
                    }), (0, s.jsx)(o.H3, {
                        children: (0, s.jsx)(o.A, {
                            href: "https://engineering.atspotify.com",
                            children: "Meet Basic Pitch: Spotify's Open Source Audio-to-MIDI Converter"
                        })
                    }), (0, s.jsx)(o.P, {
                        children: "Read the Spotify Engineering blog to learn more about how Basic Pitch works."
                    }), (0, s.jsx)(o.H3, {
                        children: (0, s.jsx)(o.A, {
                            href: "https://2022.ieeeicassp.org/view_paper.php?PaperNum=4718",
                            children: "See us at IEEE ICASSP 2022"
                        })
                    }), (0, s.jsxs)(o.P, {
                        children: ["Learn about the research behind Basic Pitch where the team presented their paper, \u201cA Lightweight Instrument-Agnostic Model for Polyphonic Note Transcription and Multipitch Estimation\u201d (", (0, s.jsx)(o.A, {
                            href: "https://ieeexplore.ieee.org/document/9746549",
                            children: "PDF"
                        }), "), at the 2022 IEEE International Conference on Acoustics, Speech and Signal Processing."]
                    }), (0, s.jsx)(o.H3, {
                        children: (0, s.jsx)(o.A, {
                            href: "https://engineering.atspotify.com/2021/09/introducing-pedalboard-spotifys-audio-effects-library-for-python/",
                            children: "Pedalboard: Spotify's Audio Effects Library for Python"
                        })
                    }), (0, s.jsxs)(o.P, {
                        children: ["Our researchers built the world's beefiest effects pedal using machine learning and Python.", " ", (0, s.jsx)(o.A, {
                            href: "https://open.spotify.com/episode/2Rgy5wETfn7HC23ZXFH0IZ",
                            children: "Say hello to Pedalboard"
                        }), ", an open source framework for adding studio-quality effects to tons of audio files \u2014 at a speed and scale that goes far beyond your DAW."]
                    }), (0, s.jsx)(o.H3, {
                        children: (0, s.jsx)(o.A, {
                            href: "https://research.atspotify.com/audio-intelligence/",
                            children: "Spotify's Audio Intelligence Lab"
                        })
                    }), (0, s.jsx)(o.P, {
                        children: "Visit the Spotify Research site to learn more about what the team does and what else they're working on."
                    })]
                })
            }

            function C() {
                return (0, s.jsxs)("svg", {
                    width: "144",
                    height: "61",
                    viewBox: "0 0 144 61",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, s.jsx)("rect", {
                        x: "48",
                        y: "26",
                        width: "43",
                        height: "16",
                        rx: "1",
                        fill: "#FFCDD2",
                        stroke: "#F573A0",
                        strokeWidth: "2"
                    }), (0, s.jsx)("rect", {
                        x: "48",
                        y: "1",
                        width: "43",
                        height: "16",
                        rx: "1",
                        fill: "#FFCDD2",
                        stroke: "#F573A0",
                        strokeWidth: "2"
                    }), (0, s.jsx)("rect", {
                        x: "100",
                        y: "1",
                        width: "43",
                        height: "16",
                        rx: "1",
                        fill: "#FFCDD2",
                        stroke: "#F573A0",
                        strokeWidth: "2"
                    }), (0, s.jsx)("rect", {
                        x: "100",
                        y: "26",
                        width: "43",
                        height: "16",
                        rx: "1",
                        fill: "#FFCDD2",
                        stroke: "#F573A0",
                        strokeWidth: "2"
                    }), (0, s.jsx)("rect", {
                        x: "1",
                        y: "44",
                        width: "43",
                        height: "16",
                        rx: "1",
                        fill: "#FFCDD2",
                        stroke: "#F573A0",
                        strokeWidth: "2"
                    })]
                })
            }

            function v() {
                return (0, s.jsxs)("svg", {
                    width: "40",
                    height: "61",
                    viewBox: "0 0 40 61",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, s.jsx)("path", {
                        d: "M5.76221 7.91669V53.631H20.8662C22.3749 51.5797 26.8533 44.1197 29.0749 39.8046C33.3434 31.5137 40.3871 20.8471 37.4451 18.4661C34.5031 16.0852 28.0308 26.2024 22.9615 18.4661C17.8922 10.7299 9.38311 8.20973 5.76221 7.91669Z",
                        stroke: "#F573A0",
                        strokeWidth: "3"
                    }), (0, s.jsx)("path", {
                        d: "M3.85742 57.4406H23.8574",
                        stroke: "#F573A0",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("path", {
                        d: "M10.5234 53.631L10.5234 10.7738",
                        stroke: "#F573A0",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("path", {
                        d: "M15.1816 53.6366L15.1816 12.6731",
                        stroke: "#F573A0",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("path", {
                        d: "M19.5454 51.7372L19.5454 14.5943",
                        stroke: "#F573A0",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("path", {
                        d: "M23.9092 49.7903L23.9092 19.7903",
                        stroke: "#F573A0",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("path", {
                        d: "M28.2729 40.3196L28.2729 21.272",
                        stroke: "#F573A0",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("path", {
                        d: "M32.6362 30.5242V20.048",
                        stroke: "#F573A0",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("path", {
                        d: "M1 60H26.7143",
                        stroke: "#F573A0",
                        strokeWidth: "2",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("circle", {
                        cx: "5.40479",
                        cy: "2.5",
                        r: "2.5",
                        fill: "#F573A0"
                    })]
                })
            }

            function P() {
                return (0, s.jsx)("svg", {
                    width: "46",
                    height: "60",
                    viewBox: "0 0 46 60",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, s.jsx)("path", {
                        d: "M0 60H1.25807L23.4516 27.1613C23.7419 26.5806 23.5806 26.2903 22.9677 26.2903H13.8065L23.4516 8.70968C23.7419 8.12903 23.5161 7.83871 22.8064 7.83871H10.5161C10.1613 7.83871 9.87097 8.03226 9.58065 8.41936L0.612902 32.2903C0.548386 32.871 0.741936 33.1613 1.22581 33.1613H10.0968L0 60ZM27.4194 39.5806H28.2903L45.129 14.8387C45.2903 14.5806 45.3226 14.3548 45.2581 14.1936C45.1935 14.0323 45 13.9677 44.7097 13.9677H37.9355L44.9677 0.967743C45.3548 0.322581 45.1613 0 44.3871 0H35.5484C35.129 0 34.8065 0.193549 34.5806 0.612903L27.871 18.2903C27.7742 18.5806 27.7742 18.8065 27.9032 18.9677C28.0323 19.129 28.2258 19.1935 28.5161 19.1935H35.0968L27.4194 39.5806Z",
                        fill: "#F573A0"
                    })
                })
            }

            function A() {
                return (0, s.jsxs)("svg", {
                    width: "67",
                    height: "62",
                    viewBox: "0 0 67 62",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, s.jsx)("path", {
                        d: "M33.5536 19.6149C33.4489 19.5827 33.338 19.5755 33.2301 19.5939C33.1221 19.6123 33.0199 19.6558 32.9318 19.7209C32.8437 19.786 32.7721 19.8709 32.7228 19.9687C32.6734 20.0665 32.6477 20.1745 32.6478 20.2841V34.1511C31.8833 33.4176 30.8868 32.9739 29.8301 32.8965C28.7735 32.8191 27.723 33.1129 26.8598 33.7271C25.9966 34.3414 25.3747 35.2376 25.1016 36.2612C24.8284 37.2849 24.9211 38.3717 25.3635 39.3344C25.8059 40.2971 26.5704 41.0752 27.5251 41.5345C28.4798 41.9938 29.5649 42.1056 30.5932 41.8505C31.6215 41.5955 32.5285 40.9896 33.1579 40.1373C33.7873 39.2851 34.0995 38.2399 34.0408 37.1821C34.0453 37.1496 34.0477 37.1168 34.0478 37.0841V26.8319L42.242 29.3519C42.3465 29.384 42.4572 29.3912 42.5651 29.3729C42.673 29.3545 42.7751 29.3112 42.8631 29.2462C42.9512 29.1813 43.0229 29.0966 43.0723 28.999C43.1217 28.9013 43.1476 28.7935 43.1478 28.6841V25.1519C43.1479 24.4032 42.908 23.6742 42.4632 23.072C42.0185 22.4697 41.3923 22.026 40.6768 21.8059L33.5536 19.6149Z",
                        fill: "#F573A0"
                    }), (0, s.jsx)("path", {
                        d: "M31.8758 5.57555C46.498 2.23022 58.6938 10.6986 61.7135 23.8975C64.1684 34.6278 60.4578 44.5836 52.2174 49.649",
                        stroke: "#F573A0",
                        strokeWidth: "5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, s.jsx)("path", {
                        d: "M35.5259 55.851C20.9516 59.399 8.63937 51.1008 5.43667 37.945C2.833 27.2499 6.405 17.2435 14.5742 12.0643",
                        stroke: "#F573A0",
                        strokeWidth: "5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, s.jsx)("path", {
                        d: "M51.4492 39.5663L51.2423 49.872L61.548 50.0788",
                        stroke: "#F573A0",
                        strokeWidth: "5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, s.jsx)("path", {
                        d: "M14.5108 22.3717L14.5745 12.0642L4.26693 12.0005",
                        stroke: "#F573A0",
                        strokeWidth: "5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })]
                })
            }

            function I() {
                return (0, s.jsxs)("svg", {
                    width: "97",
                    height: "67",
                    viewBox: "0 0 97 67",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, s.jsx)("path", {
                        d: "M41.763 18.775C41.763 19.4314 41.5022 20.0609 41.0381 20.5251C40.5739 20.9892 39.9444 21.25 39.288 21.25C38.6316 21.25 38.0021 20.9892 37.5379 20.5251C37.0737 20.0609 36.813 19.4314 36.813 18.775C36.813 18.1186 37.0737 17.4891 37.5379 17.0249C38.0021 16.5607 38.6316 16.3 39.288 16.3C39.9444 16.3 40.5739 16.5607 41.0381 17.0249C41.5022 17.4891 41.763 18.1186 41.763 18.775Z",
                        fill: "#F573A0"
                    }), (0, s.jsx)("path", {
                        d: "M41.763 18.775V6.4C41.763 5.96239 41.9368 5.54271 42.2463 5.23327C42.5557 4.92384 42.9754 4.75 43.413 4.75H47.813M41.763 18.775C41.763 19.4314 41.5022 20.0609 41.0381 20.5251C40.5739 20.9892 39.9444 21.25 39.288 21.25C38.6316 21.25 38.0021 20.9892 37.5379 20.5251C37.0737 20.0609 36.813 19.4314 36.813 18.775C36.813 18.1186 37.0737 17.4891 37.5379 17.0249C38.0021 16.5608 38.6316 16.3 39.288 16.3C39.9444 16.3 40.5739 16.5608 41.0381 17.0249C41.5022 17.4891 41.763 18.1186 41.763 18.775V18.775Z",
                        stroke: "#F573A0",
                        strokeWidth: "3.75",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("path", {
                        d: "M59.363 42.15C60.2382 42.15 61.0776 41.5706 61.6964 40.5391C62.3153 39.5077 62.663 38.1087 62.663 36.65C62.663 35.1913 62.3153 33.7924 61.6964 32.7609C61.0776 31.7295 60.2382 31.15 59.363 31.15C58.4878 31.15 57.6484 31.7295 57.0295 32.7609C56.4107 33.7924 56.063 35.1913 56.063 36.65C56.063 38.1087 56.4107 39.5077 57.0295 40.5391C57.6484 41.5706 58.4878 42.15 59.363 42.15V42.15Z",
                        stroke: "#F573A0",
                        strokeWidth: "3.75",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, s.jsx)("path", {
                        d: "M39.7007 32.25C41.0784 46.1458 52.8044 57 67.0632 57C82.2514 57 94.5632 44.6883 94.5632 29.5C94.5632 14.3118 82.2514 2.00003 67.0632 2.00003C63.2778 1.99486 59.5325 2.77389 56.0632 4.28802",
                        stroke: "#F573A0",
                        strokeWidth: "3.75",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, s.jsx)("path", {
                        d: "M76.688 20.7C77.0527 20.7 77.4024 20.5841 77.6603 20.3778C77.9181 20.1715 78.063 19.8917 78.063 19.6C78.063 19.3083 77.9181 19.0285 77.6603 18.8222C77.4024 18.6159 77.0527 18.5 76.688 18.5C76.3233 18.5 75.9736 18.6159 75.7157 18.8222C75.4578 19.0285 75.313 19.3083 75.313 19.6C75.313 19.8917 75.4578 20.1715 75.7157 20.3778C75.9736 20.5841 76.3233 20.7 76.688 20.7ZM57.438 20.7C57.8027 20.7 58.1524 20.5841 58.4103 20.3778C58.6681 20.1715 58.813 19.8917 58.813 19.6C58.813 19.3083 58.6681 19.0285 58.4103 18.8222C58.1524 18.6159 57.8027 18.5 57.438 18.5C57.0733 18.5 56.7236 18.6159 56.4657 18.8222C56.2079 19.0285 56.063 19.3083 56.063 19.6C56.063 19.8917 56.2079 20.1715 56.4657 20.3778C56.7236 20.5841 57.0733 20.7 57.438 20.7Z",
                        fill: "#F573A0",
                        stroke: "#F573A0",
                        strokeWidth: "3.75",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, s.jsx)("path", {
                        d: "M28.313 53C27.6499 53 27.0141 52.5786 26.5452 51.8284C26.0764 51.0783 25.813 50.0609 25.813 49C25.813 47.9391 26.0764 46.9217 26.5452 46.1716C27.0141 45.4214 27.6499 45 28.313 45C28.976 45 29.6119 45.4214 30.0808 46.1716C30.5496 46.9217 30.813 47.9391 30.813 49C30.813 50.0609 30.5496 51.0783 30.0808 51.8284C29.6119 52.5786 28.976 53 28.313 53V53Z",
                        stroke: "#F573A0",
                        strokeWidth: "3",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, s.jsx)("path", {
                        d: "M40.8877 50.1585C37.7814 59.2928 28.1707 64.7552 18.5517 62.516C8.3057 60.1307 1.92885 49.9124 4.30814 39.692C6.68744 29.4716 16.9217 23.1204 27.1677 25.5056C29.7221 26.0966 32.1267 27.209 34.2299 28.7728",
                        stroke: "#F573A0",
                        strokeWidth: "3.75",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, s.jsx)("path", {
                        d: "M15.813 38C15.5478 38 15.2934 37.8946 15.1059 37.7071C14.9183 37.5196 14.813 37.2652 14.813 37C14.813 36.7348 14.9183 36.4804 15.1059 36.2929C15.2934 36.1054 15.5478 36 15.813 36C16.0782 36 16.3326 36.1054 16.5201 36.2929C16.7076 36.4804 16.813 36.7348 16.813 37C16.813 37.2652 16.7076 37.5196 16.5201 37.7071C16.3326 37.8946 16.0782 38 15.813 38ZM29.813 38C29.5478 38 29.2934 37.8946 29.1059 37.7071C28.9183 37.5196 28.813 37.2652 28.813 37C28.813 36.7348 28.9183 36.4804 29.1059 36.2929C29.2934 36.1054 29.5478 36 29.813 36C30.0782 36 30.3326 36.1054 30.5201 36.2929C30.7076 36.4804 30.813 36.7348 30.813 37C30.813 37.2652 30.7076 37.5196 30.5201 37.7071C30.3326 37.8946 30.0782 38 29.813 38Z",
                        fill: "#F573A0",
                        stroke: "#F573A0",
                        strokeWidth: "3",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })]
                })
            }

            function L() {
                return (0, s.jsxs)("svg", {
                    width: "114",
                    height: "36",
                    viewBox: "0 0 114 36",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, s.jsx)("rect", {
                        x: "4",
                        y: "17",
                        width: "46",
                        height: "16",
                        rx: "1",
                        fill: "#FFCDD2",
                        stroke: "#F573A0",
                        strokeWidth: "2"
                    }), (0, s.jsx)("rect", {
                        x: "67",
                        y: "1",
                        width: "44",
                        height: "16",
                        rx: "1",
                        fill: "#FFCDD2",
                        stroke: "#F573A0",
                        strokeWidth: "2"
                    }), (0, s.jsx)("path", {
                        d: "M60.5 17.5C68 5.49999 73.5059 5.75146 78.5 6.99999C87.5 9.24999 89.5 21 103 17.5C106.167 16.8333 110 15.5 113 13",
                        stroke: "#191414",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeDasharray: "3 3"
                    }), (0, s.jsx)("path", {
                        d: "M1 35C4.5 33.6667 13.1 29.2 19.5 22C25.9 14.8 33.4 16.5 40 22C43 24.5 50.5 25.5 50.5 22.5",
                        stroke: "#191414",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeDasharray: "3 3"
                    })]
                })
            }

            function M() {
                var e = (0, u.Z)(["\n  display: grid;\n  grid-template-columns: 1fr 1fr 1fr;\n  text-align: center;\n  @media (min-width: ", ") and (max-width: ", ") {\n    grid-template-columns: 1fr 1fr;\n  }\n\n  @media (max-width: ", ") {\n    grid-template-columns: 1fr;\n  }\n\n  > div {\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    padding-bottom: ", ";\n    > * {\n      max-width: 180px;\n    }\n    > svg {\n      height: 80px;\n    }\n  }\n"]);
                return M = function() {
                    return e
                }, e
            }
            var S = p.ZP.div(M(), m.gXv, m.rmE, m.gXv, m.nuo);

            function F() {
                return (0, s.jsxs)(r.$, {
                    light: !0,
                    children: [(0, s.jsx)(o.H2, {
                        children: "Multitalented, but refreshingly basic"
                    }), (0, s.jsx)(o.P, {
                        children: "The AI model in Basic Pitch combines a lot of audio processing power in a slim package. And pitch bend detection means you also get more nuanced and expressive MIDI."
                    }), (0, s.jsxs)(S, {
                        children: [(0, s.jsxs)("div", {
                            children: [(0, s.jsx)(v, {}), (0, s.jsx)(o.H4, {
                                children: "Versatile"
                            }), (0, s.jsx)(o.P, {
                                children: "Works on any single instrument recording"
                            })]
                        }), (0, s.jsxs)("div", {
                            children: [(0, s.jsx)(I, {}), (0, s.jsx)(o.H4, {
                                children: "Polyphonic"
                            }), (0, s.jsx)(o.P, {
                                children: "Supports instruments that play multiple notes at a time"
                            })]
                        }), (0, s.jsxs)("div", {
                            children: [(0, s.jsx)(P, {}), (0, s.jsx)(o.H4, {
                                children: "Fast"
                            }), (0, s.jsx)(o.P, {
                                children: "Runs up to 10x faster than real time on most modern computers"
                            })]
                        }), (0, s.jsxs)("div", {
                            children: [(0, s.jsx)(C, {}), (0, s.jsx)(o.H4, {
                                children: "Accurate"
                            }), (0, s.jsx)(o.P, {
                                children: "Uses AI-powered note detection developed at Spotify"
                            })]
                        }), (0, s.jsxs)("div", {
                            children: [(0, s.jsx)(L, {}), (0, s.jsx)(o.H4, {
                                children: "Pitch Bend Detection"
                            }), (0, s.jsx)(o.P, {
                                children: "Go crazy with that whammy bar or pitch wheel \u2014 Basic Pitch recognizes pitch bends, too"
                            })]
                        }), (0, s.jsxs)("div", {
                            children: [(0, s.jsx)(A, {}), (0, s.jsx)(o.H4, {
                                children: "Simple"
                            }), (0, s.jsxs)(o.P, {
                                children: ["Convert to MIDI using the", " ", (0, s.jsx)(d(), {
                                    href: "/",
                                    passHref: !0,
                                    children: (0, s.jsx)(o.A, {
                                        target: "_self",
                                        children: "online demo"
                                    })
                                }), ", then import the file to your DAW"]
                            })]
                        })]
                    })]
                })
            }

            function B() {
                return (0, s.jsxs)(r.$, {
                    light: !0,
                    children: [(0, s.jsx)(o.H2, {
                        children: "Not your average MIDI converter"
                    }), (0, s.jsx)(o.P, {
                        children: "Audio-to-MIDI converters detect the notes being played in a recording and turn them into a kind of digital score, which then allows you to easily manipulate the audio by changing instruments, key, tempo, and more."
                    }), (0, s.jsx)(o.P, {
                        children: "Some MIDI converters only work with specific instruments (like piano) or monophonic instruments (like voice). Basic Pitch provides quality MIDI conversions of almost any recorded instrument."
                    })]
                })
            }

            function D() {
                return (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)(a, {}), (0, s.jsx)(B, {}), (0, s.jsx)(k, {}), (0, s.jsx)(F, {}), (0, s.jsx)(l, {}), (0, s.jsx)(c, {}), (0, s.jsx)(w, {}), (0, s.jsx)(b, {})]
                })
            }
            var H = i(14801);

            function W() {
                return (0, s.jsx)(H.T, {
                    title: "About",
                    darkFooter: !0,
                    children: (0, s.jsx)(D, {})
                })
            }
        }
    },
    function(e) {
        e.O(0, [226, 992, 119, 774, 888, 179], (function() {
            return t = 63508, e(e.s = t);
            var t
        }));
        var t = e.O();
        _N_E = t
    }
]);
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [405], {
        53671: function(n, e, t) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/", function() {
                return t(99663)
            }])
        },
        99663: function(n, e, t) {
            "use strict";
            t.r(e), t.d(e, {
                SOUNDFILE_PATH: function() {
                    return Re
                },
                default: function() {
                    return Be
                }
            });
            var r = t(27606),
                i = t(33647),
                o = t(77374),
                a = t(60335),
                s = t(61473),
                l = t(6509),
                u = t(7263),
                d = t.n(u),
                c = t(88356),
                h = t(23169),
                f = t(20465);

            function p() {
                var n = (0, i.Z)(["\n  display: flex;\n  flex-direction: row;\n"]);
                return p = function() {
                    return n
                }, n
            }

            function g() {
                var n = (0, i.Z)(["\n  background-color: #ffcdd2;\n  block-size: 9px;\n  border-radius: 5px;\n  flex-grow: 1;\n  border: 2px solid #ffcdd2;\n  margin-top: 5px;\n  box-sizing: border-box;\n"]);
                return g = function() {
                    return n
                }, n
            }

            function m() {
                var n = (0, i.Z)(["\n  inline-size: ", ";\n  background-color: #000;\n  block-size: 5px;\n  border-radius: 3px;\n"]);
                return m = function() {
                    return n
                }, n
            }

            function v() {
                var n = (0, i.Z)(["\n  width: 40px;\n  margin-left: 15px;\n  vertical-align: middle;\n  text-align: right;\n  flex-shrink: 0;\n  flex-grow: 0;\n  font-weight: 300;\n"]);
                return v = function() {
                    return n
                }, n
            }
            var x = h.ZP.div(p()),
                w = h.ZP.div(g()),
                y = h.ZP.div(m(), (function(n) {
                    return "".concat(n.progressValue, "%")
                })),
                C = h.ZP.div(v()),
                b = function(n) {
                    var e = n.value,
                        t = void 0 === e ? 0 : e;
                    return (0, f.jsxs)(x, {
                        children: [(0, f.jsx)(w, {
                            role: "progressbar",
                            "aria-valuenow": t,
                            "aria-valuemin": 0,
                            "aria-valuemax": 100,
                            children: (0, f.jsx)(y, {
                                progressValue: t
                            })
                        }), (0, f.jsx)(C, {
                            children: "".concat(t, "%")
                        })]
                    })
                };

            function j() {
                var n = (0, i.Z)(["\n  margin: 0;\n  color: #ffcdd2;\n  font-weight: 400;\n  font-size: 12px;\n  line-height: 15px;\n  margin-top: ", ";\n"]);
                return j = function() {
                    return n
                }, n
            }
            var Z = h.ZP.p(j(), l.nuo),
                k = function(n) {
                    var e = n.value,
                        t = n.children;
                    return (0, f.jsxs)("div", {
                        children: [(0, f.jsx)(b, {
                            value: Math.trunc(e)
                        }), (0, f.jsx)(Z, {
                            children: t
                        })]
                    })
                };

            function T() {
                var n = (0, i.Z)(["\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n"]);
                return T = function() {
                    return n
                }, n
            }

            function S() {
                var n = (0, i.Z)(["\n  animation: ", " 1s linear infinite;\n  transform: translateZ(0);\n\n  border-top: 2px solid grey;\n  border-right: 2px solid grey;\n  border-bottom: 2px solid grey;\n  border-left: 4px solid black;\n  background: transparent;\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n"]);
                return S = function() {
                    return n
                }, n
            }
            var M = (0, h.F4)(T()),
                F = h.ZP.div(S(), M);

            function P() {
                var n = (0, i.Z)(["\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  margin-top: ", ";\n"]);
                return P = function() {
                    return n
                }, n
            }

            function E() {
                var n = (0, i.Z)(["\n  margin: 0 0 0 20px;\n  color: #ffcdd2;\n  font-weight: 400;\n  font-size: 12px;\n  line-height: 15px;\n"]);
                return E = function() {
                    return n
                }, n
            }
            var D = h.ZP.div(P(), l.nuo),
                L = h.ZP.p(E()),
                R = function(n) {
                    var e = n.children;
                    return (0, f.jsxs)(D, {
                        children: [(0, f.jsx)(F, {}), (0, f.jsx)(L, {
                            children: e
                        })]
                    })
                },
                N = t(14801),
                _ = t(99195),
                I = t(13005),
                B = t(92768),
                O = t(96111),
                A = t(71958),
                H = t(18239).Buffer;

            function U(n, e) {
                var t = e || {},
                    r = t.sampleRate || 16e3,
                    i = t.numChannels || 1,
                    o = H.alloc(44);
                return o.write("RIFF", 0), o.writeUInt32LE(4 * n.length + 36, 4), o.write("WAVE", 8), o.write("fmt ", 12), o.writeUInt32LE(16, 16), o.writeUInt16LE(3, 20), o.writeUInt16LE(i, 22), o.writeUInt32LE(r, 24), o.writeUInt32LE(4 * r, 28), o.writeUInt16LE(4, 32), o.writeUInt16LE(32, 34), o.write("data", 36), o.writeUInt32LE(4 * n.length, 40), H.concat([o, new Uint8Array(n.buffer)])
            }
            var q = function(n) {
                    return n[n.defaultOnsetThresh = .5] = "defaultOnsetThresh", n[n.defaultFrameThresh = .3] = "defaultFrameThresh", n[n.defaultMinNoteLen = 11] = "defaultMinNoteLen", n[n.defaultInferOnsets = 1] = "defaultInferOnsets", n[n.defaultMaxFreq = 3e3] = "defaultMaxFreq", n[n.defaultMinFreq = 0] = "defaultMinFreq", n
                }({}),
                V = function(n) {
                    return n.OnsetThreshold = "Note Segmentation", n.FrameThreshold = "Model Confidence Threshold", n.MinimumNoteLength = "Minimum Note Length", n.InferOnsets = "Boost Onsets", n.MaxFreq = "Maximum Pitch", n.MinFreq = "Minimum Pitch", n.FileTempo = "MIDI File Tempo", n
                }({});
            var W = t(70119),
                z = t(2013),
                $ = t(44e3),
                G = t(80285),
                J = t(96851),
                X = t(33013),
                K = t(44897);
            var Y = function(n) {
                    (0, G.Z)(t, n);
                    var e = (0, J.Z)(t);

                    function t(n) {
                        var r;
                        return (0, z.Z)(this, t), (r = e.call(this, n)).state = {
                            loading: !1,
                            fileData: null
                        }, r._onGenerate = r._onGenerate.bind((0, W.Z)(r)), r._donePreparing = r._donePreparing.bind((0, W.Z)(r)), r._onDownload = r._onDownload.bind((0, W.Z)(r)), r
                    }
                    return (0, $.Z)(t, [{
                        key: "_onGenerate",
                        value: function() {
                            this.setState({
                                loading: !0,
                                fileData: null
                            }), this.props.genFile && this.props.genFile(this._donePreparing)
                        }
                    }, {
                        key: "_donePreparing",
                        value: function(n) {
                            this.setState({
                                loading: !1,
                                fileData: n
                            })
                        }
                    }, {
                        key: "_onDownload",
                        value: function() {
                            var n = this.props.fileData || (this.props.async ? this.state.fileData : this.props.genFile && this.props.genFile());
                            if (!n) return !1;
                            var e = new Blob([n.contents], {
                                type: n.mime
                            });
                            return function(n, e) {
                                var t = document.createElement("a");
                                "string" === typeof t.download ? (document.body.appendChild(t), t.download = e, t.href = n, t.click(), document.body.removeChild(t)) : location.replace(n)
                            }(URL.createObjectURL(e), n.filename), this.props.onDownloaded && this.props.onDownloaded()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            if (!this.props.genFile && !this.props.fileData) return (0, f.jsx)("em", {
                                children: "Invalid configuration for download button"
                            });
                            var n = "DownloadButton ".concat(this.props.className || "");
                            if (this.props.fileData || !this.props.async || this.state.fileData) {
                                var e = this.props.downloadTitle;
                                return (0, f.jsx)(K.DF, {
                                    $yellow: !0,
                                    iconLeading: X.D,
                                    onClick: this._onDownload,
                                    className: n,
                                    disabled: this.props.disabled,
                                    children: e
                                })
                            }
                            return this.state.loading ? (0, f.jsx)(K.DF, {
                                $yellow: !0,
                                className: "".concat(n, " DownloadButton-loading"),
                                children: this.props.loadingTitle
                            }) : (0, f.jsx)(K.DF, {
                                $yellow: !0,
                                onClick: this._onGenerate,
                                className: "".concat(n, " DownloadButton-generate"),
                                disabled: this.props.disabled,
                                children: this.props.generateTitle
                            })
                        }
                    }]), t
                }(c.Component),
                Q = t(30673),
                nn = t(70578),
                en = t(159),
                tn = t(85457),
                rn = function(n) {
                    (0, G.Z)(i, n);
                    var e = (0, J.Z)(i);

                    function i() {
                        var n;
                        return (0, z.Z)(this, i), n = e.apply(this, arguments), (0, Q.Z)((0, W.Z)(n), "state", {
                            loading: !0,
                            isPlaying: !1,
                            seeking: !1
                        }), (0, Q.Z)((0, W.Z)(n), "ac", void 0), (0, Q.Z)((0, W.Z)(n), "gain", void 0), (0, Q.Z)((0, W.Z)(n), "JSSynth", void 0), (0, Q.Z)((0, W.Z)(n), "sFontId", void 0), (0, Q.Z)((0, W.Z)(n), "synth", void 0), (0, Q.Z)((0, W.Z)(n), "watchingEndOfFile", !1), n
                    }
                    return (0, $.Z)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            var n = this;
                            return (0, r.Z)((function() {
                                return (0, a.__generator)(this, (function(e) {
                                    switch (e.label) {
                                        case 0:
                                            return [4, t.e(715).then(t.bind(t, 85715))];
                                        case 1:
                                            return n.JSSynth = e.sent(), [4, n.JSSynth.waitForReady().then(n._loadJsSynth.bind(n))];
                                        case 2:
                                            return e.sent(), [2]
                                    }
                                }))
                            }))()
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function(n, e) {
                            var t = this;
                            this.props.skipToPercentage !== n.skipToPercentage && "undefined" !== typeof n.skipToPercentage && this.seek(this.props.skipToPercentage), !0 === this.state.isPlaying && !1 === e.isPlaying ? (this.watchingEndOfFile = !0, this.watchEndOfFile()) : !1 === this.state.isPlaying && !0 === e.isPlaying && (this.watchingEndOfFile = !1), this.synth && !this.sFontId && null !== this.props.soundfont && null === n.soundfont && this.synth.loadSFont(this.props.soundfont).then((function(n) {
                                return t.sFontId = n
                            }))
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            var n = this;
                            return (0, r.Z)((function() {
                                return (0, a.__generator)(this, (function(e) {
                                    switch (e.label) {
                                        case 0:
                                            return n.watchingEndOfFile = !1, [4, n.stop()];
                                        case 1:
                                            return e.sent(), [4, n.synth.waitForPlayerStopped()];
                                        case 2:
                                            return e.sent(), [4, n.synth.waitForVoicesStopped()];
                                        case 3:
                                            return e.sent(), [4, n.synth.resetPlayer()];
                                        case 4:
                                            return e.sent(), n.synth.unloadSFont(n.sFontId), n.synth.close(), n.props.onTickUpdate(0), [4, n.ac.close()];
                                        case 5:
                                            return e.sent(), [2]
                                    }
                                }))
                            }))()
                        }
                    }, {
                        key: "_loadJsSynth",
                        value: function() {
                            var n = this;
                            return (0, r.Z)((function() {
                                return (0, a.__generator)(this, (function(e) {
                                    switch (e.label) {
                                        case 0:
                                            return n.ac = new AudioContext({
                                                sampleRate: 44100
                                            }), n.synth = new n.JSSynth.Synthesizer, n.synth.init(n.ac.sampleRate), n.synth.setReverbOn(!1), n.gain = new GainNode(n.ac), n.gain.connect(n.ac.destination), n.synth.createAudioNode(n.ac, 8192).connect(n.gain), [4, n.addMidiToSynth()];
                                        case 1:
                                            return e.sent(), [2]
                                    }
                                }))
                            }))()
                        }
                    }, {
                        key: "addMidiToSynth",
                        value: function() {
                            var n = this;
                            return (0, r.Z)((function() {
                                var e;
                                return (0, a.__generator)(this, (function(t) {
                                    switch (t.label) {
                                        case 0:
                                            return e = new Uint8Array(n.props.midiBuffer), [4, n.synth.addSMFDataToPlayer(e.buffer)];
                                        case 1:
                                            return t.sent(), n.sFontId || null === n.props.soundfont ? [3, 3] : [4, n.synth.loadSFont(n.props.soundfont)];
                                        case 2:
                                            n.sFontId = t.sent(), t.label = 3;
                                        case 3:
                                            return [2]
                                    }
                                }))
                            }))()
                        }
                    }, {
                        key: "watchEndOfFile",
                        value: function() {
                            var n = this;
                            return (0, r.Z)((function() {
                                var e, t, r, i, o;
                                return (0, a.__generator)(this, (function(a) {
                                    switch (a.label) {
                                        case 0:
                                            return e = 0, t = Date.now(), [4, n.synth.retrievePlayerCurrentTick()];
                                        case 1:
                                            return r = a.sent(), [4, n.synth.retrievePlayerTotalTicks()];
                                        case 2:
                                            i = a.sent(), a.label = 3;
                                        case 3:
                                            return !0 === n.watchingEndOfFile && 0 === i && n.state.isPlaying ? [4, n.synth.retrievePlayerTotalTicks()] : [3, 6];
                                        case 4:
                                            return i = a.sent(), [4, new Promise((function(n) {
                                                return setTimeout(n, 20)
                                            }))];
                                        case 5:
                                            return a.sent(), [3, 3];
                                        case 6:
                                            return !0 === n.watchingEndOfFile && r < i ? n.state.seeking || n.props.seeking || !n.state.isPlaying ? [3, 8] : [4, n.synth.retrievePlayerCurrentTick()] : [3, 10];
                                        case 7:
                                            r = a.sent(), 0 === i ? n.props.onTickUpdate(0) : e !== r ? (e = r, n.props.onTickUpdate(Math.min(100, 100 * r / i)), t = Date.now()) : e === r && (o = Date.now() - t, n.props.onTickUpdate(Math.min(100, 100 * (r + o + 40) / i))), a.label = 8;
                                        case 8:
                                            return [4, new Promise((function(n) {
                                                return setTimeout(n, 40)
                                            }))];
                                        case 9:
                                            return a.sent(), [3, 6];
                                        case 10:
                                            return !0 !== n.watchingEndOfFile ? [3, 16] : [4, new Promise((function(n) {
                                                return setTimeout(n, 50)
                                            }))];
                                        case 11:
                                            return a.sent(), [4, n.synth.waitForVoicesStopped()];
                                        case 12:
                                            return a.sent(), n.seek(0), [4, n.stop()];
                                        case 13:
                                            return a.sent(), [4, n.synth.resetPlayer()];
                                        case 14:
                                            return a.sent(), [4, n.addMidiToSynth()];
                                        case 15:
                                            a.sent(), a.label = 16;
                                        case 16:
                                            return [2]
                                    }
                                }))
                            }))()
                        }
                    }, {
                        key: "seek",
                        value: function(n) {
                            var e = this;
                            return (0, r.Z)((function() {
                                var t, r, i;
                                return (0, a.__generator)(this, (function(o) {
                                    switch (o.label) {
                                        case 0:
                                            return e.setState({
                                                seeking: !0
                                            }), e.props.onTickUpdate(n), r = (t = e.synth).seekPlayer, i = n / 100, [4, e.synth.retrievePlayerTotalTicks()];
                                        case 1:
                                            return r.apply(t, [i * o.sent()]), e.setState({
                                                seeking: !1
                                            }), [2]
                                    }
                                }))
                            }))()
                        }
                    }, {
                        key: "play",
                        value: function() {
                            var n = this;
                            return (0, r.Z)((function() {
                                return (0, a.__generator)(this, (function(e) {
                                    switch (e.label) {
                                        case 0:
                                            return n.gain.gain.exponentialRampToValueAtTime(.8, n.ac.currentTime + .5), [4, n.synth.playPlayer()];
                                        case 1:
                                            return e.sent(), n.setState({
                                                isPlaying: !0
                                            }), n.props.setPlaying(!0), [2]
                                    }
                                }))
                            }))()
                        }
                    }, {
                        key: "stop",
                        value: function() {
                            var n = this;
                            return (0, r.Z)((function() {
                                return (0, a.__generator)(this, (function(e) {
                                    switch (e.label) {
                                        case 0:
                                            return [4, new Promise((function(e) {
                                                n.gain.gain.exponentialRampToValueAtTime(.01, n.ac.currentTime + .2), setTimeout(e, 200)
                                            }))];
                                        case 1:
                                            return e.sent(), n.synth.stopPlayer(), n.setState({
                                                isPlaying: !1
                                            }), n.props.setPlaying(!1), [2]
                                    }
                                }))
                            }))()
                        }
                    }, {
                        key: "togglePlay",
                        value: function() {
                            var n = this;
                            return (0, r.Z)((function() {
                                return (0, a.__generator)(this, (function(e) {
                                    switch (e.label) {
                                        case 0:
                                            return n.state.isPlaying ? [4, n.stop()] : [3, 2];
                                        case 1:
                                            return e.sent(), [3, 4];
                                        case 2:
                                            return [4, n.play()];
                                        case 3:
                                            e.sent(), e.label = 4;
                                        case 4:
                                            return [2]
                                    }
                                }))
                            }))()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var n = this,
                                e = this.state.isPlaying ? "Pause" : "Play";
                            return (0, f.jsxs)(f.Fragment, {
                                children: [(0, f.jsx)(K.DF, {
                                    $yellow: !0,
                                    "aria-label": "seekBack",
                                    iconOnly: nn.y,
                                    onClick: function() {
                                        return n.seek(0)
                                    },
                                    disabled: this.props.disabled
                                }), (0, f.jsx)(K.DF, {
                                    $yellow: !0,
                                    disabled: null === this.props.soundfont || this.props.disabled,
                                    iconLeading: this.state.isPlaying ? en.I : tn.q,
                                    onClick: this.togglePlay.bind(this),
                                    style: {
                                        minWidth: 147
                                    },
                                    children: e
                                })]
                            })
                        }
                    }]), i
                }(c.Component);

            function on() {
                return (0, f.jsx)("svg", {
                    width: "30",
                    height: "30",
                    viewBox: "0 0 30 30",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, f.jsx)("path", {
                        d: "M27.5 0H2.5C1.83696 0 1.20107 0.263392 0.732233 0.732233C0.263392 1.20107 0 1.83696 0 2.5V27.5C0 28.163 0.263392 28.7989 0.732233 29.2678C1.20107 29.7366 1.83696 30 2.5 30H27.5C28.163 30 28.7989 29.7366 29.2678 29.2678C29.7366 28.7989 30 28.163 30 27.5V2.5C30 1.83696 29.7366 1.20107 29.2678 0.732233C28.7989 0.263392 28.163 0 27.5 0ZM11.875 18.75C12.2065 18.75 12.5245 18.6183 12.7589 18.3839C12.9933 18.1495 13.125 17.8315 13.125 17.5V2.5H16.875V17.5C16.875 17.8315 17.0067 18.1495 17.2411 18.3839C17.4755 18.6183 17.7935 18.75 18.125 18.75H19.375V27.5H10.625V18.75H11.875ZM2.5 2.5H5.625V17.5C5.625 17.8315 5.7567 18.1495 5.99112 18.3839C6.22554 18.6183 6.54348 18.75 6.875 18.75H8.125V27.5H2.5V2.5ZM27.5 27.5H21.875V18.75H23.125C23.4565 18.75 23.7745 18.6183 24.0089 18.3839C24.2433 18.1495 24.375 17.8315 24.375 17.5V2.5H27.5V27.5Z",
                        fill: "black"
                    })
                })
            }

            function an() {
                return (0, f.jsxs)("svg", {
                    width: "43",
                    height: "41",
                    viewBox: "0 0 43 41",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, f.jsx)("path", {
                        d: "M18.3928 19.8327L39.6238 3.63635L40.8599 5.15643L21.4196 23.2337L18.3928 19.8327Z",
                        fill: "#191414"
                    }), (0, f.jsx)("path", {
                        d: "M38.0704 1.22753C37.8332 1.98256 38.1339 2.70418 38.5916 3.30553C38.8321 3.61957 39.1061 3.90354 39.3834 4.18083C39.507 4.30778 39.6673 4.43139 39.7709 4.57505C39.8477 4.68195 40.0081 4.86236 40.0582 4.99599C40.0983 5.10624 40.0682 5.27328 40.0682 5.39355C40.0682 5.62407 40.0348 5.79779 39.9847 5.99156C40.2186 5.89134 40.4257 5.73098 40.6495 5.62407C41.752 5.09622 42.654 4.21424 42.5638 2.90797C42.4903 1.78545 41.5382 0.452458 40.4224 0.10167C39.9607 -0.0445238 39.4634 -0.032769 39.0092 0.135079C38.4412 0.352233 38.2207 0.746451 38.0704 1.22753Z",
                        fill: "#191414"
                    }), (0, f.jsx)("path", {
                        d: "M36.7508 4.59509C36.3666 4.87907 35.9323 5.0862 35.5782 5.40692C34.9702 5.95481 35.2341 6.17531 35.625 6.79002C35.8054 7.07399 35.9891 7.33792 36.1963 7.60184C36.36 7.81232 36.5571 7.95931 36.7141 8.1631C37.1384 8.70766 37.6696 9.12861 38.2976 8.59741C38.6017 8.34351 38.8489 8.02279 39.1362 7.74884C39.6941 7.21431 40.2253 6.65305 40.7699 6.09847C41.6485 5.20313 42.4403 4.50489 42.4403 3.14851C42.4403 2.8445 42.447 2.50039 42.2098 2.28324C41.2944 1.43467 40.0516 2.31999 39.2264 2.86454C38.3868 3.42055 37.5614 3.99758 36.7508 4.59509Z",
                        fill: "#191414"
                    }), (0, f.jsx)("path", {
                        d: "M34.058 4.23088C34.1014 3.67297 34.7061 3.32218 35.1939 3.54267C35.4611 3.66294 35.6783 3.87676 35.8754 4.08723C36.0558 4.27766 36.0859 4.53156 36.3699 4.6251C36.4968 4.66519 36.6405 4.63178 36.7741 4.64849C36.7407 4.7721 36.6137 4.88903 36.5202 4.97255C36.4099 5.07277 36.3197 5.17968 36.2162 5.28659C36.0859 5.42022 35.9356 5.53047 35.7752 5.62735C35.7351 5.65408 35.2908 5.86121 35.2941 5.87458C35.2774 5.73426 35.3576 5.52045 35.2407 5.4102C34.8264 5.01598 33.9945 5.02266 34.058 4.23088Z",
                        fill: "#191414"
                    }), (0, f.jsx)("path", {
                        d: "M37.125 4.54832C37.2018 4.4815 37.2787 4.41468 37.3589 4.35121C37.6595 4.11735 38.3077 3.78661 38.4513 3.40575C38.3277 3.4592 38.1005 3.54941 37.9702 3.47257C37.87 3.41243 37.8132 3.21198 37.7631 3.11176C37.6128 2.8211 37.5092 2.45695 37.2219 2.26653C36.9413 2.08612 36.5671 2.02599 36.2731 2.20305C35.9323 2.41018 35.7887 2.73424 35.9323 3.11176C36.0158 3.33559 36.1562 3.55275 36.3265 3.72313C36.684 4.07392 37.0081 4.27103 36.6539 4.80556C36.6673 4.78217 36.958 4.67861 37.0148 4.63518C37.0515 4.60845 37.0883 4.57838 37.125 4.54832ZM37.9134 8.09628C37.9101 8.1063 37.9101 8.11633 37.9068 8.12635C37.8834 8.24662 37.9134 8.36689 37.9134 8.48716C37.9168 8.58404 37.8566 8.68761 37.8633 8.77781C38.0604 8.84129 38.1573 8.62079 38.3611 8.80788C38.5682 9.00165 38.5148 9.34575 38.7253 9.55289C39.1328 9.95045 39.8311 10.0273 40.1986 9.5295C40.4825 9.14196 40.3723 8.72436 40.0248 8.42034C39.5972 8.04283 39.2197 8.11967 39.4235 7.45818C39.33 7.44816 39.1863 7.48825 39.0961 7.50829C39.0193 7.525 38.919 7.54504 38.8389 7.53502C38.6584 7.51498 38.3511 7.40807 38.1941 7.5417C38.0337 7.67868 37.9502 7.89249 37.9134 8.09628Z",
                        fill: "#191414"
                    }), (0, f.jsx)("path", {
                        d: "M39.4535 6.51265C39.4468 6.52602 39.4435 6.53938 39.4402 6.55609C39.4001 6.72981 39.5103 6.89685 39.5103 7.07391C39.5137 7.1708 39.5137 7.40466 39.4234 7.47147C39.5337 7.36457 39.6339 7.26434 39.8043 7.29107C40.0348 7.32782 40.135 7.62849 40.2921 7.77215C40.5393 7.99264 40.8834 8.17305 41.2141 8.19309C41.8021 8.22984 42.4536 7.55834 42.0627 6.95699C41.7687 6.50597 40.703 6.6797 40.9803 5.95808C41.0103 5.88458 41.0705 5.82778 41.0872 5.74426C40.9636 5.90128 40.7197 6.04494 40.5359 6.11509C40.4524 6.1485 40.3422 6.17857 40.2553 6.18859C40.135 6.2053 40.0382 6.1485 39.9246 6.14182C39.6941 6.13848 39.5304 6.29884 39.4535 6.51265ZM11.4172 22.415C10.9362 22.6088 10.4785 22.562 10.0642 21.9239C9.96731 21.7736 9.7702 21.68 9.5898 21.66C8.44723 21.5264 8.36705 23.0398 9.06195 23.6411C10.2646 24.6901 11.5642 24.0721 12.7135 23.297C13.2948 22.9061 13.8494 22.4618 14.4908 22.1711C14.8048 22.0275 15.2057 21.8571 15.5599 21.8972C16.041 21.9506 16.0476 22.4117 16.4519 22.5086C17.0165 22.6455 17.6646 22.1077 17.4942 21.5297C17.1902 20.4807 15.6568 20.5408 14.8382 20.6544C13.993 20.7713 13.2514 21.2391 12.5631 21.7101C12.1723 21.9807 11.7881 22.268 11.4172 22.415ZM18.4497 30.8072C18.1724 31.2448 18.1357 31.7025 18.6835 32.2271C18.8172 32.3507 18.8706 32.5611 18.8606 32.7415C18.7838 33.8908 17.2804 33.6937 16.816 32.8986C16.0075 31.5221 16.8494 30.3595 17.825 29.3706C18.3194 28.8729 18.8539 28.4085 19.2615 27.8305C19.4586 27.5499 19.6992 27.1857 19.7259 26.8349C19.7593 26.3505 19.3083 26.2603 19.2882 25.8461C19.2582 25.2681 19.9063 24.7269 20.4442 24.9975C21.4164 25.4919 21.0789 26.9886 20.815 27.7704C20.5444 28.5789 19.9497 29.2236 19.3584 29.8116C19.0176 30.1457 18.6635 30.4698 18.4497 30.8072Z",
                        fill: "#191414"
                    }), (0, f.jsx)("path", {
                        d: "M9.17747 29.1051L12.1283 32.3231L5.75639 36.8094L4.42407 35.0554L9.17747 29.1051Z",
                        fill: "#191414"
                    }), (0, f.jsx)("path", {
                        d: "M1 37.837L2.16565 39.3772L6.9922 34.9252L5.82655 33.385L1 37.837Z",
                        fill: "#191414"
                    }), (0, f.jsx)("path", {
                        d: "M30.0082 23.237C32.7475 19.4705 31.1496 15.3901 30.0082 13.3927C25.7281 8.25647 19.8295 10.6841 18.8798 12.1086C18.0238 13.3926 15.4559 13.3926 14.5998 13.3926H14.5997C16.3118 16.1319 14.7424 18.5288 13.7437 18.9569C12.7164 19.9841 11.0329 18.5288 10.3195 17.6728L3.89931 21.0969C2.18725 23.5223 -2.09287 28.3732 4.75534 36.0774C11.6036 42.2408 17.5958 39.7869 19.7358 37.7895L22.732 32.2253C22.0186 31.512 21.0199 29.7428 22.732 28.3732C24.8721 26.6611 25.7281 28.3732 27.0121 28.3732C26.5841 26.6611 28.7242 24.9491 30.0082 23.237Z",
                        stroke: "#191414"
                    })]
                })
            }

            function sn() {
                return (0, f.jsxs)("svg", {
                    width: "50",
                    height: "62",
                    viewBox: "0 0 50 62",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, f.jsx)("rect", {
                        x: "14.2324",
                        width: "22.2",
                        height: "34.5333",
                        rx: "10",
                        fill: "#FFCDD2"
                    }), (0, f.jsx)("path", {
                        d: "M14.622 59.2H25.3325M36.043 59.2H25.3325M6.83252 27.1333C6.83252 32.4777 10.5325 43.1666 25.3325 43.1666C40.1325 43.1666 43.8325 32.4777 43.8325 27.1333M25.3325 45.1708V59.2",
                        stroke: "#FFCDD2",
                        strokeWidth: "4",
                        strokeLinecap: "round"
                    }), (0, f.jsx)("path", {
                        d: "M13.8325 17.5L17.8325 22.5L19.8325 9L30.3325 26.5L31.8325 13.5L36.8325 19.5",
                        stroke: "#191414",
                        strokeWidth: "2"
                    }), (0, f.jsx)("rect", {
                        x: "0.83252",
                        y: "13.2417",
                        width: "3",
                        height: "5.05525",
                        transform: "rotate(-48.3502 0.83252 13.2417)",
                        fill: "#191414"
                    }), (0, f.jsx)("rect", {
                        x: "4.83252",
                        y: "7.2417",
                        width: "3",
                        height: "2.55885",
                        transform: "rotate(-48.3502 4.83252 7.2417)",
                        fill: "#191414"
                    }), (0, f.jsx)("rect", {
                        x: "46.939",
                        y: "12.6973",
                        width: "3",
                        height: "2.55885",
                        transform: "rotate(-110.124 46.939 12.6973)",
                        fill: "#191414"
                    }), (0, f.jsx)("rect", {
                        y: "7.55933",
                        width: "1.49029",
                        height: "1.33385",
                        transform: "rotate(-75.8502 0 7.55933)",
                        fill: "#191414"
                    }), (0, f.jsx)("rect", {
                        x: "44.9336",
                        y: "17.1053",
                        width: "1.49029",
                        height: "1.33385",
                        transform: "rotate(-137.624 44.9336 17.1053)",
                        fill: "#191414"
                    })]
                })
            }
            var ln = t(5630),
                un = t(36713),
                dn = t(37482),
                cn = t(74380),
                hn = t(18239).Buffer;

            function fn(n, e) {
                var t = new un.Midi,
                    r = t.addTrack();
                return e && t.header.setTempo(e), r.instrument.number = 4, n.forEach((function(n) {
                    r.addNote({
                        midi: n.pitchMidi,
                        time: n.startTimeSeconds,
                        duration: n.durationSeconds,
                        velocity: n.amplitude
                    })
                })), hn.from(t.toArray())
            }
            var pn = function(n) {
                var e = n + 80;
                return e > 127 && (e = 127), e
            };

            function gn(n) {
                var e = new un.Midi,
                    t = e.addTrack(),
                    r = [];
                return n.forEach((function(n) {
                    t.addNote({
                        midi: n.pitchMidi,
                        time: n.startTimeSeconds,
                        duration: n.durationSeconds,
                        velocity: pn(n.amplitude)
                    })
                })), t.notes.forEach((function(t, i) {
                    var o, a = e.header.ticksToMeasures(t.durationTicks);
                    r.push((0, ln.Z)((0, I.Z)({}, t.toJSON()), {
                        color: "#1ed760",
                        startBeat: 4 * t.bars,
                        endBeat: 4 * (t.bars + a),
                        pitchBends: null === (o = n[i].pitchBends) || void 0 === o ? void 0 : o.map((function(n) {
                            return 1364 * n
                        }))
                    }))
                })), r
            }
            var mn = (0, dn.C)({
                    predictableActionArguments: !0,
                    initial: "initial",
                    context: {
                        notes: [],
                        pianoRollNotes: [],
                        isPlayable: !1,
                        revision: 1,
                        MIDITempo: 120
                    },
                    states: {
                        initial: {
                            on: {
                                SET_RESULTS: {
                                    target: "active",
                                    actions: ["setResults"]
                                },
                                NO_RESULTS: {
                                    target: "badFile",
                                    actions: ["noResults"]
                                }
                            }
                        },
                        badFile: {},
                        active: {
                            initial: "idle",
                            states: {
                                idle: {
                                    on: {
                                        SET_TEMPO: {
                                            target: "idle",
                                            actions: ["setTempo"]
                                        },
                                        PROCESS: {
                                            target: "processing"
                                        },
                                        NO_RESULTS: {
                                            target: "badAdjustment",
                                            actions: ["noResults"]
                                        }
                                    }
                                },
                                badAdjustment: {
                                    on: {
                                        PROCESS: {
                                            target: "processing"
                                        }
                                    }
                                },
                                processing: {
                                    on: {
                                        PROCESS: {},
                                        SET_RESULTS: {
                                            target: "idle",
                                            actions: ["setResults"]
                                        },
                                        NO_RESULTS: {
                                            target: "idle",
                                            actions: ["noResults"]
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, {
                    actions: {
                        restart: (0, cn.f0)((function(n) {
                            return (0, I.Z)({}, n)
                        })),
                        setTempo: (0, cn.f0)((function(n, e) {
                            var t = n.notes,
                                r = e.MIDITempo;
                            return {
                                MIDITempo: r,
                                midiBuffer: fn(t, r),
                                revision: n.revision + 1
                            }
                        })),
                        setResults: (0, cn.f0)((function(n, e) {
                            var t = e.result;
                            return {
                                notes: t,
                                pianoRollNotes: gn(t),
                                midiBuffer: fn(t, n.MIDITempo),
                                isPlayable: !0,
                                revision: n.revision + 1
                            }
                        })),
                        noResults: (0, cn.f0)((function(n) {
                            return {
                                isPlayable: !1,
                                notes: [],
                                pianoRollNotes: []
                            }
                        }))
                    }
                }),
                vn = t(79320),
                xn = t(24105),
                wn = t(6755),
                yn = t(95674),
                Cn = t.n(yn),
                bn = t(41044);

            function jn() {
                var n = (0, i.Z)(["\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n\n  & > :first-child {\n    margin-bottom: ", ";\n  }\n  & > :nth-child(2) {\n    margin-bottom: ", ";\n  }\n\n  margin-bottom: ", ";\n  & > label {\n    font-size: 22px;\n    display: block;\n  }\n"]);
                return jn = function() {
                    return n
                }, n
            }

            function Zn() {
                var n = (0, i.Z)(["\n  display: inline-grid;\n  grid-template-columns: 100px 200px 100px;\n  align-items: center;\n\n  & .value-display {\n    justify-self: center;\n    margin-top: ", ";\n  }\n\n  & p.right-label {\n    justify-self: right;\n  }\n"]);
                return Zn = function() {
                    return n
                }, n
            }
            var kn = h.ZP.div(jn(), l.hM$, l.nuo, l.mGT),
                Tn = h.ZP.div(Zn(), l.hM$),
                Sn = function(n) {
                    var e = n.onChange,
                        t = (0, c.useState)(n.value),
                        r = t[0],
                        i = t[1],
                        o = (0, c.useMemo)((function() {
                            if (n.step < 1 && 1 === (r.toString().split(".")[1] || "0").length) return "".concat(r, "0");
                            return "".concat(r)
                        }), [r, n.step]),
                        a = (0, c.useMemo)((function() {
                            return Cn()((function(n) {
                                return e(n)
                            }), 250)
                        }), [e]),
                        s = function(e) {
                            var t = n.step < 1 ? parseFloat(e[0].toFixed(2)) : e[0];
                            i(t), a(t)
                        },
                        l = (0, bn.S)({
                            min: n.min,
                            max: n.max,
                            stepSize: n.step,
                            values: [r],
                            onDrag: s,
                            onChange: s
                        }),
                        u = l.getTrackProps,
                        d = l.segments,
                        h = l.handles,
                        p = "".concat(n.thresholdName, "-slider"),
                        g = "".concat(n.thresholdName),
                        m = "".concat(g, "Value"),
                        v = (0, c.useState)(0),
                        x = v[0],
                        w = v[1],
                        y = (0, c.useRef)();
                    c.useEffect((function() {
                        var n = y.current.getBoundingClientRect();
                        w(Math.ceil(n.width))
                    }), []);
                    var C = (0, c.useRef)(!1),
                        b = function(e) {
                            if ("yes" === e.nativeEvent.target.dataset.track) {
                                e.preventDefault(), C.current = !0;
                                for (var t = e.nativeEvent.offsetX / x, r = (n.max - n.min) * t + n.min, i = 1, o = n.step; o < 1;) i *= 10, o *= 10;
                                r *= i, r = Math.round(r / o) * o, s([r /= i])
                            }
                        },
                        j = u({
                            style: {
                                height: "".concat(6, "px")
                            }
                        }),
                        Z = j.ref,
                        k = (0, xn.Z)(j, ["ref"]);
                    return (0, f.jsxs)(kn, {
                        children: [(0, f.jsx)("label", {
                            htmlFor: p,
                            children: n.thresholdName
                        }), (0, f.jsx)(wn.Dy.small, {
                            children: n.desc
                        }), (0, f.jsxs)(Tn, {
                            children: [n.leftEnd ? (0, f.jsx)(wn.Dy.p, {
                                children: n.leftEnd
                            }) : (0, f.jsx)("span", {
                                children: "\xa0"
                            }), (0, f.jsxs)("div", (0, ln.Z)((0, I.Z)({}, k), {
                                ref: function(n) {
                                    Z(n), y.current = n
                                },
                                onMouseDown: b,
                                onMouseMove: function(n) {
                                    "yes" === n.nativeEvent.target.dataset.track && C.current && b(n)
                                },
                                onMouseLeave: function() {
                                    return C.current = !1
                                },
                                onMouseUp: function() {
                                    return C.current = !1
                                },
                                "data-track": "yes",
                                children: [d.map((function(n, e) {
                                    var t = n.getSegmentProps;
                                    return (0, f.jsx)("div", (0, I.Z)({}, t({
                                        key: String(e),
                                        style: {
                                            background: 0 === e ? (0, O.NE)(O.iK.essentialBrightAccent) : "#D9D9D9",
                                            height: "".concat(6, "px"),
                                            borderRadius: "".concat(3, "px"),
                                            pointerEvents: "none"
                                        }
                                    })))
                                })), h.map((function(n, e) {
                                    var t = n.getHandleProps;
                                    return (0, f.jsx)("button", (0, I.Z)({}, t({
                                        key: String(e),
                                        style: {
                                            width: "14px",
                                            height: "14px",
                                            outline: "none",
                                            borderRadius: "100%",
                                            background: (0, O.NE)(O.iK.essentialBrightAccent),
                                            border: "none"
                                        }
                                    })))
                                }))]
                            })), n.rightEnd ? (0, f.jsx)(wn.Dy.p, {
                                className: "right-label",
                                children: n.rightEnd
                            }) : (0, f.jsx)("span", {
                                children: "\xa0"
                            }), (0, f.jsx)("span", {}), (0, f.jsx)("span", {
                                className: "value-display",
                                id: m,
                                children: o
                            }), (0, f.jsx)("span", {})]
                        })]
                    })
                },
                Mn = t(58910);
            var Fn = function(n) {
                var e = n.in,
                    t = void 0 === e ? void 0 : e,
                    r = n.className,
                    i = void 0 === r ? "" : r,
                    o = n.children,
                    a = (0, B.Z)(function() {
                        var n = (0, c.useRef)(),
                            e = (0, c.useState)(0),
                            t = e[0],
                            r = e[1],
                            i = (0, c.useRef)(t),
                            o = (0, c.useState)((function() {
                                return new ResizeObserver((function(e) {
                                    n.current && i.current !== n.current.offsetHeight && (i.current = n.current.offsetHeight, r(n.current.offsetHeight))
                                }))
                            }))[0];
                        return (0, c.useLayoutEffect)((function() {
                            return n.current && (r(n.current.offsetHeight), o.observe(n.current, {})),
                                function() {
                                    return o.disconnect()
                                }
                        }), [o]), [n, t]
                    }(), 2),
                    s = a[0],
                    l = a[1],
                    u = (0, c.useRef)(t ? "auto" : 0),
                    d = (0, Mn.q_)({
                        config: (0, ln.Z)((0, I.Z)({}, Mn.vc.stiff), {
                            clamp: !t
                        }),
                        from: {
                            height: u
                        },
                        to: {
                            height: t ? l : 0
                        }
                    }) || {};
                return (0, f.jsx)(Mn.q.div, {
                    style: (0, I.Z)({
                        overflow: "hidden"
                    }, d),
                    className: i,
                    children: (0, f.jsx)("div", {
                        ref: s,
                        children: o
                    })
                })
            };

            function Pn() {
                var n = (0, i.Z)(["\n  margin-top: ", ";\n  margin-bottom: ", ";\n\n  & hr {\n    border: 1px solid ", ";\n  }\n"]);
                return Pn = function() {
                    return n
                }, n
            }

            function En() {
                var n = (0, i.Z)(["\n  padding-top: ", ";\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n\n  @media (max-width: ", ") {\n    grid-template-columns: 1fr;\n  }\n"]);
                return En = function() {
                    return n
                }, n
            }

            function Dn() {
                var n = (0, i.Z)(["\n  display: flex;\n  border: 2px solid ", ";\n  border-radius: 6px;\n  padding: ", " ", ";\n  cursor: pointer;\n  align-items: center;\n  color: ", ";\n  text-transform: uppercase;\n  & svg {\n    margin-left: auto;\n    transform: rotate(", "deg);\n    transition: transform 150ms ease-in;\n  }\n"]);
                return Dn = function() {
                    return n
                }, n
            }
            var Ln, Rn = h.ZP.div(Pn(), l.g4V, l.JBZ, (0, O.NE)(O.iK.essentialAnnouncement)),
                Nn = h.ZP.div(En(), l.g4V, l.SIq),
                _n = h.ZP.div.attrs({
                    role: "button",
                    tabIndex: 0,
                    title: "Toggle midi adjustments"
                })(Dn(), (0, O.NE)(O.iK.essentialAnnouncement), l.dly, l.nuo, (0, O.NE)(O.iK.essentialAnnouncement), (function(n) {
                    return n.open ? 0 : 180
                })),
                In = function(n) {
                    var e = n.thresholdParameters,
                        t = n.updateThresholdParameter,
                        r = n.notes,
                        i = n.setMIDITempo,
                        o = (0, c.useState)(r.length < 5),
                        a = o[0],
                        s = o[1];
                    return (0, f.jsxs)(Rn, {
                        children: [(0, f.jsxs)(_n, {
                            onClick: function() {
                                return s((function(n) {
                                    return !n
                                }))
                            },
                            open: a,
                            children: [(0, f.jsx)("div", {
                                children: a ? "Hide midi adjustments" : "Show midi adjustments"
                            }), (0, f.jsx)(vn.C, {})]
                        }), (0, f.jsx)(Fn, { in: a,
                            children: (0, f.jsxs)("div", {
                                children: [(0, f.jsxs)(Nn, {
                                    children: [(0, f.jsx)(Sn, {
                                        thresholdName: V.OnsetThreshold,
                                        min: .05,
                                        max: .95,
                                        step: .05,
                                        value: e.onsetThreshold,
                                        leftEnd: "Split Notes",
                                        rightEnd: "Merge Notes",
                                        desc: "How easily a note should be split into two.",
                                        onChange: function(n) {
                                            return t({
                                                onsetThreshold: n
                                            })
                                        }
                                    }), (0, f.jsx)(Sn, {
                                        thresholdName: V.FrameThreshold,
                                        min: .05,
                                        max: .95,
                                        step: .05,
                                        value: e.frameThreshold,
                                        leftEnd: "More Notes",
                                        rightEnd: "Fewer Notes",
                                        desc: "The model confidence required to create a note.",
                                        onChange: function(n) {
                                            return t({
                                                frameThreshold: n
                                            })
                                        }
                                    }), (0, f.jsx)(Sn, {
                                        thresholdName: V.MinFreq,
                                        min: 0,
                                        max: 2e3,
                                        step: 10,
                                        value: e.minFreq,
                                        leftEnd: "Lower notes",
                                        rightEnd: "Higher notes",
                                        desc: "The minimum allowed pitch, in Hz.",
                                        onChange: function(n) {
                                            return t({
                                                minFreq: n
                                            })
                                        }
                                    }), (0, f.jsx)(Sn, {
                                        thresholdName: V.MaxFreq,
                                        min: 40,
                                        max: 3e3,
                                        step: 10,
                                        value: e.maxFreq,
                                        leftEnd: "Lower notes",
                                        rightEnd: "Higher notes",
                                        desc: "The maximum allowed pitch, in Hz.",
                                        onChange: function(n) {
                                            return t({
                                                maxFreq: n
                                            })
                                        }
                                    }), (0, f.jsx)(Sn, {
                                        thresholdName: V.MinimumNoteLength,
                                        min: 3,
                                        max: 50,
                                        step: 1,
                                        value: e.minimumNoteLength,
                                        leftEnd: "Short Notes",
                                        rightEnd: "Long Notes",
                                        desc: "The minimum length required to emit a note, in milliseconds.",
                                        onChange: function(n) {
                                            return t({
                                                minimumNoteLength: n
                                            })
                                        }
                                    }), (0, f.jsx)(Sn, {
                                        thresholdName: V.FileTempo,
                                        min: 24,
                                        max: 224,
                                        step: 1,
                                        value: 120,
                                        leftEnd: "",
                                        rightEnd: "",
                                        desc: "The tempo used to export the MIDI file.",
                                        onChange: function(n) {
                                            return i(n)
                                        }
                                    })]
                                }), (0, f.jsx)("hr", {})]
                            })
                        })]
                    })
                },
                Bn = t(26496),
                On = function(n) {
                    var e = n.data,
                        t = n.displayFunction,
                        r = n.backgroundColor,
                        i = n.customMargins,
                        o = n.width,
                        a = n.height,
                        s = (0, c.useRef)(null),
                        l = (0, c.useRef)(null),
                        u = function(n) {
                            var e = (0, c.useState)(null),
                                t = e[0],
                                r = e[1];
                            return (0, c.useEffect)((function() {
                                var e = null === n || void 0 === n ? void 0 : n.current,
                                    t = new ResizeObserver((function(n) {
                                        n.forEach((function(n) {
                                            r(n.contentRect)
                                        }))
                                    }));
                                return t.observe(e),
                                    function() {
                                        t.unobserve(e)
                                    }
                            }), [n]), t
                        }(l),
                        d = i || {
                            top: 40,
                            bottom: 40,
                            left: 40,
                            right: 40
                        };
                    return (0, c.useEffect)((function() {
                        var n = Bn.Ys(s.current);
                        s.current && (s.current.innerHTML = ""), u && (n.empty() || t(n, e, u, d))
                    }), [e, u]), (0, f.jsx)("div", {
                        ref: l,
                        style: {
                            width: o || "100%",
                            height: a || "100%"
                        },
                        children: (0, f.jsx)("canvas", {
                            ref: s,
                            style: {
                                background: r || "transparent",
                                height: a,
                                width: o
                            }
                        })
                    })
                },
                An = ["C", "Db", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"],
                Hn = (Ln = {}, (0, Q.Z)(Ln, "Db", !0), (0, Q.Z)(Ln, "Eb", !0), (0, Q.Z)(Ln, "F#", !0), (0, Q.Z)(Ln, "Ab", !0), (0, Q.Z)(Ln, "Bb", !0), Ln),
                Un = "#F573A0",
                qn = "#ba406b",
                Vn = 4192,
                Wn = function(n) {
                    return Hn[An[n % 12]] ? "#303030" : "#fffef2"
                },
                zn = function(n) {
                    return n[n.TIME = 0] = "TIME", n[n.BEATS = 1] = "BEATS", n
                }({}),
                $n = function(n, e) {
                    return e === zn.BEATS ? n.startBeat : n.time
                },
                Gn = function(n, e) {
                    return e === zn.BEATS ? n.endBeat : n.time + n.duration
                },
                Jn = function(n, e, t, r) {
                    return e($n(n, t)) + r
                },
                Xn = function(n, e, t) {
                    var r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
                    return e(n.midi + 1 + r) + t
                },
                Kn = function(n, e, t, r, i, o) {
                    var a = e(Gn(n, t)) - e($n(n, t)) - 2 * r;
                    return e($n(n, t)) + r < i.left || e($n(n, t)) + r + a > o - i.right ? 0 : a
                },
                Yn = function(n, e, t) {
                    return e(n.midi) - e(n.midi + 1) - 2 * t
                },
                Qn = c.memo((function(n) {
                    var e = n.notes,
                        t = n.abscissaMode,
                        r = void 0 === t ? zn.TIME : t,
                        i = n.backgroundColor,
                        o = n.customMargins,
                        a = n.noteRectProps,
                        s = n.maxXDomain,
                        l = n.pixelsPerSecond,
                        u = n.height;
                    return (0, f.jsx)(On, {
                        backgroundColor: i,
                        customMargins: o,
                        data: e,
                        displayFunction: function(n, e, t, i) {
                            ! function(n, e, t, r, i) {
                                var o = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : {
                                        padding: .5,
                                        rx: 1,
                                        ry: 1,
                                        strokeWidth: .5
                                    },
                                    a = arguments.length > 6 ? arguments[6] : void 0,
                                    s = 2,
                                    l = {
                                        width: Math.max(0, t.width * s),
                                        height: Math.max(0, t.height * s)
                                    },
                                    u = l.width,
                                    d = l.height,
                                    c = {
                                        canvas: n,
                                        dimensions: t,
                                        margins: r
                                    };
                                console.log(r);
                                var h = Bn.VV$(e, (function(n) {
                                        return n.midi
                                    })) || 0,
                                    f = Bn.Fp7(e, (function(n) {
                                        return n.midi
                                    })) || 0,
                                    p = a || Bn.Fp7(e, (function(n) {
                                        return Gn(n, i)
                                    })) || 0,
                                    g = h - 3,
                                    m = f + 3,
                                    v = Bn.BYU().domain([0, p]).range([r.left * s, u - r.right * s]),
                                    x = Bn.BYU().domain([g, m]).range([d - r.bottom * s, r.top * s]);
                                c.xScale = v, c.yScale = x;
                                var w = m - g,
                                    y = x(g) - x(g + 1),
                                    C = v(0),
                                    b = v(p) - r.left * s,
                                    j = n.node().getContext("2d");
                                if (n.node().width = u, n.node().height = d, null === j) throw new Error("This browser does not support 2-dimensional canvas rendering contexts.");
                                j.clearRect(0, 0, n.node().width, n.node().height);
                                for (var Z = 1; Z <= w; Z++) {
                                    var k = g + Z;
                                    j.fillStyle = Wn(k), j.globalAlpha = .8, j.fillRect(0, x(k), C, Math.max(0, y)), j.globalAlpha = .2, j.fillRect(C, x(k), b, Math.max(0, y))
                                }
                                j.shadowBlur = 2, j.shadowOffsetX = .2, j.shadowOffsetY = .4, j.shadowColor = "#3a3a3a";
                                var T = function(n, e, t) {
                                    n.forEach((function(n) {
                                        var a = Jn(n, e, i, o.padding),
                                            s = Xn(n, t, o.padding),
                                            l = Math.max(0, Kn(n, e, i, o.padding, r, u)),
                                            d = Math.max(0, Yn(n, t, o.padding));
                                        j.globalAlpha = n.velocity / 127 * .4 + .5, j.fillStyle = Un, j.fillRect(a, s, l, d), j.strokeStyle = qn, j.globalAlpha = .8, j.lineWidth = 1, j.strokeRect(a, s, l, d)
                                    }))
                                };
                                T(e.filter((function(n) {
                                    return void 0 === n.pitchBends || void 0 !== n.pitchBends && (0 === n.pitchBends.length || n.pitchBends.every((function(n) {
                                        return 0 === n
                                    })))
                                })), v, x), e.filter((function(n) {
                                    return void 0 !== n.pitchBends && 0 !== n.pitchBends.length && !n.pitchBends.every((function(n) {
                                        return 0 === n
                                    }))
                                })).forEach((function(n) {
                                    var e = Kn(n, v, i, o.padding, r, u),
                                        t = n.pitchBends.map((function(t, r) {
                                            return [Jn(n, v, i, o.padding) + r / n.pitchBends.length * e, Xn(n, x, o.padding, t / Vn)]
                                        })),
                                        a = n.pitchBends.concat().reverse().map((function(t, r) {
                                            return [Jn(n, v, i, o.padding) + (n.pitchBends.length - r - 1) / n.pitchBends.length * e, Xn(n, x, o.padding, t / Vn - 1)]
                                        })),
                                        s = Bn.jvg().x((function(n) {
                                            return n[0]
                                        })).y((function(n) {
                                            return n[1]
                                        })).curve(Bn.fxm).context(j);
                                    j.beginPath(), s(t.concat(a)), j.lineWidth = 1, j.globalAlpha = n.velocity / 127 * .4 + .5, j.fillStyle = Un, j.strokeStyle = qn, j.stroke(), j.fill(), j.closePath()
                                }))
                            }(n, e, t, i, r, a, s)
                        },
                        width: void 0 !== l ? "".concat(s * l, "px") : "100%",
                        height: u
                    })
                }), (function(n, e) {
                    return JSON.stringify(n.notes.length) === JSON.stringify(e.notes.length)
                })),
                ne = function(n) {
                    (0, G.Z)(t, n);
                    var e = (0, J.Z)(t);

                    function t(n) {
                        var r;
                        return (0, z.Z)(this, t), r = e.call(this, n), (0, Q.Z)((0, W.Z)(r), "tickRequestId", void 0), (0, Q.Z)((0, W.Z)(r), "waveform", void 0), (0, Q.Z)((0, W.Z)(r), "width", void 0), (0, Q.Z)((0, W.Z)(r), "height", void 0), (0, Q.Z)((0, W.Z)(r), "waveformWrapper", c.createRef()), n.width && (r.width = n.width), n.height && (r.height = n.height), r
                    }
                    return (0, $.Z)(t, [{
                        key: "componentDidMount",
                        value: function() {
                            var n, e, t, r;
                            this.waveform = new this.props.Waveform(this.props.audioFile), null !== this.waveformWrapper.current && this.waveformWrapper.current.appendChild(this.waveform.element), this.waveform.interactive = !1;
                            var i = null !== (r = null === (n = window.visualViewport) || void 0 === n ? void 0 : n.width) && void 0 !== r ? r : window.innerWidth;
                            this.width || (console.log("no width"), this.width = i < 962 ? 306 : 962), this.height || (this.height = i < 962 ? 150 : 250), this.waveform.width = this.width, this.waveform.height = this.height, this.waveform.waveformColor = 0, this.waveform.startTime = 0, this.waveform.endTime = null === (e = this.props.audioFile) || void 0 === e ? void 0 : e.duration, this.waveform.sampleRate = (null === (t = this.props.audioFile) || void 0 === t ? void 0 : t.sampleRate) / 8
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function(n) {
                            n.width !== this.props.width && this.waveform && (console.log("changing waveform width", this.props, n), this.width = this.props.width, this.waveform.width = this.props.width)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            cancelAnimationFrame(this.tickRequestId)
                        }
                    }, {
                        key: "currentTime",
                        get: function() {
                            return Math.max(0, Math.min(this.waveform.source.duration, this.waveform.midpoint))
                        },
                        set: function(n) {
                            this.waveform.midpoint = Math.max(0, Math.min(this.waveform.source.duration, n))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return (0, f.jsx)("div", {
                                style: {
                                    pointerEvents: "none",
                                    height: "".concat(this.height, "px")
                                },
                                ref: this.waveformWrapper
                            })
                        }
                    }]), t
                }(c.Component),
                ee = 50;

            function te() {
                var n = (0, i.Z)(["\n  background: #ffcdd2;\n  margin-top: 6px;\n  overflow: hidden;\n"]);
                return te = function() {
                    return n
                }, n
            }

            function re() {
                var n = (0, i.Z)(["\n  width: ", ";\n  height: ", ";\n  margin-top: -", ";\n  border-left: ", " solid black;\n  position: relative;\n  margin-left: ", "px;\n  transform: translate(", "px);\n"]);
                return re = function() {
                    return n
                }, n
            }

            function ie() {
                var n = (0, i.Z)(["\n  width: ", ";\n  height: ", ";\n  margin-top: -", ";\n  position: relative;\n  background-color: #5f9ea0;\n  opacity: 0.2;\n  transform: translate(", "px);\n"]);
                return ie = function() {
                    return n
                }, n
            }
            var oe = h.ZP.div(te()),
                ae = h.ZP.div(re(), (function(n) {
                    return n.width
                }), (function(n) {
                    return n.height
                }), (function(n) {
                    return n.height
                }), (function(n) {
                    return n.width
                }), (function(n) {
                    return n.leftMargin
                }), (function(n) {
                    return Math.max(0, n.px)
                })),
                se = h.ZP.div(ie(), (function(n) {
                    return n.width
                }), (function(n) {
                    return n.height
                }), (function(n) {
                    return n.height
                }), (function(n) {
                    return n.px
                })),
                le = function(n) {
                    var e = n.percentage,
                        t = n.audio,
                        r = n.audioState,
                        i = n.setSkipPercentage,
                        o = n.Waveform,
                        a = (0, c.useRef)(null),
                        s = (0, c.useRef)(null),
                        l = (0, c.useRef)(null),
                        u = (0, c.useState)(60),
                        d = u[0],
                        h = u[1];
                    (0, c.useEffect)((function() {
                        if (a && a.current && s && s.current) {
                            var n = Math.ceil(d * t.duration),
                                r = (n - ee) * e / 100;
                            if (a && a.current && a.current.offsetWidth > n - r + 10) {
                                var i = r - (n - a.current.offsetWidth) - 10;
                                a.current.scrollLeft = n - a.current.offsetWidth, s.current.style.transform = "translate(".concat(Math.max(0, i), "px)")
                            } else s.current.style.transform = "translate(0px)", a.current.scrollLeft = r - 10
                        }
                    }), [a, s, d, t.duration, e]);
                    var p = a && a.current && a.current.offsetWidth ? a.current.offsetWidth - ee : 850;
                    n.audio.duration * d < p && h((p + ee) / n.audio.duration);
                    var g = a.current && p ? p / (d * t.duration) : 0,
                        m = r.pianoRollNotes.slice(0, r.pianoRollNotes.length - 1),
                        v = p * e / 100 - 10;
                    return (0, f.jsxs)(oe, {
                        children: [(0, f.jsx)("div", {
                            ref: a,
                            style: {
                                height: "".concat(400, "px"),
                                overflow: "hidden",
                                paddingRight: "".concat(p, "px")
                            },
                            children: (0, f.jsx)(Qn, {
                                customMargins: {
                                    top: 0,
                                    bottom: 0,
                                    left: ee,
                                    right: 0
                                },
                                notes: m,
                                backgroundColor: "#FFCDD2",
                                maxXDomain: t.duration,
                                pixelsPerSecond: d,
                                height: "".concat(400, "px")
                            })
                        }), (0, f.jsx)(ae, {
                            ref: s,
                            px: 0,
                            width: "1px",
                            height: "".concat(400, "px"),
                            leftMargin: ee
                        }), (0, f.jsx)("div", {
                            onClick: function(n) {
                                var e = l.current.clientWidth,
                                    t = l.current.offsetLeft,
                                    r = n.pageX;
                                console.log(e, t, r), i((r - t - ee) / (e - ee) * 100)
                            },
                            ref: l,
                            style: {
                                overflowX: "hidden"
                            },
                            children: (0, f.jsxs)("div", {
                                style: {
                                    marginLeft: "".concat(ee, "px"),
                                    overflow: "hidden"
                                },
                                children: [(0, f.jsx)(ne, {
                                    audioFile: t,
                                    height: 75,
                                    width: p,
                                    Waveform: o
                                }), (0, f.jsx)(ae, {
                                    px: v,
                                    width: "1px",
                                    height: "75px",
                                    leftMargin: 0
                                }), t.duration >= 15 ? (0, f.jsx)(se, {
                                    px: v,
                                    width: "".concat(p * g, "px"),
                                    height: "75px"
                                }) : null]
                            })
                        })]
                    })
                };

            function ue() {
                var n = (0, i.Z)(["\n  display: flex;\n  flex-direction: row;\n  flex: 1 1 0;\n  gap: 12px;\n  margin-bottom: 24px;\n\n  @media (max-width: ", ") {\n    flex-direction: column;\n    align-items: center;\n  }\n"]);
                return ue = function() {
                    return n
                }, n
            }

            function de() {
                var n = (0, i.Z)(["\n  display: flex;\n  flex-wrap: nowrap;\n  overflow: hidden;\n  align-items: center;\n\n  & > :nth-child(2) {\n    margin-left: 5px;\n  }\n"]);
                return de = function() {
                    return n
                }, n
            }

            function ce() {
                var n = (0, i.Z)(["\n  text-align: center;\n  font-size: 20px;\n  line-height: 38px;\n  position: relative;\n  svg {\n    position: absolute;\n    top: 8px;\n    margin-left: -64px;\n  }\n  > span:first-of-type {\n    color: ", ";\n  }\n  a {\n    color: ", ";\n    text-decoration: underline;\n    text-underline-offset: 0.14em;\n  }\n\n  @media (max-width: ", ") {\n    svg {\n      position: initial;\n      display: block;\n      margin: auto;\n    }\n  }\n"]);
                return ce = function() {
                    return n
                }, n
            }

            function he() {
                var n = (0, i.Z)(["\n  display: flex;\n  justify-content: center;\n  gap: 0px 52px;\n  flex-wrap: wrap;\n"]);
                return he = function() {
                    return n
                }, n
            }
            var fe = h.ZP.div(ue(), l.rmE),
                pe = h.ZP.div(de()),
                ge = h.ZP.div(ce(), (0, O.NE)("essentialAnnouncement"), (0, O.NE)("textBase"), l.SA3),
                me = h.ZP.div(he()),
                ve = function(n) {
                    var e = (0, c.useState)(0),
                        t = e[0],
                        r = e[1],
                        i = (0, c.useState)(0),
                        o = i[0],
                        a = i[1],
                        s = (0, c.useState)(!1),
                        u = (s[0], s[1]),
                        d = (0, c.useState)(!1),
                        h = d[0],
                        p = d[1],
                        g = (0, c.useState)(120),
                        m = g[0],
                        v = g[1],
                        x = n.Waveform,
                        w = (0, c.useState)({
                            onsetThreshold: q.defaultOnsetThresh,
                            frameThreshold: q.defaultFrameThresh,
                            minimumNoteLength: q.defaultMinNoteLen,
                            inferOnsets: q.defaultInferOnsets,
                            maxFreq: q.defaultMaxFreq,
                            minFreq: q.defaultMinFreq
                        }),
                        y = w[0],
                        C = w[1],
                        b = (0, B.Z)((0, A.e)(mn), 2),
                        j = b[0],
                        Z = b[1],
                        k = j.context.isPlayable;
                    (0, c.useEffect)((function() {
                        Z("SET_TEMPO", {
                            MIDITempo: m
                        })
                    }), [m, Z]), (0, c.useEffect)((function() {
                        var e = new Worker("/audio-worker.js");
                        return e.onmessage = function(n) {
                                var e;
                                if ("finished" === (null === n || void 0 === n || null === (e = n.data) || void 0 === e ? void 0 : e.command)) {
                                    var t = n.data.result;
                                    t.length > 1 ? Z("SET_RESULTS", {
                                        result: t
                                    }) : Z("NO_RESULTS")
                                }
                            }, Z("PROCESS"), e.postMessage({
                                command: "sync",
                                payload: {
                                    contours: n.contours,
                                    frames: n.frames,
                                    onsets: n.onsets,
                                    onsetThreshold: y.onsetThreshold,
                                    frameThreshold: y.frameThreshold,
                                    minimumNoteLength: y.minimumNoteLength,
                                    inferOnsets: Boolean(y.inferOnsets),
                                    maxFreq: y.maxFreq,
                                    minFreq: y.minFreq
                                }
                            }),
                            function() {
                                e.terminate()
                            }
                    }), [n, y, Z]);
                    var T = URL.createObjectURL(new Blob([U(n.audio.getChannelData(0), {
                            numChannels: 1,
                            sampleRate: n.audio.sampleRate
                        })], {
                            type: "audio/wave"
                        })),
                        S = (0, c.useCallback)((function(n) {
                            C((function(e) {
                                return (0, I.Z)({}, e, n)
                            }))
                        }), [C]);
                    return (0, f.jsxs)("div", {
                        children: ["initial" === j.value ? (0, f.jsx)(R, {
                            children: "Converting notes to MIDI..."
                        }) : null, j.matches("badFile") && (0, f.jsxs)("div", {
                            style: {
                                textAlign: "center",
                                paddingTop: l.mGT
                            },
                            children: [(0, f.jsxs)(ge, {
                                children: [(0, f.jsx)(sn, {}), (0, f.jsx)("span", {
                                    children: "Oh no! Basic Pitch didn't find any notes."
                                }), (0, f.jsx)("br", {}), (0, f.jsxs)("span", {
                                    children: [(0, f.jsx)("a", {
                                        href: "#reset-file",
                                        onClick: function(e) {
                                            e.preventDefault(), n.onResetRequest()
                                        },
                                        children: "Try again?"
                                    }), " ", "Or try with a test file:"]
                                })]
                            }), (0, f.jsxs)(me, {
                                children: [(0, f.jsxs)(K.DF, {
                                    iconLeading: on,
                                    $yellow: !0,
                                    onClick: function() {
                                        return function(n) {
                                            var e = document.createElement("a");
                                            e.href = n, e.download = n.split("/").pop(), document.body.appendChild(e), e.click(), document.body.removeChild(e)
                                        }("/assets/piano-Mazurka_in_D_major.mp3")
                                    },
                                    children: ["Download", (0, f.jsx)("br", {}), "Piano Test File"]
                                }), (0, f.jsxs)(K.DF, {
                                    iconLeading: an,
                                    $yellow: !0,
                                    disabled: !0,
                                    children: ["Download", (0, f.jsx)("br", {}), "Violin Test File"]
                                })]
                            })]
                        }), j.matches("active") ? (0, f.jsxs)("div", {
                            children: [(0, f.jsxs)(fe, {
                                children: [(0, f.jsxs)(c.Fragment, {
                                    children: [(0, f.jsx)(rn, {
                                        midiBuffer: j.context.midiBuffer,
                                        onTickUpdate: r,
                                        onFileEnd: function() {
                                            return a(0)
                                        },
                                        skipToPercentage: o,
                                        setPlaying: u,
                                        seeking: h,
                                        soundfont: n.soundfont,
                                        disabled: !k
                                    }), (0, f.jsx)(Y, {
                                        downloadTitle: "Download Midi",
                                        fileData: {
                                            mime: "audio/midi",
                                            filename: "basic_pitch_transcription.mid",
                                            contents: j.context.midiBuffer
                                        },
                                        disabled: !k
                                    })]
                                }, j.context.revision), (0, f.jsxs)(pe, {
                                    children: [(0, f.jsxs)("audio", {
                                        controls: !0,
                                        title: "basic-pitch-recording.wav",
                                        children: [(0, f.jsx)("track", {
                                            kind: "captions"
                                        }), (0, f.jsx)("source", {
                                            src: T
                                        })]
                                    }), j.matches("active.processing") ? (0, f.jsx)(F, {}) : null]
                                })]
                            }), (0, f.jsx)(le, {
                                percentage: t,
                                audio: n.audio,
                                audioState: j.context,
                                setSeeking: p,
                                setSkipPercentage: a,
                                Waveform: x
                            }), (0, f.jsx)(In, {
                                thresholdParameters: y,
                                updateThresholdParameter: S,
                                notes: j.context.notes,
                                setMIDITempo: v
                            }), (0, f.jsx)(K.zw, {
                                $yellow: !0,
                                children: "Note: None of your audio is saved or stored. It all stays on your machine."
                            })]
                        }) : null]
                    })
                },
                xe = t(1242),
                we = t(35164);

            function ye() {
                return (0, f.jsxs)("svg", {
                    width: "70",
                    height: "70",
                    viewBox: "0 0 70 70",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, f.jsx)("path", {
                        d: "M32.4019 6.5C33.5566 4.5 36.4434 4.5 37.5981 6.5L60.9808 47C62.1355 49 60.6921 51.5 58.3827 51.5H11.6173C9.30791 51.5 7.86454 49 9.01924 47L32.4019 6.5Z",
                        stroke: "#FF4632",
                        strokeWidth: "2"
                    }), (0, f.jsx)("path", {
                        d: "M37.9814 23.8182L37.5197 36.3182H33.4714L33.0098 23.8182H37.9814ZM35.4956 42.2841C34.809 42.2841 34.2201 42.0444 33.7289 41.565C33.2435 41.0797 33.0038 40.4908 33.0098 39.7983C33.0038 39.1236 33.2435 38.5465 33.7289 38.0671C34.2201 37.5877 34.809 37.348 35.4956 37.348C36.1466 37.348 36.7207 37.5877 37.2179 38.0671C37.7209 38.5465 37.9754 39.1236 37.9814 39.7983C37.9754 40.2599 37.8541 40.6802 37.6174 41.0589C37.3865 41.4318 37.0847 41.7307 36.7118 41.9556C36.339 42.1746 35.9335 42.2841 35.4956 42.2841Z",
                        fill: "#FF4632"
                    })]
                })
            }
            var Ce = function() {
                return (0, f.jsx)("svg", {
                    width: "45",
                    height: "41",
                    viewBox: "0 0 45 41",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    style: {
                        marginBottom: 12
                    },
                    children: (0, f.jsx)("path", {
                        d: "M18 25H27V11.5H33.75L22.5 0.25L11.25 11.5H18V25ZM43.5105 28.447C43.038 27.943 39.8858 24.5702 38.9858 23.6905C38.3551 23.0859 37.5149 22.7489 36.6413 22.75H32.688L39.582 29.4865H31.608C31.4996 29.4845 31.3927 29.5111 31.2979 29.5637C31.2031 29.6162 31.1238 29.6928 31.068 29.7857L29.232 34H15.768L13.932 29.7857C13.8759 29.6931 13.7966 29.6168 13.7018 29.5643C13.6071 29.5118 13.5003 29.485 13.392 29.4865H5.41802L12.3098 22.75H8.35877C7.46552 22.75 6.61277 23.1077 6.01427 23.6905C5.11427 24.5725 1.96202 27.9452 1.48952 28.447C0.389268 29.6192 -0.215982 30.553 0.0720182 31.7073L1.33427 38.6237C1.62227 39.7803 2.88902 40.7297 4.15127 40.7297H40.8533C42.1155 40.7297 43.3823 39.7803 43.6703 38.6237L44.9325 31.7073C45.216 30.553 44.613 29.6192 43.5105 28.447Z",
                        fill: "#FAE62D"
                    })
                })
            };

            function be() {
                var n = (0, i.Z)(["\n  --dropzone-color: #ffcdd2;\n  display: flex;\n  flex-direction: column;\n  flex: 1;\n  align-items: center;\n  justify-content: center;\n  padding: 20px;\n  border: 3px;\n  border-style: solid;\n  border-color: var(--dropzone-color);\n  box-sizing: border-box;\n  background-color: var(--dropzone-color);\n  color: #191414;\n  outline: none;\n  height: 138px;\n  transition: border 0.24s ease-in-out;\n\n  & span {\n    width: 100%;\n    text-overflow: ellipsis;\n    overflow: hidden;\n    white-space: nowrap;\n  }\n"]);
                return be = function() {
                    return n
                }, n
            }

            function je() {
                var n = (0, i.Z)(["\n  display: inline-block;\n  box-sizing: border-box;\n  height: 40px;\n  border: 1px solid #191414;\n  border-radius: 20px;\n  background: #fff;\n  padding: 8px 20px;\n  text-align: center;\n  vertical-align: middle;\n"]);
                return je = function() {
                    return n
                }, n
            }
            var Ze = h.ZP.div(be()),
                ke = {
                    borderColor: "#2196f3"
                },
                Te = {
                    borderStyle: "dashed",
                    borderColor: "var(--dropzone-color)",
                    backgroundColor: "transparent",
                    color: (0, O.NE)(O.iK.textAnnouncement)
                },
                Se = {
                    borderStyle: "dashed",
                    borderColor: (0, O.NE)(O.iK.textNegative),
                    backgroundColor: "transparent",
                    color: "white"
                },
                Me = h.ZP.span(je());

            function Fe(n) {
                var e = n.fileAdded,
                    t = n.onFileAdded,
                    r = n.disabled,
                    i = (0, c.useState)(""),
                    o = i[0],
                    a = i[1],
                    s = (0, c.useState)(!1),
                    l = s[0],
                    u = s[1],
                    d = (0, xe.uI)({
                        accept: r ? void 0 : "audio/*",
                        onDropAccepted: function(n) {
                            n.forEach((function(n) {
                                a(n.name);
                                var e = new FileReader;
                                e.onabort = function() {
                                    return console.log("file reading was aborted")
                                }, e.onerror = function() {
                                    return console.log("file reading has failed")
                                }, e.onload = function() {
                                    t(e.result)
                                }, e.readAsArrayBuffer(n)
                            }))
                        },
                        onDropRejected: function() {
                            a(""), u(!0)
                        },
                        multiple: !1,
                        disabled: r
                    }),
                    h = d.getRootProps,
                    p = d.getInputProps,
                    g = d.isFocused,
                    m = d.isDragAccept,
                    v = d.isDragReject,
                    x = (0, c.useMemo)((function() {
                        return (0, I.Z)({}, g ? ke : {}, v || l ? Se : {}, m ? Te : {})
                    }), [g, m, v, l]),
                    w = (0, f.jsx)(we.P, {
                        condensed: !0,
                        children: "Drop your audio file here or click to select one (.wav, .mp3, etc.)"
                    });
                m ? w = (0, f.jsxs)(f.Fragment, {
                    children: [(0, f.jsx)(Ce, {}), (0, f.jsx)(we.P, {
                        condensed: !0,
                        children: "Drop it here!"
                    })]
                }) : v || l ? w = (0, f.jsxs)(f.Fragment, {
                    children: [(0, f.jsx)(ye, {}), (0, f.jsx)(we.P, {
                        condensed: !0,
                        children: "That file type is not supported"
                    })]
                }) : e && (w = (0, f.jsx)(Me, {
                    children: o || "Recording.mp3"
                }));
                var y = h({
                        style: x
                    }),
                    C = y.onDrop,
                    b = (0, xn.Z)(y, ["onDrop"]);
                return (0, f.jsxs)(Ze, (0, ln.Z)((0, I.Z)({}, b), {
                    onDrop: r ? function(n) {
                        return n.preventDefault()
                    } : C,
                    children: [r ? null : (0, f.jsx)("input", (0, I.Z)({}, p())), w]
                }))
            }

            function Pe(n) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 22050,
                    t = new OfflineAudioContext(1, n.length * (e / n.sampleRate), e),
                    r = t.createChannelMerger(n.numberOfChannels),
                    i = t.createBufferSource();
                return i.buffer = n, i.connect(r), r.connect(t.destination), i.start(), t.startRendering()
            }

            function Ee() {
                var n = (0, i.Z)(["\n  padding-left: 72px;\n  padding-bottom: ", ";\n  max-width: 760px;\n\n  @media (max-width: ", ") {\n    padding-left: 0;\n  }\n"]);
                return Ee = function() {
                    return n
                }, n
            }

            function De() {
                var n = (0, i.Z)(["\n  display: flex;\n  gap: 30px;\n\n  @media (max-width: ", ") {\n    flex-direction: column;\n  }\n"]);
                return De = function() {
                    return n
                }, n
            }
            var Le = t.e(293).then(t.bind(t, 11293)).then((function(n) {
                    return n.default
                })).catch((function() {})),
                Re = "/soundfont/GeneralUserGS1.471/GeneralUserGSv1.471.sf2",
                Ne = h.ZP.div(Ee(), l.o78, l.rmE),
                _e = h.ZP.div(De(), l.gXv),
                Ie = function() {
                    var n = (0, r.Z)((function(n, e, r, i, s, l, u, d) {
                        var c, h, f, p, g, m;
                        return (0, a.__generator)(this, (function(a) {
                            switch (a.label) {
                                case 0:
                                    return r([]), i([]), s([]), [4, Le];
                                case 1:
                                    return d.apply(void 0, [a.sent()]), c = t.g.window.AudioContext, [4, (new c).decodeAudioData(n)];
                                case 2:
                                    return h = a.sent(), l(h), [4, Pe(h)];
                                case 3:
                                    return f = a.sent(), p = [], g = [], m = [], console.log("evaluating"), [4, null === u || void 0 === u ? void 0 : u.evaluateModel(f, (function(n, e, t) {
                                        var r, i, a;
                                        (r = p).push.apply(r, (0, o.Z)(n)), (i = g).push.apply(i, (0, o.Z)(e)), (a = m).push.apply(a, (0, o.Z)(t))
                                    }), (function(n) {
                                        return e(100 * n)
                                    }))];
                                case 4:
                                    return a.sent(), r(p), i(g), s(m), [2]
                            }
                        }))
                    }));
                    return function(e, t, r, i, o, a, s, l) {
                        return n.apply(this, arguments)
                    }
                }(),
                Be = function() {
                    var n = (0, c.useState)(0),
                        e = n[0],
                        t = n[1],
                        i = (0, c.useState)([]),
                        u = i[0],
                        h = i[1],
                        p = (0, c.useState)([]),
                        g = p[0],
                        m = p[1],
                        v = (0, c.useState)([]),
                        x = v[0],
                        w = v[1],
                        y = (0, c.useState)(null),
                        C = y[0],
                        b = y[1],
                        j = (0, c.useState)(),
                        Z = j[0],
                        T = j[1],
                        S = (0, c.useState)(null),
                        M = S[0],
                        F = S[1],
                        P = (0, c.useState)(!1),
                        E = P[0],
                        D = P[1],
                        L = (0, c.useState)(!1),
                        I = L[0],
                        B = L[1],
                        O = (0, c.useRef)(null),
                        A = function(n) {
                            return O.current = n
                        },
                        H = function() {
                            var n = (0, r.Z)((function() {
                                var n, e, t, r = arguments;
                                return (0, a.__generator)(this, (function(i) {
                                    switch (i.label) {
                                        case 0:
                                            for (n = r.length, e = new Array(n), t = 0; t < n; t++) e[t] = r[t];
                                            return B(!0), D(!1), [4, Ie.apply(void 0, (0, o.Z)(e))];
                                        case 1:
                                            return i.sent(), D(!0), B(!1), [2]
                                    }
                                }))
                            }));
                            return function() {
                                return n.apply(this, arguments)
                            }
                        }();
                    return (0, c.useEffect)((function() {
                        b(new s.lk("/model/model.json")), fetch("https://audio-understanding-dev.scdn.co".concat(Re)).catch((function() {
                            return fetch(Re)
                        })).then((function(n) {
                            return n.arrayBuffer()
                        })).then((function(n) {
                            return F(n)
                        }))
                    }), []), (0, f.jsx)(N.T, {
                        title: "Demo",
                        children: (0, f.jsxs)(_.$, {
                            children: [(0, f.jsxs)(Ne, {
                                children: [(0, f.jsxs)(K.P, {
                                    children: ["Try Basic Pitch, a free audio-to-MIDI converter with pitch bend detection, built by Spotify.", " ", (0, f.jsx)(d(), {
                                        href: "/about",
                                        passHref: !0,
                                        children: (0, f.jsx)(K.A, {
                                            target: "_self",
                                            children: "Learn more"
                                        })
                                    }), " ", "or follow the instructions below."]
                                }), (0, f.jsxs)(K.Ol, {
                                    children: [(0, f.jsx)("li", {
                                        children: "Press record and sing a ditty into your computer. Or drop a recording of any single instrument (piano, guitar, xylophone, you name it)."
                                    }), (0, f.jsx)("li", {
                                        children: "Then get a MIDI version back. Just like that."
                                    }), (0, f.jsx)("li", {
                                        children: "Download the MIDI file to fine tune and make corrections in your favorite digital audio workstation."
                                    })]
                                })]
                            }), (0, f.jsxs)(_e, {
                                children: [(0, f.jsx)(Fe, {
                                    onFileAdded: function(n) {
                                        return H(n, t, h, m, w, T, C, A)
                                    },
                                    fileAdded: I || E,
                                    noteDetectionPending: e < 100,
                                    disabled: I && !E
                                }), (0, f.jsx)(K.BZ, {
                                    onClick: function() {
                                        return D(!1)
                                    },
                                    onFileAdded: function(n) {
                                        return H(n, t, h, m, w, T, C, A)
                                    },
                                    disabled: I && !E
                                })]
                            }), null === C && (0, f.jsx)(R, {
                                children: "Downloading model."
                            }), null === M && (0, f.jsx)(R, {
                                children: "Downloading SoundFont. Cannot play rendered MIDI until downloaded."
                            }), I && (0, f.jsx)(R, {
                                children: "Loading file..."
                            }), e > 0 && e < 100 && (0, f.jsx)(k, {
                                value: e,
                                children: "Running note detection..."
                            }), E && (0, f.jsx)(ve, {
                                frames: u,
                                onsets: g,
                                contours: x,
                                audio: Z,
                                soundfont: M,
                                Waveform: O.current,
                                onResetRequest: function() {
                                    B(!1), D(!1)
                                }
                            }), C && M && !I && !E && (0, f.jsx)(K.P, {
                                $yellow: !0,
                                style: {
                                    marginTop: l.nuo
                                },
                                children: "Note: None of your audio is saved or stored. It all stays on your machine."
                            })]
                        })
                    })
                }
        },
        66969: function() {},
        75627: function() {},
        7196: function() {},
        89316: function() {},
        17618: function() {},
        85871: function() {}
    },
    function(n) {
        n.O(0, [226, 389, 264, 358, 497, 274, 992, 711, 119, 774, 888, 179], (function() {
            return e = 53671, n(n.s = e);
            var e
        }));
        var e = n.O();
        _N_E = e
    }
]);